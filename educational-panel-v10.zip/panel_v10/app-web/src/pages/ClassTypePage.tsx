import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { getClassType } from "../data";

export default function ClassTypePage() {
  const { typeKey } = useParams<{ typeKey: string }>();
  const navigate   = useNavigate();

  const typeData = getClassType(typeKey);

  if (!typeData) {
    return (
      <Layout title="خطا" backPath="/classes">
        <div className="not-available">صفحه پیدا نشد</div>
      </Layout>
    );
  }

  if (typeKey === "F" || typeKey === "G") {
    return (
      <Layout title={typeData.title} backPath="/classes">
        <div className="not-available">
          <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f512.png" width={36} height={36} alt="lock" style={{ display:"block", margin:"0 auto 12px" }} />
          این گزینه به زودی در دسترس خواهد بود
        </div>
      </Layout>
    );
  }

  const isAnnual = typeKey === "A";
  const iconColors: Record<string, string> = {
    A: "#2f6f3e", B: "#9b111e", C: "#c9a227", D: "#1a4a7a", E: "#5a1a7a",
  };
  const color = iconColors[typeKey ?? "A"] ?? "#2f6f3e";

  // آیکون ایموجی برای هر درس
  const subjectEmojis: Record<string, string> = {
    jam3e_shenasi:       "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f465.png",
    din_zendegi:         "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/2b50.png",
    ravan_shenasi:       "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f9e0.png",
    riazi_va_amar:       "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4ca.png",
    zaban_enghelisi:     "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f1ec-1f1e7.png",
    arabi:               "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4d6.png",
    olum_va_fonun_adabi: "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/270f.png",
    farsi:               "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f58a.png",
    falsafe:             "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f914.png",
    ensan_va_mohit:      "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f331.png",
  };

  return (
    <Layout title={typeData.title} backPath="/classes">
      {typeData.subjects.map(subj => {
        const lines: string[] = [subj.teacher];
        if (isAnnual && subj.grade)      lines.push(subj.grade);
        if (!isAnnual && subj.nextClass) lines.push(subj.nextClass);

        const emojiUrl = subjectEmojis[subj.slug] || "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4d6.png";

        return (
          <div
            key={subj.slug}
            className="class-item"
            onClick={() => navigate(`/classes/${typeKey}/${subj.slug}`)}
          >
            <div
              className="class-item-icon"
              style={{ background: `linear-gradient(145deg, ${color}, ${color}bb)` }}
            >
              <img src={emojiUrl} width={28} height={28} alt={subj.name} />
            </div>
            <div className="class-item-text">
              <div className="class-item-title">{subj.name}</div>
              <div className="class-info">{lines.join("\n")}</div>
            </div>
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/2b05.png" width={14} height={14} alt="arrow" className="class-item-arrow" />
          </div>
        );
      })}
    </Layout>
  );
}
