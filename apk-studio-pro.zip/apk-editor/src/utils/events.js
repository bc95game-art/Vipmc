// events.js - Simple event emitter
window.APKStudio = window.APKStudio || {};
APKStudio.events = (() => {
  const listeners = {};
  return {
    on(event, fn) {
      if (!listeners[event]) listeners[event] = [];
      listeners[event].push(fn);
    },
    off(event, fn) {
      if (!listeners[event]) return;
      listeners[event] = listeners[event].filter(f => f !== fn);
    },
    emit(event, ...args) {
      (listeners[event] || []).forEach(fn => fn(...args));
    }
  };
})();
