import { useState, useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { getExam } from "../data";

export default function ExamFilesPage() {
  const { examId } = useParams<{ examId: string }>();
  const navigate   = useNavigate();
  const [search, setSearch] = useState("");
  const exam = getExam(examId);
  const total = 100;

  const items = useMemo(() =>
    Array.from({ length: total }, (_, i) => i + 1).filter(i =>
      search ? String(i).includes(search) : true
    ), [search]);

  return (
    <Layout title="فایل‌های مرتبط" subtitle={exam?.title} backPath={`/exams/${examId}`}>
      <div className="search-box">
        <img className="search-icon" src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f50d.png" width={18} height={18} alt="جستجو" />
        <input
          type="number" min={1} max={total}
          placeholder="شماره فایل را وارد کنید..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="search-input"
        />
        {search && (
          <button className="search-clear" onClick={() => setSearch("")}>✕</button>
        )}
      </div>
      <div className="pdf-list">
        {items.map(i => (
          <div
            key={i}
            className="pdf-item"
            onClick={() => navigate(`/exams/${examId}/files/${i}`)}
          >
            <span className="item-number">{i}</span>
            <span className="item-label">فایل</span>
          </div>
        ))}
        {items.length === 0 && <div className="empty-search">موردی یافت نشد</div>}
      </div>
    </Layout>
  );
}
