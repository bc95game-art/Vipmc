import { useState, useRef, useCallback, useEffect } from "react";

// ─── Android Bridge ────────────────────────────────────────────────────────────
declare global {
  interface Window {
    MazBridge?: {
      openPdf(assetPath: string, title: string): void;
      openVideo(assetPath: string, title: string): void;
      assetExists(assetPath: string): boolean;
      showToast(message: string): void;
      saveNote(key: string, value: string): void;
      getNote(key: string): string;
    };
  }
}

const bridge = (): Window["MazBridge"] | null =>
  typeof window !== "undefined" && window.MazBridge ? window.MazBridge : null;

function urlToAssetPath(url: string): string {
  return url.replace("file:///android_asset/", "");
}

function storageSet(key: string, value: string): void {
  try {
    const b = bridge();
    if (b) { b.saveNote(key, value); } else { localStorage.setItem(key, value); }
  } catch { /* silent */ }
}

function storageGet(key: string): string | null {
  try {
    const b = bridge();
    if (b) { const val = b.getNote(key); return val !== "" ? val : null; }
    else { return localStorage.getItem(key); }
  } catch { return null; }
}

// ─── CopyLinkButton ───────────────────────────────────────────────────────────
function CopyLinkButton({ url, label = "کپی آدرس فایل" }: { url: string; label?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    let ok = false;
    try {
      if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(url); ok = true; }
    } catch { /* fall through */ }
    if (!ok) {
      try {
        const ta = document.createElement("textarea");
        ta.value = url;
        Object.assign(ta.style, { position: "fixed", top: "0", left: "0", opacity: "0" });
        document.body.appendChild(ta); ta.focus(); ta.select();
        ok = document.execCommand("copy"); document.body.removeChild(ta);
      } catch { /* silent */ }
    }
    if (ok) { setCopied(true); setTimeout(() => setCopied(false), 2000); }
    else { window.prompt("کپی خودکار ممکن نشد — آدرس را با دست کپی کنید:", url); }
  }, [url]);

  return (
    <button type="button" className="copy-link-btn" onClick={handleCopy}>
      {copied
        ? <><img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/2705.png" width={14} height={14} alt="✓" /> آدرس کپی شد</>
        : <><img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4cb.png" width={14} height={14} alt="copy" /> {label}</>
      }
    </button>
  );
}

// ─── requestFullscreen ────────────────────────────────────────────────────────
function enterFullscreen(wrapperEl: HTMLElement) {
  const video = wrapperEl.querySelector("video") as HTMLVideoElement | null;
  if (video) {
    if ((video as any).webkitEnterFullscreen) { (video as any).webkitEnterFullscreen(); return; }
    if (video.requestFullscreen) { video.requestFullscreen().catch(() => {}); return; }
  }
  if (wrapperEl.requestFullscreen) { wrapperEl.requestFullscreen().catch(() => {}); }
  else if ((wrapperEl as any).webkitRequestFullscreen) { (wrapperEl as any).webkitRequestFullscreen(); }
}

// ─── VideoPlayer ──────────────────────────────────────────────────────────────
interface VideoPlayerProps {
  src: string;
  mediaKey: string;
  title?: string;
}

export function VideoPlayer({ src, mediaKey, title = "ویدیو" }: VideoPlayerProps) {
  const assetPath = urlToAssetPath(src);
  const hasBridge = !!bridge();

  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  // کنترل نمایش هدر ویدیو — با یک ضربه مخفی/نمایان
  const [showHeader, setShowHeader] = useState(true);

  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const savedKey = `video_pos_${mediaKey}`;

  useEffect(() => {
    setError(false);
    setLoading(true);
    setProgress(0);
    setShowHeader(true);
  }, [mediaKey]);

  const handleOpenNative = useCallback(() => {
    bridge()?.openVideo(assetPath, title);
  }, [assetPath, title]);

  // ─── حالت native ────────────────────────────────────────────────────────────
  if (hasBridge) {
    return (
      <div className="media-frame">
        <div className="media-header">
          <div className="media-header-icon">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f3ac.png" width={20} height={20} alt="video" />
          </div>
          <div className="media-header-text">
            <div className="media-header-title">{title}</div>
            <div className="media-header-sub">پخش در پلیر اختصاصی برنامه</div>
          </div>
        </div>
        <div className="native-launcher">
          <div className="native-icon">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/25b6.png" width={28} height={28} alt="play" />
          </div>
          <p className="native-hint">برای پخش ویدیو روی دکمه زیر بزنید</p>
          <button type="button" className="open-native-btn open-native-btn--video" onClick={handleOpenNative}>
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f3ac.png" width={18} height={18} alt="film" />
            پخش ویدیو در پلیر
          </button>
          <p className="native-path">{assetPath}</p>
        </div>
        <CopyLinkButton url={src} />
      </div>
    );
  }

  // ─── حالت web ────────────────────────────────────────────────────────────────
  const handleCanPlay = () => {
    setLoading(false);
    const saved = storageGet(savedKey);
    if (saved && videoRef.current) {
      const t = parseFloat(saved);
      if (t > 5) videoRef.current.currentTime = t;
    }
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const t = videoRef.current.currentTime;
    const d = videoRef.current.duration || 0;
    if (d > 0) setProgress(Math.round((t / d) * 100));
    if (Math.floor(t) % 5 === 0) storageSet(savedKey, String(t));
  };

  const handleFullscreen = () => {
    if (wrapperRef.current) enterFullscreen(wrapperRef.current);
  };

  // با ضربه روی ویدیو هدر مخفی/نمایان می‌شود
  const toggleHeader = () => setShowHeader(prev => !prev);

  return (
    <div className="media-frame">
      {/* هدر فقط وقتی showHeader=true نمایش داده می‌شود */}
      {showHeader && (
        <div className="media-header">
          <div className="media-header-icon">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f3ac.png" width={20} height={20} alt="video" />
          </div>
          <div className="media-header-text">
            <div className="media-header-title">{title}</div>
            <div className="media-header-sub">برای مخفی کردن عنوان روی ویدیو بزنید</div>
          </div>
        </div>
      )}

      <div className="video-wrapper" ref={wrapperRef}>
        {loading && !error && (
          <div className="media-loading">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/23f3.png" className="spin-icon" width={32} height={32} alt="loading" />
            <span>در حال بارگذاری ویدیو...</span>
          </div>
        )}

        {error ? (
          <div className="media-error">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/26a0.png" className="err-icon" width={32} height={32} alt="error" />
            <span>خطا در بارگذاری ویدیو</span>
            <span className="media-error-hint">{src}</span>
          </div>
        ) : (
          <video
            ref={videoRef}
            className="video-player"
            src={src}
            controls
            playsInline
            onCanPlay={handleCanPlay}
            onTimeUpdate={handleTimeUpdate}
            onError={() => setError(true)}
            style={{ display: loading ? "none" : "block" }}
            onClick={toggleHeader}
          />
        )}

        {!error && !loading && (
          <div className="video-controls-row">
            <div className="video-progress-bar">
              <div className="video-progress-fill" style={{ width: `${progress}%` }} />
            </div>
            <button type="button" className="fullscreen-btn" onClick={handleFullscreen}>
              <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4fa.png" width={16} height={16} alt="fullscreen" />
              تمام صفحه
            </button>
          </div>
        )}
      </div>

      <CopyLinkButton url={src} />
    </div>
  );
}

// ─── PdfPlayer ────────────────────────────────────────────────────────────────
interface PdfPlayerProps {
  src: string;
  mediaKey: string;
  title?: string;
  openLabel?: string;
}

export function PdfPlayer({ src, mediaKey, title = "جزوه", openLabel = "باز کردن PDF" }: PdfPlayerProps) {
  const assetPath = urlToAssetPath(src);
  const hasBridge = !!bridge();
  const [viewMode, setViewMode] = useState<"iframe" | "fallback">("iframe");
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const iframeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleOpenNative = useCallback(() => {
    bridge()?.openPdf(assetPath, title);
  }, [assetPath, title]);

  useEffect(() => {
    setIframeLoaded(false);
    if (hasBridge) { setViewMode("fallback"); }
    else {
      setViewMode("iframe");
      iframeTimerRef.current = setTimeout(() => setViewMode("fallback"), 5000);
    }
    return () => { if (iframeTimerRef.current) clearTimeout(iframeTimerRef.current); };
  }, [mediaKey, hasBridge]);

  const handleLoad = useCallback(() => {
    if (iframeTimerRef.current) clearTimeout(iframeTimerRef.current);
    setIframeLoaded(true);
  }, []);

  if (hasBridge) {
    return (
      <div className="media-frame">
        <div className="media-header">
          <div className="media-header-icon pdf">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c4.png" width={20} height={20} alt="pdf" />
          </div>
          <div className="media-header-text">
            <div className="media-header-title">{title}</div>
            <div className="media-header-sub">نمایش در پلیر اختصاصی برنامه</div>
          </div>
        </div>
        <div className="native-launcher native-launcher--pdf">
          <div className="native-icon native-icon--pdf">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c4.png" width={28} height={28} alt="pdf" />
          </div>
          <p className="native-hint">برای مشاهده جزوه روی دکمه زیر بزنید</p>
          <button type="button" className="open-native-btn open-native-btn--pdf" onClick={handleOpenNative}>
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f441.png" width={18} height={18} alt="view" />
            {openLabel}
          </button>
          <p className="native-path">{assetPath}</p>
        </div>
        <CopyLinkButton url={src} />
      </div>
    );
  }

  return (
    <div className="media-frame">
      <div className="media-header">
        <div className="media-header-icon pdf">
          <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c4.png" width={20} height={20} alt="pdf" />
        </div>
        <div className="media-header-text">
          <div className="media-header-title">{title}</div>
          <div className="media-header-sub">مشاهده آنلاین فایل PDF</div>
        </div>
      </div>

      <div className="pdf-wrapper">
        <a className="open-pdf-btn open-pdf-btn--primary" href={src} target="_blank" rel="noreferrer">
          <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c4.png" width={16} height={16} alt="pdf" />
          {openLabel}
        </a>

        {viewMode === "iframe" && (
          <div className="pdf-iframe-wrapper">
            {!iframeLoaded && (
              <div className="pdf-loading">
                <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/23f3.png" width={20} height={20} alt="loading" />
                در حال بارگذاری PDF...
              </div>
            )}
            <iframe
              key={mediaKey}
              className="pdf-viewer"
              src={src}
              title="نمایش PDF"
              onLoad={handleLoad}
              onError={() => setViewMode("fallback")}
              style={{ display: iframeLoaded ? "block" : "none" }}
            />
          </div>
        )}

        {viewMode === "fallback" && (
          <div className="pdf-fallback-box">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/2139.png" className="info-icon" width={26} height={26} alt="info" />
            <p>از دکمه بالا برای باز کردن PDF استفاده کنید.</p>
          </div>
        )}

        <CopyLinkButton url={src} />
      </div>
    </div>
  );
}

// ─── NoteBox ──────────────────────────────────────────────────────────────────
interface NoteBoxProps {
  noteKey: string;
  label?: string;
}

export function NoteBox({ noteKey, label = "یادداشت شما" }: NoteBoxProps) {
  const storageKey = `note_${noteKey}`;
  const [note, setNote] = useState("");
  const [saved, setSaved] = useState(false);
  const [charCount, setCharCount] = useState(0);

  useEffect(() => {
    const stored = storageGet(storageKey) ?? "";
    setNote(stored);
    setCharCount(stored.length);
  }, [storageKey]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNote(e.target.value);
    setCharCount(e.target.value.length);
  }, []);

  const handleSave = useCallback(() => {
    storageSet(storageKey, note);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }, [storageKey, note]);

  const handleClear = useCallback(() => {
    if (window.confirm("یادداشت پاک شود؟")) {
      setNote(""); setCharCount(0);
      try { localStorage.removeItem(storageKey); } catch { /* silent */ }
      storageSet(storageKey, "");
    }
  }, [storageKey]);

  return (
    <div className="note-box">
      <div className="note-box-header">
        <div className="note-box-label">
          <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4dd.png" width={14} height={14} alt="note" />
          {label}
        </div>
        {charCount > 0 && (
          <button className="note-clear-btn" onClick={handleClear} title="پاک کردن">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f5d1.png" width={14} height={14} alt="trash" />
          </button>
        )}
      </div>
      <textarea
        className="note-textarea"
        value={note}
        onChange={handleChange}
        placeholder="یادداشت خود را اینجا بنویسید..."
        rows={4}
      />
      <div className="note-footer">
        <span className="note-char-count">{charCount} کاراکتر</span>
        <button className="note-save-btn" onClick={handleSave}>
          {saved
            ? <><img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/2705.png" width={13} height={13} alt="✓" /> ذخیره شد!</>
            : <><img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4be.png" width={13} height={13} alt="save" /> ذخیره</>
          }
        </button>
      </div>
    </div>
  );
}

// ─── MediaNotAvailable ────────────────────────────────────────────────────────
export function MediaNotAvailable({ icon, message }: { icon?: string; message: string }) {
  return (
    <div className="not-available">
      <img
        src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/274c.png"
        width={32} height={32} alt="×"
        style={{ display: "block", margin: "0 auto 10px" }}
      />
      {message}
    </div>
  );
}

// alias برای سازگاری با صفحات قدیمی
export const PdfViewer = PdfPlayer;
