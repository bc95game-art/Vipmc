// apk.js — APK loading, parsing, and ZIP management
window.APKStudio = window.APKStudio || {};

APKStudio.apk = (() => {
  let _zip = null;
  let _fileName = '';
  let _modifiedFiles = {}; // path -> content

  const BINARY_EXTENSIONS = new Set([
    'png','jpg','jpeg','gif','webp','bmp','ico','tiff',
    'ttf','otf','woff','woff2','eot',
    'mp3','mp4','ogg','wav','aac','m4a','flac',
    'so','dex','arsc','keystore','jks','class',
    'zip','jar','aar','7z','gz','tar','bz2',
    'pdf','doc','docx','xls','xlsx','ppt','pptx',
    'db','sqlite','realm'
  ]);

  const TEXT_EXTENSIONS = new Set([
    'xml','json','txt','js','ts','java','kt','kts','py','rb','php',
    'html','htm','css','scss','sass','less',
    'gradle','properties','yaml','yml','toml','ini','conf','cfg',
    'md','markdown','rst','tex',
    'sh','bat','cmd','ps1',
    'smali','aidl','proto','thrift','graphql',
    'c','cpp','cc','h','hpp','cs','swift','go','rs',
    'sql','r','lua','perl','groovy',
    'pem','crt','cer','key',
    'gitignore','gitattributes','editorconfig','eslintrc','babelrc',
    'Makefile','Dockerfile','Vagrantfile',
    'MF','SF' // META-INF
  ]);

  const IMAGE_EXTENSIONS = new Set(['png','jpg','jpeg','gif','webp','bmp','ico','svg']);

  function isBinary(path) {
    const ext = path.split('.').pop()?.toLowerCase();
    return BINARY_EXTENSIONS.has(ext);
  }

  function isImage(path) {
    const ext = path.split('.').pop()?.toLowerCase();
    return IMAGE_EXTENSIONS.has(ext);
  }

  function isText(path) {
    const ext = path.split('.').pop()?.toLowerCase();
    if (TEXT_EXTENSIONS.has(ext)) return true;
    if (BINARY_EXTENSIONS.has(ext)) return false;
    // Check filename without extension
    const base = path.split('/').pop();
    const noExt = ['Makefile','Dockerfile','Vagrantfile','README','LICENSE','AUTHORS','CHANGELOG','TODO','NOTICE'];
    return noExt.includes(base);
  }

  function getFileIcon(path, isDir) {
    if (isDir) {
      const name = path.split('/').filter(Boolean).pop()?.toLowerCase() || '';
      if (name === 'res') return '🗂️';
      if (name === 'assets') return '📦';
      if (name === 'meta-inf') return '🔐';
      if (name === 'lib') return '🔧';
      if (name === 'kotlin') return '🟣';
      return '📁';
    }
    const ext = path.split('.').pop()?.toLowerCase();
    const icons = {
      'xml': '📄', 'json': '📋', 'java': '☕', 'kt': '🟣', 'kts': '🟣',
      'smali': '🔩', 'dex': '⚡', 'png': '🖼️', 'jpg': '🖼️', 'jpeg': '🖼️',
      'gif': '🖼️', 'webp': '🖼️', 'so': '⚙️', 'arsc': '📦', 'apk': '📱',
      'gradle': '🐘', 'properties': '⚙️', 'txt': '📝', 'md': '📝',
      'html': '🌐', 'css': '🎨', 'js': '📜', 'ts': '📘',
      'MF': '🔐', 'SF': '🔐',
    };
    return icons[ext] || '📄';
  }

  function getSyntaxLanguage(path) {
    const ext = path.split('.').pop()?.toLowerCase();
    const map = {
      'xml': 'xml', 'json': 'json', 'java': 'java', 'kt': 'kotlin', 'kts': 'kotlin',
      'smali': 'smali', 'gradle': 'groovy', 'properties': 'properties',
      'js': 'javascript', 'ts': 'typescript', 'html': 'html', 'css': 'css',
      'txt': 'text', 'md': 'markdown', 'yaml': 'yaml', 'yml': 'yaml',
      'sh': 'bash', 'py': 'python', 'MF': 'text', 'SF': 'text'
    };
    return map[ext] || 'text';
  }

  async function loadAPK(file) {
    _fileName = file.name;
    _modifiedFiles = {};
    const buffer = await file.arrayBuffer();
    _zip = await JSZip.loadAsync(buffer);
    return buildFileTree(_zip);
  }

  function buildFileTree(zip) {
    const tree = {};
    zip.forEach((relativePath, zipEntry) => {
      const parts = relativePath.split('/');
      let current = tree;
      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        if (!part) continue;
        if (i === parts.length - 1 && !zipEntry.dir) {
          current[part] = { _file: true, path: relativePath, entry: zipEntry };
        } else {
          if (!current[part]) current[part] = { _dir: true, path: parts.slice(0, i+1).join('/') + '/', children: {} };
          current = current[part].children || current[part];
        }
      }
    });
    return tree;
  }

  async function getFileContent(path) {
    if (_modifiedFiles[path] !== undefined) return _modifiedFiles[path];
    if (!_zip) throw new Error('APK not loaded');
    const entry = _zip.file(path);
    if (!entry) throw new Error(`File not found: ${path}`);

    if (isImage(path)) {
      const blob = await entry.async('blob');
      return URL.createObjectURL(blob);
    }

    if (isBinary(path) && !isText(path)) {
      return null; // signal binary
    }

    try {
      const text = await entry.async('string');
      return text;
    } catch (e) {
      return null; // binary fallback
    }
  }

  async function getFileSizeAndInfo(path) {
    if (!_zip) return null;
    const entry = _zip.file(path);
    if (!entry) return null;
    const data = await entry.async('uint8array');
    return {
      size: data.length,
      sizeFormatted: formatSize(data.length)
    };
  }

  function formatSize(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  }

  function saveFileContent(path, content) {
    _modifiedFiles[path] = content;
    if (_zip && _zip.file(path)) {
      _zip.file(path, content);
    }
  }

  async function searchInFiles(query, options = {}) {
    if (!_zip) return [];
    const results = [];
    const flags = options.caseSensitive ? 'g' : 'gi';
    let regex;
    try {
      regex = options.regex ? new RegExp(query, flags) : new RegExp(escapeRegex(query), flags);
    } catch (e) {
      return [];
    }

    const promises = [];
    _zip.forEach((path, entry) => {
      if (!entry.dir && isText(path)) {
        promises.push(
          entry.async('string').then(text => {
            const lines = text.split('\n');
            lines.forEach((line, idx) => {
              if (regex.test(line)) {
                regex.lastIndex = 0;
                results.push({ path, line: idx + 1, content: line.trim(), match: query });
              }
              regex.lastIndex = 0;
            });
          }).catch(() => {})
        );
      }
    });

    await Promise.all(promises);
    return results;
  }

  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  async function injectZip(zipBuffer, options = {}) {
    if (!_zip) throw new Error('APK not loaded');
    const injectZip = await JSZip.loadAsync(zipBuffer);
    const injectedFiles = [];

    injectZip.forEach((path, entry) => {
      if (!entry.dir) {
        const targetPath = path;
        if (!options.overwrite && _zip.file(targetPath)) return;
        _zip.file(targetPath, entry.async('arraybuffer').then(d => d));
        injectedFiles.push(targetPath);
      }
    });

    return injectedFiles;
  }

  async function buildAPK() {
    if (!_zip) throw new Error('APK not loaded');

    // Apply all modifications
    for (const [path, content] of Object.entries(_modifiedFiles)) {
      _zip.file(path, content);
    }

    const blob = await _zip.generateAsync({
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    }, (metadata) => {
      APKStudio.events.emit('buildProgress', metadata.percent);
    });

    return blob;
  }

  async function getAllFiles() {
    if (!_zip) return [];
    const files = [];
    _zip.forEach((path, entry) => {
      if (!entry.dir) files.push(path);
    });
    return files;
  }

  function getFileName() { return _fileName; }
  function isLoaded() { return _zip !== null; }
  function getModifiedFiles() { return Object.keys(_modifiedFiles); }
  function isModified(path) { return _modifiedFiles[path] !== undefined; }

  return {
    loadAPK, getFileContent, saveFileContent, buildAPK,
    searchInFiles, injectZip, getAllFiles,
    getFileName, isLoaded, getModifiedFiles, isModified,
    isBinary, isImage, isText, getFileIcon, getSyntaxLanguage,
    getFileSizeAndInfo, formatSize, buildFileTree
  };
})();
