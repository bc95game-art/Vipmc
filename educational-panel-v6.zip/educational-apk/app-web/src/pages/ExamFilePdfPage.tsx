import { useParams } from "react-router-dom";
import Layout from "../components/Layout";
import NoteBox from "../components/NoteBox";
import { PdfViewer, MediaNotAvailable } from "../components/MediaPlayer";
import { getExam } from "../data";
import { getExamFilePdfUrl } from "../mediaConfig";

export default function ExamFilePdfPage() {
  const { examId, index } = useParams<{ examId: string; index: string }>();

  const exam   = getExam(examId);
  const pdfUrl = examId && index ? getExamFilePdfUrl(examId, index) : null;

  return (
    <Layout
      title={`فایل ${index}`}
      subtitle={exam?.title}
      backPath={`/exams/${examId}/files`}
    >
      <div className="media-container">
        {pdfUrl
          ? <PdfViewer src={pdfUrl} mediaKey={`exam-file-${examId}-${index}`} openLabel="باز کردن فایل" />
          : <MediaNotAvailable message="فایل هنوز اضافه نشده است" />
        }
      </div>
      <NoteBox noteKey={`exam_file_${examId}_${index}`} label={`یادداشت فایل ${index}`} />
    </Layout>
  );
}
