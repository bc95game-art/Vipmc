import { useState, useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { getClassType } from "../data";

interface Props {
  mode: "sessions" | "notes";
}

export default function SessionListPage({ mode }: Props) {
  const { typeKey, slug } = useParams<{ typeKey: string; slug: string }>();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");

  const typeData    = getClassType(typeKey);
  const subject     = typeData?.subjects.find(s => s.slug === slug);
  const subjectName = subject?.name ?? "درس";

  const isSession  = mode === "sessions";
  const title      = isSession ? "جلسات برگزار شده" : "جزوات";
  const itemLabel  = isSession ? "جلسه" : "جزوه";
  const basePath   = isSession
    ? `/classes/${typeKey}/${slug}/sessions`
    : `/classes/${typeKey}/${slug}/notes`;

  const totalItems = 100;

  const items = useMemo(() => {
    return Array.from({ length: totalItems }, (_, i) => i + 1).filter(i =>
      search ? String(i).includes(search) : true
    );
  }, [search]);

  // بارگیری یادداشت‌های ذخیره‌شده
  const savedNotes = useMemo(() => {
    const keys: Set<number> = new Set();
    for (let i = 1; i <= totalItems; i++) {
      const k = isSession
        ? `note_video_${typeKey}_${slug}_${i}`
        : `note_pdf_${typeKey}_${slug}_${i}`;
      if (localStorage.getItem(k)) keys.add(i);
    }
    return keys;
  }, [typeKey, slug, isSession]);

  return (
    <Layout
      title={title}
      subtitle={subjectName}
      backPath={`/classes/${typeKey}/${slug}`}
    >
      {/* جستجو */}
      <div className="search-box">
        <i className="fas fa-search" />
        <input
          type="number"
          min={1}
          max={100}
          placeholder={`شماره ${itemLabel} را وارد کنید...`}
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="search-input"
        />
        {search && (
          <button className="search-clear" onClick={() => setSearch("")}>
            <i className="fas fa-times" />
          </button>
        )}
      </div>

      <div className={isSession ? "lesson-list" : "pdf-list"}>
        {items.map(i => (
          <div
            key={i}
            className={`${isSession ? "lesson-item" : "pdf-item"}${savedNotes.has(i) ? " has-note" : ""}`}
            onClick={() => navigate(`${basePath}/${i}`)}
          >
            <span className="item-number">{i}</span>
            <span className="item-label">{itemLabel}</span>
            {savedNotes.has(i) && (
              <i className="fas fa-sticky-note item-note-icon" title="یادداشت دارد" />
            )}
          </div>
        ))}
        {items.length === 0 && (
          <div className="empty-search">موردی یافت نشد</div>
        )}
      </div>
    </Layout>
  );
}
