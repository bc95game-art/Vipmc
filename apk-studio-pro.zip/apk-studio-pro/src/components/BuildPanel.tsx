import { useState } from "react";
import { Hammer, Download, AlertTriangle, AlertCircle, CheckCircle2, Loader2, ChevronDown, ChevronRight } from "lucide-react";
import { BuildError, ApkInfo, formatFileSize } from "@/lib/apk-utils";

interface BuildPanelProps {
  onBuild: () => Promise<{ blob: Blob; errors: BuildError[] }>;
  apkInfo?: ApkInfo;
  hasApk: boolean;
  modifiedCount: number;
}

export function BuildPanel({ onBuild, apkInfo, hasApk, modifiedCount }: BuildPanelProps) {
  const [building, setBuilding] = useState(false);
  const [buildResult, setBuildResult] = useState<{ blob: Blob; errors: BuildError[] } | null>(null);
  const [showErrors, setShowErrors] = useState(true);
  const [showWarnings, setShowWarnings] = useState(true);

  const handleBuild = async () => {
    setBuilding(true);
    setBuildResult(null);
    try {
      const result = await onBuild();
      setBuildResult(result);
    } catch (e) {
      setBuildResult({ blob: new Blob(), errors: [{ file: "", message: (e as Error).message, type: "error" }] });
    } finally {
      setBuilding(false);
    }
  };

  const handleDownload = () => {
    if (!buildResult?.blob || buildResult.blob.size === 0) return;
    const url = URL.createObjectURL(buildResult.blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = apkInfo?.name || "output.apk";
    a.click();
    URL.revokeObjectURL(url);
  };

  const errors = buildResult?.errors.filter((e) => e.type === "error") || [];
  const warnings = buildResult?.errors.filter((e) => e.type === "warning") || [];
  const buildSuccess = buildResult && errors.length === 0;

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] text-gray-300 overflow-y-auto">
      <div className="p-4 space-y-4">
        <div className="space-y-1">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Hammer size={14} className="text-[#569cd6]" />
            بازسازی APK
          </h3>
          <p className="text-xs text-gray-500">
            فایل‌های ویرایش‌شده را بسته‌بندی و خطاها را بررسی کنید
          </p>
        </div>

        {apkInfo && (
          <div className="bg-[#252526] rounded-lg p-3 space-y-2">
            <p className="text-xs text-gray-400 font-medium">اطلاعات APK</p>
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              {[
                ["نام", apkInfo.name],
                ["حجم", formatFileSize(apkInfo.size)],
                ["تعداد فایل", apkInfo.fileCount.toString()],
                ["Package", apkInfo.packageName || "—"],
                ["Version", apkInfo.versionName || "—"],
                ["Min SDK", apkInfo.minSdkVersion || "—"],
              ].map(([key, val]) => (
                <div key={key} className="flex justify-between gap-2">
                  <span className="text-gray-500">{key}</span>
                  <span className="text-gray-300 truncate font-mono">{val}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {modifiedCount > 0 && (
          <div className="flex items-center gap-2 p-2.5 bg-yellow-500/10 border border-yellow-500/30 rounded text-xs text-yellow-400">
            <AlertTriangle size={12} />
            {modifiedCount} فایل ویرایش‌نشده (ذخیره) وجود دارد
          </div>
        )}

        <button
          onClick={handleBuild}
          disabled={!hasApk || building}
          className="flex items-center justify-center gap-2 w-full py-3 bg-gradient-to-r from-[#007acc] to-[#005a9e] hover:from-[#005a9e] hover:to-[#004080] disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-lg transition-all shadow-lg"
        >
          {building ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              در حال بازسازی...
            </>
          ) : (
            <>
              <Hammer size={16} />
              ساخت APK
            </>
          )}
        </button>
      </div>

      {buildResult && (
        <div className="px-4 pb-4 space-y-3">
          <div className={`flex items-center gap-2 p-3 rounded-lg text-sm font-medium ${
            buildSuccess
              ? "bg-green-500/10 border border-green-500/30 text-green-400"
              : "bg-red-500/10 border border-red-500/30 text-red-400"
          }`}>
            {buildSuccess ? (
              <>
                <CheckCircle2 size={16} />
                ساخت موفق — آماده دانلود
              </>
            ) : (
              <>
                <AlertCircle size={16} />
                {errors.length} خطا یافت شد
              </>
            )}
          </div>

          {buildSuccess && buildResult.blob.size > 0 && (
            <button
              onClick={handleDownload}
              className="flex items-center justify-center gap-2 w-full py-2.5 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors"
            >
              <Download size={14} />
              دانلود APK ({formatFileSize(buildResult.blob.size)})
            </button>
          )}

          {errors.length > 0 && (
            <div className="space-y-1">
              <button
                onClick={() => setShowErrors(!showErrors)}
                className="flex items-center gap-1.5 text-xs text-red-400 font-medium"
              >
                {showErrors ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                خطاها ({errors.length})
              </button>
              {showErrors && (
                <div className="space-y-1">
                  {errors.map((err, i) => (
                    <ErrorItem key={i} error={err} />
                  ))}
                </div>
              )}
            </div>
          )}

          {warnings.length > 0 && (
            <div className="space-y-1">
              <button
                onClick={() => setShowWarnings(!showWarnings)}
                className="flex items-center gap-1.5 text-xs text-yellow-400 font-medium"
              >
                {showWarnings ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                هشدارها ({warnings.length})
              </button>
              {showWarnings && (
                <div className="space-y-1">
                  {warnings.map((warn, i) => (
                    <ErrorItem key={i} error={warn} />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ErrorItem({ error }: { error: BuildError }) {
  const isError = error.type === "error";
  return (
    <div className={`flex gap-2 p-2.5 rounded text-xs ${
      isError ? "bg-red-500/10 border border-red-500/20" : "bg-yellow-500/10 border border-yellow-500/20"
    }`}>
      {isError ? (
        <AlertCircle size={12} className="text-red-400 flex-shrink-0 mt-0.5" />
      ) : (
        <AlertTriangle size={12} className="text-yellow-400 flex-shrink-0 mt-0.5" />
      )}
      <div className="flex-1 min-w-0">
        {error.file && (
          <p className={`font-mono truncate ${isError ? "text-red-300" : "text-yellow-300"}`}>
            {error.file}{error.line ? `:${error.line}` : ""}
          </p>
        )}
        <p className={isError ? "text-red-200" : "text-yellow-200"}>{error.message}</p>
      </div>
    </div>
  );
}
