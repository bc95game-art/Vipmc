import { useState, useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { getFileBook } from "../data";

export default function TestListPage() {
  const { bookId } = useParams<{ bookId: string }>();
  const navigate   = useNavigate();
  const [search, setSearch] = useState("");
  const book = getFileBook(bookId);
  const total = 100;

  const items = useMemo(() =>
    Array.from({ length: total }, (_, i) => i + 1).filter(i =>
      search ? String(i).includes(search) : true
    ), [search]);

  return (
    <Layout title="تست‌ها" subtitle={book?.title} backPath="/files/tests">
      <div className="search-box">
        <i className="fas fa-search" />
        <input
          type="number" min={1} max={total}
          placeholder="شماره تست..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="search-input"
        />
        {search && (
          <button className="search-clear" onClick={() => setSearch("")}>
            <i className="fas fa-times" />
          </button>
        )}
      </div>
      <div className="pdf-list">
        {items.map(i => (
          <div
            key={i}
            className="pdf-item"
            onClick={() => navigate(`/files/tests/${bookId}/${i}`)}
          >
            <span className="item-number">{i}</span>
            <span className="item-label">تست</span>
          </div>
        ))}
        {items.length === 0 && <div className="empty-search">موردی یافت نشد</div>}
      </div>
    </Layout>
  );
}
