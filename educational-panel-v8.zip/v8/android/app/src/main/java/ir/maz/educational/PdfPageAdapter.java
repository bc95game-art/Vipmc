package ir.maz.educational;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PdfPageAdapter extends RecyclerView.Adapter<PdfPageAdapter.PageHolder> {

    private final List<Bitmap> pages;

    public PdfPageAdapter(List<Bitmap> pages) {
        this.pages = pages;
    }

    @NonNull
    @Override
    public PageHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                               .inflate(R.layout.item_pdf_page, parent, false);
        return new PageHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PageHolder holder, int position) {
        holder.imageView.setImageBitmap(pages.get(position));
        holder.tvPage.setText("صفحه " + (position + 1));
    }

    @Override
    public int getItemCount() { return pages.size(); }

    static class PageHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView tvPage;
        PageHolder(@NonNull View v) {
            super(v);
            imageView = v.findViewById(R.id.pageImage);
            tvPage    = v.findViewById(R.id.pageNumber);
        }
    }
}
