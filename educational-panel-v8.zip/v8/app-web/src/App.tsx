import { HashRouter, Routes, Route } from "react-router-dom";
import MainMenu           from "./pages/MainMenu";
import ClassesPage        from "./pages/ClassesPage";
import ClassTypePage      from "./pages/ClassTypePage";
import SubjectPage        from "./pages/SubjectPage";
import SessionListPage    from "./pages/SessionListPage";
import VideoPage          from "./pages/VideoPage";
import PdfPage            from "./pages/PdfPage";
import ExamsPage          from "./pages/ExamsPage";
import ExamDetailPage     from "./pages/ExamDetailPage";
import ExamSessionsPage   from "./pages/ExamSessionsPage";
import ExamPdfPage        from "./pages/ExamPdfPage";
import ExamAnswerPage     from "./pages/ExamAnswerPage";
import ExamFilesPage      from "./pages/ExamFilesPage";
import ExamFilePdfPage    from "./pages/ExamFilePdfPage";
import FilesPage          from "./pages/FilesPage";
import FileBooksPage      from "./pages/FileBooksPage";
import SimulatorListPage  from "./pages/SimulatorListPage";
import FilePdfPage        from "./pages/FilePdfPage";
import TestBooksPage      from "./pages/TestBooksPage";
import TestListPage       from "./pages/TestListPage";
import TestPdfPage        from "./pages/TestPdfPage";

export default function App() {
  return (
    <HashRouter>
      <Routes>
        {/* صفحه اصلی */}
        <Route path="/" element={<MainMenu />} />

        {/* کلاس‌ها */}
        <Route path="/classes"                                          element={<ClassesPage />} />
        <Route path="/classes/:typeKey"                                 element={<ClassTypePage />} />
        <Route path="/classes/:typeKey/:slug"                           element={<SubjectPage />} />
        <Route path="/classes/:typeKey/:slug/sessions"                  element={<SessionListPage mode="sessions" />} />
        <Route path="/classes/:typeKey/:slug/notes"                     element={<SessionListPage mode="notes" />} />
        <Route path="/classes/:typeKey/:slug/sessions/:index"           element={<VideoPage />} />
        <Route path="/classes/:typeKey/:slug/notes/:index"              element={<PdfPage />} />

        {/* آزمون‌ها */}
        <Route path="/exams"                                            element={<ExamsPage />} />
        <Route path="/exams/:examId"                                    element={<ExamDetailPage />} />
        <Route path="/exams/:examId/sessions"                           element={<ExamSessionsPage />} />
        <Route path="/exams/:examId/sessions/:index"                    element={<ExamPdfPage />} />
        <Route path="/exams/:examId/sessions/:index/answer"             element={<ExamAnswerPage />} />
        <Route path="/exams/:examId/files"                              element={<ExamFilesPage />} />
        <Route path="/exams/:examId/files/:index"                       element={<ExamFilePdfPage />} />

        {/* فایل‌ها */}
        <Route path="/files"                                            element={<FilesPage />} />
        <Route path="/files/simulator"                                  element={<FileBooksPage />} />
        <Route path="/files/simulator/:bookId"                          element={<SimulatorListPage />} />
        <Route path="/files/simulator/:bookId/:index"                   element={<FilePdfPage />} />
        <Route path="/files/tests"                                      element={<TestBooksPage />} />
        <Route path="/files/tests/:bookId"                              element={<TestListPage />} />
        <Route path="/files/tests/:bookId/:index"                       element={<TestPdfPage />} />
      </Routes>
    </HashRouter>
  );
}
