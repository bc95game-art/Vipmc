// ─── Interfaces ───────────────────────────────────────────────────────────────

export interface Subject {
  name: string;
  slug: string;
  teacher: string;
  /** فقط برای کلاس‌های سالیانه (typeKey A) */
  grade?: string;
  /** فقط برای امتحان نهایی (typeKey B) */
  nextClass?: string;
  /** آیا این درس جزوه PDF دارد (پیش‌فرض: true فقط برای typeKey A) */
  hasPdf?: boolean;
}

export interface ClassType {
  key: string;
  title: string;
  icon: string;
  subjects: Subject[];
  /** آیا این نوع کلاس جزوه (notes) هم دارد؟ */
  hasNotes: boolean;
}

export interface Exam {
  id: string;
  title: string;
  info: string;
}

// ─── Subjects ─────────────────────────────────────────────────────────────────

export const annualSubjects: Subject[] = [
  { name: "جامعه شناسی",     slug: "jam3e_shenasi",    teacher: "مژده طالبی",       grade: "یازدهم | انسانی" },
  { name: "دین و زندگی",     slug: "din_zendegi",      teacher: "فرزاد صائلی",      grade: "یازدهم | انسانی" },
  { name: "روان شناسی",      slug: "ravan_shenasi",    teacher: "مژده طالبی",       grade: "یازدهم | انسانی" },
  { name: "ریاضی و آمار",    slug: "riazi_va_amar",    teacher: "محمد یگانه",       grade: "یازدهم | انسانی" },
  { name: "زبان انگلیسی",    slug: "zaban_enghelisi",  teacher: "علی قیومی",        grade: "یازدهم | عمومی"  },
  { name: "عربی",            slug: "arabi",             teacher: "کیارش پورمهدی",    grade: "یازدهم | انسانی" },
  { name: "علوم و فنون ادبی",slug: "olum_va_fonun_adabi",teacher: "علیرضا بدیع",   grade: "یازدهم | انسانی" },
  { name: "فارسی",           slug: "farsi",             teacher: "علیرضا جعفری",    grade: "یازدهم | عمومی"  },
  { name: "فلسفه",           slug: "falsafe",           teacher: "مجتبی علی اکبر",  grade: "یازدهم | انسانی" },
  { name: "انسان و محیط زیست",slug:"ensan_va_mohit",   teacher: "اساتید ماز",       grade: "یازدهم | عمومی"  },
];

export const finalExamSubjects: Subject[] = [
  { name: "جامعه شناسی",     slug: "jam3e_shenasi",    teacher: "مژده طالب",       nextClass: "سه‌شنبه ۲۶ خرداد ۱۴:۰۰ تا ۱۶:۳۰" },
  { name: "دین و زندگی",     slug: "din_zendegi",      teacher: "فرزاد صائلی",    nextClass: "سه‌شنبه ۲۶ خرداد ۱۹:۰۰ تا ۲۰:۳۰" },
  { name: "روان شناسی",      slug: "ravan_shenasi",    teacher: "مژده طالب",       nextClass: "یک‌شنبه ۲۴ خرداد ۱۴:۰۰ تا ۱۶:۰۰" },
  { name: "ریاضی و آمار",    slug: "riazi_va_amar",    teacher: "محمد یگانه",      nextClass: "یک‌شنبه ۲۴ خرداد ۱۷:۱۵ تا ۱۹:۱۵" },
  { name: "زبان انگلیسی",    slug: "zaban_enghelisi",  teacher: "علی قیومی",       nextClass: "یک‌شنبه ۲۴ خرداد ۲۰:۴۵ تا ۲۲:۱۵" },
  { name: "عربی",            slug: "arabi",             teacher: "کیارش پورمهدی",  nextClass: "پنج‌شنبه ۲۸ خرداد ۱۴:۰۰ تا ۱۶:۳۰" },
  { name: "علوم و فنون ادبی",slug: "olum_va_fonun_adabi",teacher: "علیرضا بدیع",  nextClass: "شنبه ۲۳ خرداد ۱۴:۰۰ تا ۱۶:۳۰"   },
  { name: "فارسی",           slug: "farsi",             teacher: "علیرضا جعفری",   nextClass: "شنبه ۲۳ خرداد ۲۰:۴۵ تا ۲۲:۱۵"   },
  { name: "فلسفه",           slug: "falsafe",           teacher: "مجتبی علی اکبر", nextClass: "دوشنبه ۲۵ خرداد ۱۴:۰۰ تا ۱۶:۳۰" },
];

/** برای دوره‌های C, D, E — بدون تاریخ کلاس، فقط اسم درس و استاد عمومی */
const archiveSubjects: Subject[] = finalExamSubjects.map(({ name, slug }) => ({
  name,
  slug,
  teacher: "اساتید کلاس آنلاین ماز",
}));

// ─── Class Types ──────────────────────────────────────────────────────────────

export const classTypes: ClassType[] = [
  { key: "A", title: "کلاس‌های سالیانه",      icon: "fas fa-calendar-alt",   subjects: annualSubjects,   hasNotes: true  },
  { key: "B", title: "امتحان نهایی",           icon: "fas fa-clipboard-check",subjects: finalExamSubjects,hasNotes: true  },
  { key: "C", title: "دوره خط به خط",          icon: "fas fa-book",           subjects: archiveSubjects,  hasNotes: true  },
  { key: "D", title: "بانک ویدیویی نهایی",     icon: "fas fa-video",          subjects: archiveSubjects,  hasNotes: true  },
  { key: "E", title: "جمع‌بندی نیم‌سال اول",  icon: "fas fa-layer-group",    subjects: archiveSubjects,  hasNotes: true  },
  { key: "F", title: "ماز یار",                icon: "fas fa-robot",          subjects: [],               hasNotes: false },
  { key: "G", title: "سایر",                   icon: "fas fa-ellipsis-h",     subjects: [],               hasNotes: false },
];

// ─── Exams ────────────────────────────────────────────────────────────────────

export const exams: Exam[] = [
  { id: "maz",          title: "آزمون ماز (شروع از تابستان)",  info: "انسانی | یازدهم\nسال تحصیلی ۱۴۰۴-۱۴۰۵" },
  { id: "zoodbist_dey", title: "دوره زودبیست - دی ماه",        info: "انسانی | یازدهم\nسال تحصیلی ۱۴۰۴-۱۴۰۵" },
  { id: "zoodbist_sim", title: "زودبیست (شبیه‌ساز نهایی)",    info: "انسانی | یازدهم\nسال تحصیلی ۱۴۰۴-۱۴۰۵" },
];

// ─── File Books ───────────────────────────────────────────────────────────────

export const fileBooks: { id: string; title: string }[] = [
  { id: "jam3e_shenasi",     title: "جامعه شناسی"    },
  { id: "din_zendegi",       title: "دین و زندگی"    },
  { id: "ravan_shenasi",     title: "روان شناسی"     },
  { id: "riazi_va_amar",     title: "ریاضی و آمار"   },
  { id: "zaban_enghelisi",   title: "زبان انگلیسی"   },
  { id: "arabi",             title: "عربی"            },
  { id: "olum_va_fonun_adabi",title: "علوم و فنون ادبی"},
  { id: "farsi",             title: "فارسی"           },
  { id: "falsafe",           title: "فلسفه"           },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function getClassType(key: string | undefined): ClassType | undefined {
  return classTypes.find(t => t.key === key);
}

export function getExam(id: string | undefined): Exam | undefined {
  return exams.find(e => e.id === id);
}

export function getFileBook(id: string | undefined): { id: string; title: string } | undefined {
  return fileBooks.find(b => b.id === id);
}
