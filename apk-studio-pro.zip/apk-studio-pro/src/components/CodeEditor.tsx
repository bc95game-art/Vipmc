import { useRef, useEffect } from "react";
import MonacoEditor, { OnMount } from "@monaco-editor/react";
import { getLanguage, getFileIcon, getFileExtension } from "@/lib/apk-utils";
import { Save, RotateCcw, Download } from "lucide-react";

interface OpenTab {
  path: string;
  name: string;
  content: string;
  modified: boolean;
}

interface CodeEditorProps {
  tabs: OpenTab[];
  activeTab: string | null;
  onTabChange: (path: string) => void;
  onTabClose: (path: string) => void;
  onContentChange: (path: string, content: string) => void;
  onSave: (path: string) => void;
}

export function CodeEditor({ tabs, activeTab, onTabChange, onTabClose, onContentChange, onSave }: CodeEditorProps) {
  const editorRef = useRef<any>(null);

  const activeTabData = tabs.find((t) => t.path === activeTab);

  const handleEditorMount: OnMount = (editor) => {
    editorRef.current = editor;

    editor.addAction({
      id: "save-file",
      label: "Save File",
      keybindings: [
        (window as any).monaco?.KeyMod?.CtrlCmd | (window as any).monaco?.KeyCode?.KeyS,
      ],
      run: () => {
        if (activeTab) onSave(activeTab);
      },
    });
  };

  const handleDownload = () => {
    if (!activeTabData) return;
    const blob = new Blob([activeTabData.content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = activeTabData.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (tabs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-[#1e1e1e] text-gray-500 select-none">
        <div className="text-center space-y-3">
          <div className="text-6xl opacity-20">⚡</div>
          <h2 className="text-xl font-semibold text-gray-400">APK Studio Pro</h2>
          <p className="text-sm text-gray-500">یک فایل را از درخت فایل انتخاب کنید</p>
          <div className="mt-6 grid grid-cols-2 gap-3 text-xs text-gray-600 max-w-xs">
            <div className="bg-[#2d2d2d] rounded p-2 text-center">Ctrl+S ذخیره</div>
            <div className="bg-[#2d2d2d] rounded p-2 text-center">جستجوی پیشرفته</div>
            <div className="bg-[#2d2d2d] rounded p-2 text-center">ویرایش XML</div>
            <div className="bg-[#2d2d2d] rounded p-2 text-center">تزریق پروژه</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e]">
      <div className="flex items-center bg-[#252526] border-b border-[#1e1e1e] overflow-x-auto scrollbar-thin">
        {tabs.map((tab) => {
          const icon = getFileIcon({ name: tab.name, path: tab.path, size: 0, isDirectory: false });
          return (
            <div
              key={tab.path}
              onClick={() => onTabChange(tab.path)}
              className={`flex items-center gap-1.5 px-4 py-2 cursor-pointer border-r border-[#1e1e1e] min-w-0 max-w-[180px] flex-shrink-0 group transition-colors ${
                activeTab === tab.path
                  ? "bg-[#1e1e1e] text-white border-t-2 border-t-[#007acc]"
                  : "text-gray-400 hover:text-gray-300 hover:bg-[#2d2d2d]"
              }`}
            >
              <span className="text-xs">{icon}</span>
              <span className="text-xs truncate flex-1">{tab.name}</span>
              {tab.modified && <span className="text-yellow-400 text-xs">●</span>}
              <button
                onClick={(e) => { e.stopPropagation(); onTabClose(tab.path); }}
                className="opacity-0 group-hover:opacity-100 hover:text-white p-0.5 rounded transition-opacity"
              >
                ×
              </button>
            </div>
          );
        })}
      </div>

      {activeTabData && (
        <div className="flex items-center gap-2 px-3 py-1 bg-[#252526] border-b border-[#1e1e1e]">
          <span className="text-xs text-gray-500 flex-1 truncate">{activeTabData.path}</span>
          <button
            onClick={() => onSave(activeTabData.path)}
            disabled={!activeTabData.modified}
            className="flex items-center gap-1 text-xs px-2 py-0.5 bg-[#007acc] hover:bg-[#005a9e] disabled:opacity-40 disabled:cursor-not-allowed text-white rounded transition-colors"
          >
            <Save size={10} />
            ذخیره
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1 text-xs px-2 py-0.5 bg-[#2d2d2d] hover:bg-[#3d3d3d] text-gray-300 rounded transition-colors"
          >
            <Download size={10} />
            دانلود
          </button>
        </div>
      )}

      <div className="flex-1 overflow-hidden">
        {activeTabData ? (
          <MonacoEditor
            key={activeTabData.path}
            height="100%"
            language={getLanguage(activeTabData.name)}
            value={activeTabData.content}
            theme="vs-dark"
            onMount={handleEditorMount}
            onChange={(value) => onContentChange(activeTabData.path, value || "")}
            options={{
              fontSize: 13,
              fontFamily: "'JetBrains Mono', 'Cascadia Code', 'Fira Code', Consolas, monospace",
              fontLigatures: true,
              lineNumbers: "on",
              minimap: { enabled: true },
              scrollBeyondLastLine: false,
              wordWrap: "on",
              automaticLayout: true,
              tabSize: 2,
              insertSpaces: true,
              renderLineHighlight: "all",
              cursorBlinking: "smooth",
              smoothScrolling: true,
              formatOnPaste: true,
              formatOnType: true,
              bracketPairColorization: { enabled: true },
              padding: { top: 8 },
            }}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500 text-sm">
            فایل باینری — قابل ویرایش متنی نیست
          </div>
        )}
      </div>
    </div>
  );
}
