import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { fileBooks } from "../data";

const subjectEmojis: Record<string, string> = {
  jam3e_shenasi:       "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f465.png",
  din_zendegi:         "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/2b50.png",
  ravan_shenasi:       "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f9e0.png",
  riazi_va_amar:       "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4ca.png",
  zaban_enghelisi:     "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f1ec-1f1e7.png",
  arabi:               "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4d6.png",
  olum_va_fonun_adabi: "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/270f.png",
  farsi:               "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f58a.png",
  falsafe:             "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f914.png",
};

export default function FileBooksPage() {
  const navigate = useNavigate();

  return (
    <Layout title="شبیه‌ساز نهایی" backPath="/files">
      {fileBooks.map((book) => (
        <div
          key={book.id}
          className="class-item"
          onClick={() => navigate(`/files/simulator/${book.id}`)}
        >
          <div
            className="class-item-icon"
            style={{ background: "linear-gradient(145deg, #2f6f3e, #1a4829)" }}
          >
            <img
              src={subjectEmojis[book.id] || "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4d6.png"}
              width={28} height={28} alt={book.title}
            />
          </div>
          <div className="class-item-text">
            <div className="class-item-title">{book.title}</div>
            <div className="class-info">آزمون‌های شبیه‌ساز</div>
          </div>
          <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/2b05.png" width={14} height={14} alt="arrow" className="class-item-arrow" />
        </div>
      ))}
    </Layout>
  );
}
