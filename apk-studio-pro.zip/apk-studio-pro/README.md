# APK Studio Pro

  ویرایشگر پیشرفته فایل‌های APK اندروید — ساخته‌شده با React + Vite

  ## قابلیت‌ها

  - 📁 **درخت فایل کامل** — مشاهده تمام فایل‌های داخل APK با آیکون هر نوع
  - ⚡ **ویرایشگر Monaco** — همان موتور VS Code با Syntax Highlighting (XML، Java، Smali، Kotlin، JSON...)
  - 🔍 **جستجوی پیشرفته** — جستجو در تمام فایل‌های متنی با پشتیبانی از Regex و فیلتر نوع فایل
  - 📦 **تزریق پروژه ZIP** — وارد کردن فایل‌های پروژه از zip به داخل APK
  - 🔨 **بازسازی APK** — بررسی خطاها و دانلود APK ویرایش‌شده

  ## نصب و اجرا

  ```bash
  npm install
  npm run dev
  ```

  یا با pnpm:

  ```bash
  pnpm install
  pnpm dev
  ```

  ## استک فنی

  - React 18 + TypeScript
  - Vite (bundler)
  - Monaco Editor (VS Code engine)
  - JSZip (APK/ZIP handling)
  - Tailwind CSS + Radix UI
  - react-resizable-panels

  ## نحوه استفاده

  1. فایل APK را drag & drop کنید یا دکمه بارگذاری را بزنید
  2. روی فایل‌های متنی در درخت فایل کلیک کنید تا در ویرایشگر باز شوند
  3. تغییرات را با **Ctrl+S** ذخیره کنید
  4. برای جستجو، آیکون 🔍 در نوار کناری را بزنید
  5. برای تزریق پروژه zip، آیکون 📁+ را بزنید
  6. برای ساخت APK نهایی، آیکون 🔨 را بزنید

  ## نکته

  APK یک فایل ZIP است. این ابزار محتوای آن را استخراج، ویرایش، و دوباره بسته‌بندی می‌کند.
  برای disassemble کامل Smali نیاز به apktool دارید.

  ## License

  MIT
  