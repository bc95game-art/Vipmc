package ir.maz.educational;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfViewerActivity extends AppCompatActivity {

    private PdfRenderer pdfRenderer;
    private ParcelFileDescriptor pfd;
    private RecyclerView recyclerView;
    private TextView tvTitle, tvPageInfo;
    private ProgressBar progressBar;
    private int totalPages = 0;

    // FIX: thread pool محدود به ۲ — جلوگیری از race condition و OOM هنگام scroll سریع
    private final ExecutorService renderExecutor = Executors.newFixedThreadPool(2);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full-screen immersive
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_FULLSCREEN
        );

        setContentView(R.layout.activity_pdf_viewer);

        tvTitle     = findViewById(R.id.tvPdfTitle);
        tvPageInfo  = findViewById(R.id.tvPageInfo);
        progressBar = findViewById(R.id.pdfProgressBar);
        recyclerView = findViewById(R.id.pdfRecyclerView);

        String pdfPath  = getIntent().getStringExtra("pdf_path");
        String pdfTitle = getIntent().getStringExtra("pdf_title");

        tvTitle.setText(pdfTitle != null ? pdfTitle : "PDF");

        // Back button
        findViewById(R.id.btnPdfBack).setOnClickListener(v -> finish());

        if (pdfPath == null) {
            showError("مسیر فایل نامعتبر است");
            return;
        }

        loadPdf(pdfPath);
    }

    private void loadPdf(String path) {
        progressBar.setVisibility(View.VISIBLE);

        renderExecutor.execute(() -> {
            try {
                File file = new File(path);
                pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                pdfRenderer = new PdfRenderer(pfd);
                totalPages  = pdfRenderer.getPageCount();

                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    tvPageInfo.setText("تعداد صفحات: " + totalPages);

                    // Lazy adapter: هر صفحه هنگام نیاز رندر می‌شود (رفع OOM)
                    recyclerView.setLayoutManager(new LinearLayoutManager(this));
                    recyclerView.setRecycledViewPool(new RecyclerView.RecycledViewPool());
                    recyclerView.setAdapter(new LazyPdfAdapter());
                });

            } catch (IOException e) {
                runOnUiThread(() -> showError("خطا در بارگذاری PDF: " + e.getMessage()));
            }
        });
    }

    // ─── Lazy RecyclerView Adapter ────────────────────────────────────────────
    // هر صفحه فقط وقتی وارد دید می‌شود رندر می‌شود؛
    // وقتی از دید خارج شود Bitmap آزاد می‌شود.

    private class LazyPdfAdapter extends RecyclerView.Adapter<LazyPdfAdapter.PageHolder> {

        @Override
        public PageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            ImageView iv = new ImageView(PdfViewerActivity.this);
            int screenW = getResources().getDisplayMetrics().widthPixels;
            // ارتفاع اولیه — نسبت A4 تقریبی
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (int) (screenW * 1.414f)
            );
            iv.setLayoutParams(lp);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setBackgroundColor(Color.WHITE);
            return new PageHolder(iv);
        }

        @Override
        public void onBindViewHolder(PageHolder holder, int position) {
            holder.render(position);
        }

        @Override
        public void onViewRecycled(PageHolder holder) {
            // آزاد کردن Bitmap وقتی آیتم از دید خارج می‌شود
            holder.recycleBitmap();
        }

        @Override
        public int getItemCount() { return totalPages; }

        class PageHolder extends RecyclerView.ViewHolder {
            ImageView imageView;
            // FIX: volatile برای دیده شدن صحیح بین thread‌ها
            volatile Bitmap currentBitmap = null;

            PageHolder(ImageView iv) {
                super(iv);
                imageView = iv;
            }

            void recycleBitmap() {
                Bitmap old = currentBitmap;
                currentBitmap = null;
                if (old != null && !old.isRecycled()) old.recycle();
                imageView.setImageBitmap(null);
            }

            void render(int pageIndex) {
                // FIX: از renderExecutor (thread pool) به جای new Thread استفاده می‌شود
                renderExecutor.execute(() -> {
                    Bitmap bmp = renderPage(pageIndex);
                    runOnUiThread(() -> {
                        // FIX: بررسی می‌شود که holder هنوز همین صفحه را نمایش می‌دهد
                        if (getBindingAdapterPosition() == pageIndex) {
                            Bitmap old = currentBitmap;
                            currentBitmap = bmp;
                            imageView.setImageBitmap(bmp);
                            if (old != null && !old.isRecycled()) old.recycle();
                        } else if (bmp != null && !bmp.isRecycled()) {
                            bmp.recycle();
                        }
                    });
                });
            }
        }
    }

    /** رندر یک صفحه با synchronized (PdfRenderer thread-safe نیست) */
    private synchronized Bitmap renderPage(int pageIndex) {
        if (pdfRenderer == null) return null;
        try {
            PdfRenderer.Page page = pdfRenderer.openPage(pageIndex);
            int screenW = getResources().getDisplayMetrics().widthPixels;
            float scale = (float) screenW / page.getWidth();
            int w = screenW;
            int h = (int) (page.getHeight() * scale);

            Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565); // RGB_565 = نصف حافظه ARGB_8888
            Canvas canvas = new Canvas(bmp);
            canvas.drawColor(Color.WHITE);
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            page.close();
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }

    private void showError(String msg) {
        progressBar.setVisibility(View.GONE);
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        renderExecutor.shutdownNow(); // FIX: executor را در onDestroy خاموش کن
        try {
            if (pdfRenderer != null) { pdfRenderer.close(); pdfRenderer = null; }
            if (pfd != null) { pfd.close(); pfd = null; }
        } catch (IOException ignored) {}
    }
}
