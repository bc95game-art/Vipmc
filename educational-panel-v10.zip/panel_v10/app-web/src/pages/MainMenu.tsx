import { useNavigate } from "react-router-dom";

const menuItems = [
  { path: "/classes", emoji: "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4da.png", label: "کلاس‌ها",  color: "#2f6f3e" },
  { path: "/exams",   emoji: "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4dd.png", label: "آزمون‌ها", color: "#9b111e" },
  { path: "/files",   emoji: "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c2.png", label: "فایل‌ها",  color: "#c9a227" },
];

export default function MainMenu() {
  const navigate = useNavigate();

  return (
    <div className="layout-body">
      <div className="card home-card">
        {/* هدر اصلی */}
        <div className="home-header">
          <div className="home-logo">
            <img
              src="assets/imogiapp/imogi.png"
              alt="لوگو"
              onError={(e) => {
                const t = e.currentTarget;
                t.style.display = "none";
                const parent = t.parentElement!;
                const span = document.createElement("span");
                span.className = "home-logo-emoji";
                span.textContent = "🎓";
                parent.appendChild(span);
              }}
            />
          </div>
          <h1 className="home-title">پنل آموزشی</h1>
          <p className="home-subtitle">کلاس آنلاین ماز</p>
        </div>

        {/* منوی اصلی */}
        <div className="main-menu-grid">
          {menuItems.map(item => (
            <button
              key={item.path}
              className="main-button"
              onClick={() => navigate(item.path)}
            >
              <div className="main-button-icon">
                <img src={item.emoji} alt={item.label} width={40} height={40} />
              </div>
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        {/* footer */}
        <div className="home-footer">
          <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f6e1.png" width={14} height={14} alt="shield" />
          <span>نسخه ۱۰ — دسترسی آفلاین کامل</span>
        </div>
      </div>
    </div>
  );
}
