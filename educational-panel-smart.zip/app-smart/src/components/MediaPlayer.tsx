import { useState, useRef, useCallback, useEffect } from "react";

// ─── CopyLinkButton ──────────────────────────────────────────────────────────

interface CopyLinkButtonProps {
  url: string;
  label?: string;
}

function CopyLinkButton({ url, label = "کپی آدرس فایل" }: CopyLinkButtonProps) {
  const [copied, setCopied] = useState(false);

  const legacyCopy = (text: string): boolean => {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      Object.assign(ta.style, { position: "fixed", top: "0", left: "0", opacity: "0" });
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch {
      return false;
    }
  };

  const handleCopy = useCallback(async () => {
    let ok = false;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(url);
        ok = true;
      }
    } catch { /* fall through */ }

    if (!ok) ok = legacyCopy(url);

    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } else {
      window.prompt("کپی خودکار ممکن نشد — آدرس را با دست کپی کنید:", url);
    }
  }, [url]);

  return (
    <button type="button" className="copy-link-btn" onClick={handleCopy}>
      {copied
        ? <><i className="fas fa-check" /> آدرس کپی شد</>
        : <><i className="fas fa-copy" /> {label}</>
      }
    </button>
  );
}

// ─── requestFullscreen helper ────────────────────────────────────────────────

function enterFullscreen(wrapperEl: HTMLElement) {
  const video = wrapperEl.querySelector("video") as HTMLVideoElement | null;
  if (video) {
    if ((video as any).webkitEnterFullscreen) {
      (video as any).webkitEnterFullscreen();
      return;
    }
    if (video.requestFullscreen) {
      video.requestFullscreen().catch(() => {});
      return;
    }
  }

  if (wrapperEl.requestFullscreen) {
    wrapperEl.requestFullscreen().catch(() => {});
  } else if ((wrapperEl as any).webkitRequestFullscreen) {
    (wrapperEl as any).webkitRequestFullscreen();
  }
}

// ─── VideoPlayer ─────────────────────────────────────────────────────────────

interface VideoPlayerProps {
  src: string;
  mediaKey: string;
}

export function VideoPlayer({ src, mediaKey }: VideoPlayerProps) {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // بازیابی جایگاه پخش از localStorage
  const savedKey = `video_pos_${mediaKey}`;

  useEffect(() => {
    setError(false);
    setLoading(true);
    setProgress(0);
  }, [mediaKey]);

  const handleCanPlay = useCallback(() => {
    setLoading(false);
    // بازیابی جایگاه ذخیره‌شده
    const saved = localStorage.getItem(savedKey);
    if (saved && videoRef.current) {
      const t = parseFloat(saved);
      if (t > 5) videoRef.current.currentTime = t;
    }
  }, [savedKey]);

  const handleTimeUpdate = useCallback(() => {
    if (videoRef.current) {
      const t = videoRef.current.currentTime;
      const d = videoRef.current.duration || 0;
      if (d > 0) setProgress(Math.round((t / d) * 100));
      // ذخیره هر ۵ ثانیه
      if (Math.floor(t) % 5 === 0) {
        localStorage.setItem(savedKey, String(t));
      }
    }
  }, [savedKey]);

  const handleFullscreen = useCallback(() => {
    if (wrapperRef.current) enterFullscreen(wrapperRef.current);
  }, []);

  const handleError = useCallback(() => {
    setError(true);
    setLoading(false);
  }, []);

  return (
    <div className="video-wrapper" ref={wrapperRef}>
      {loading && !error && (
        <div className="media-loading">
          <i className="fas fa-spinner fa-spin" />
          <span>در حال بارگذاری ویدیو...</span>
        </div>
      )}

      {error ? (
        <div className="media-error">
          <i className="fas fa-triangle-exclamation" />
          <span>خطا در بارگذاری ویدیو</span>
          <span className="media-error-hint">اتصال یا مسیر فایل را بررسی کنید</span>
          <CopyLinkButton url={src} label="کپی آدرس برای بررسی" />
        </div>
      ) : (
        <video
          ref={videoRef}
          key={mediaKey}
          className="video-player"
          controls
          preload="metadata"
          playsInline
          webkit-playsinline="true"
          x5-playsinline="true"
          x5-video-player-type="h5"
          x5-video-player-fullscreen="true"
          onCanPlay={handleCanPlay}
          onTimeUpdate={handleTimeUpdate}
          onError={handleError}
          style={{ display: loading ? "none" : "block" }}
        >
          <source src={src} type="video/mp4" />
          مرورگر شما از پخش ویدیو پشتیبانی نمی‌کند.
        </video>
      )}

      {!error && !loading && (
        <>
          {/* نوار پیشرفت */}
          <div className="video-progress-bar">
            <div className="video-progress-fill" style={{ width: `${progress}%` }} />
          </div>

          <button
            type="button"
            className="fullscreen-btn"
            onClick={handleFullscreen}
            title="تمام صفحه"
          >
            <i className="fas fa-expand" /> تمام صفحه
          </button>
        </>
      )}

      {!error && <CopyLinkButton url={src} />}
    </div>
  );
}

// ─── PdfViewer ───────────────────────────────────────────────────────────────
// بهینه‌شده برای Android WebView + fallback کامل

interface PdfViewerProps {
  src: string;
  mediaKey: string;
  openLabel?: string;
}

export function PdfViewer({ src, mediaKey, openLabel = "باز کردن جزوه" }: PdfViewerProps) {
  const [viewMode, setViewMode] = useState<"auto" | "iframe" | "fallback">("auto");
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const [iframeError, setIframeError]   = useState(false);
  const iframeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const isAndroid = /android/i.test(navigator.userAgent);
  const isFileUrl  = src.startsWith("file://");

  // در Android با file:// → مستقیم به fallback
  useEffect(() => {
    setIframeLoaded(false);
    setIframeError(false);
    if (isAndroid && isFileUrl) {
      setViewMode("fallback");
    } else {
      setViewMode("auto");
      // timeout اگر iframe بعد از ۵ ثانیه لود نشد
      iframeTimerRef.current = setTimeout(() => {
        setIframeError(true);
        setViewMode("fallback");
      }, 5000);
    }
    return () => {
      if (iframeTimerRef.current) clearTimeout(iframeTimerRef.current);
    };
  }, [mediaKey, isAndroid, isFileUrl]);

  const handleLoad = useCallback(() => {
    if (iframeTimerRef.current) clearTimeout(iframeTimerRef.current);
    setIframeLoaded(true);
    setIframeError(false);
    setViewMode("iframe");
  }, []);

  const handleIframeError = useCallback(() => {
    if (iframeTimerRef.current) clearTimeout(iframeTimerRef.current);
    setIframeError(true);
    setViewMode("fallback");
  }, []);

  const handleFullscreen = useCallback(() => {
    if (!wrapperRef.current) return;
    const iframe = wrapperRef.current.querySelector("iframe") as HTMLIFrameElement | null;
    const target = iframe ?? wrapperRef.current;
    if (target.requestFullscreen) {
      target.requestFullscreen().catch(() => {});
    } else if ((target as any).webkitRequestFullscreen) {
      (target as any).webkitRequestFullscreen();
    }
  }, []);

  return (
    <div className="pdf-wrapper" ref={wrapperRef}>
      {/* دکمه اصلی باز کردن — همیشه نمایش داده می‌شود */}
      <a
        className="open-pdf-btn open-pdf-btn--primary"
        href={src}
        target="_blank"
        rel="noreferrer"
      >
        <i className="fas fa-file-pdf" /> {openLabel}
      </a>

      {/* نمایش iframe (فقط غیر‌Android یا https) */}
      {viewMode !== "fallback" && !iframeError && (
        <div className="pdf-iframe-wrapper">
          {!iframeLoaded && (
            <div className="pdf-loading">
              <i className="fas fa-spinner fa-spin" />
              در حال بارگذاری PDF...
            </div>
          )}
          <iframe
            key={mediaKey}
            className="pdf-viewer"
            src={src}
            title="نمایش PDF"
            onLoad={handleLoad}
            onError={handleIframeError}
            style={{ display: iframeLoaded ? "block" : "none" }}
          />
        </div>
      )}

      {/* حالت fallback — دستورالعمل واضح */}
      {viewMode === "fallback" && (
        <div className="pdf-fallback-box">
          <i className="fas fa-info-circle" />
          <p>برای مشاهده PDF از دکمه بالا استفاده کنید.</p>
          <p className="pdf-fallback-hint">
            فایل در ویوور سیستمی باز می‌شود.
          </p>
        </div>
      )}

      <div className="pdf-actions-row">
        {iframeLoaded && (
          <button
            type="button"
            className="fullscreen-btn"
            onClick={handleFullscreen}
            title="تمام صفحه"
          >
            <i className="fas fa-expand" /> تمام صفحه
          </button>
        )}
        <CopyLinkButton url={src} />
      </div>
    </div>
  );
}

// ─── MediaNotAvailable ───────────────────────────────────────────────────────

interface MediaNotAvailableProps {
  icon?: string;
  message: string;
}

export function MediaNotAvailable({ icon = "fas fa-file-circle-xmark", message }: MediaNotAvailableProps) {
  return (
    <div className="not-available">
      <i className={icon} style={{ fontSize: 28, marginBottom: 10, display: "block" }} />
      {message}
    </div>
  );
}
