// inject.js — ZIP project injection into APK
window.APKStudio = window.APKStudio || {};

APKStudio.inject = (() => {
  let _zipBuffer = null;
  let _zipName = '';
  let _zipFiles = [];

  const panel = () => document.getElementById('injectPanel');
  const dropZone = () => document.getElementById('injectDropZone');
  const fileInfo = () => document.getElementById('injectFileInfo');
  const fileTree = () => document.getElementById('injectFileTree');
  const doInjectBtn = () => document.getElementById('doInjectBtn');
  const injectBtn = () => document.getElementById('injectBtn');

  function init() {
    injectBtn()?.addEventListener('click', openPanel);
    document.getElementById('closeInjectPanel')?.addEventListener('click', closePanel);
    document.getElementById('zipInjectInput')?.addEventListener('change', onFileInput);

    const dz = dropZone();
    if (dz) {
      dz.addEventListener('click', () => document.getElementById('zipInjectInput').click());
      dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag-over'); });
      dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
      dz.addEventListener('drop', e => {
        e.preventDefault();
        dz.classList.remove('drag-over');
        const file = e.dataTransfer.files[0];
        if (file && file.name.endsWith('.zip')) loadZip(file);
        else APKStudio.ui.toast('فقط فایل‌های .zip مجاز هستند', 'error');
      });
    }

    doInjectBtn()?.addEventListener('click', doInject);
  }

  function openPanel() {
    if (!APKStudio.apk.isLoaded()) {
      APKStudio.ui.toast('ابتدا یک APK بارگذاری کنید', 'error');
      return;
    }
    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.id = 'injectOverlay';
    overlay.addEventListener('click', closePanel);
    document.body.appendChild(overlay);
    panel().style.display = 'flex';
  }

  function closePanel() {
    panel().style.display = 'none';
    document.getElementById('injectOverlay')?.remove();
  }

  async function onFileInput(e) {
    const file = e.target.files[0];
    if (!file) return;
    await loadZip(file);
    e.target.value = '';
  }

  async function loadZip(file) {
    _zipName = file.name;
    try {
      _zipBuffer = await file.arrayBuffer();
      const zip = await JSZip.loadAsync(_zipBuffer);
      _zipFiles = [];
      zip.forEach((path, entry) => {
        if (!entry.dir) _zipFiles.push(path);
      });

      // Update UI
      document.getElementById('injectFileName').textContent = _zipName;
      document.getElementById('injectFileSize').textContent = APKStudio.apk.formatSize(file.size);

      // Show file tree
      const treeEl = fileTree();
      treeEl.innerHTML = _zipFiles.map(f =>
        `<div class="tree-file">${getFileIcon(f)} ${f}</div>`
      ).join('');

      fileInfo().style.display = 'block';
      doInjectBtn().disabled = false;

      APKStudio.ui.toast(`ZIP بارگذاری شد - ${_zipFiles.length} فایل`, 'success');
    } catch (e) {
      APKStudio.ui.toast('خطا در بارگذاری ZIP: ' + e.message, 'error');
    }
  }

  function getFileIcon(path) {
    const ext = path.split('.').pop()?.toLowerCase();
    const icons = { xml: '📄', json: '📋', java: '☕', kt: '🟣', smali: '🔩', png: '🖼️', jpg: '🖼️', so: '⚙️' };
    return icons[ext] || '📄';
  }

  async function doInject() {
    if (!_zipBuffer || !APKStudio.apk.isLoaded()) return;

    const overwrite = document.getElementById('overwriteFiles').checked;
    const verifyHash = document.getElementById('verifyHash').checked;

    const btn = doInjectBtn();
    btn.disabled = true;
    btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px;animation:spin 1s linear infinite"><path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" stroke-dasharray="60" stroke-dashoffset="60"/></svg> در حال تزریق...`;

    try {
      let hashOk = true;
      if (verifyHash) {
        const hash = await computeHash(_zipBuffer);
        APKStudio.ui.toast(`هش SHA-256: ${hash.substring(0,16)}...`, 'info');
        // In real app: compare against known hash
        hashOk = true; // assume ok
      }

      if (!hashOk) {
        APKStudio.ui.toast('تأیید هش ناموفق بود', 'error');
        return;
      }

      const injected = await APKStudio.apk.injectZip(_zipBuffer, { overwrite });

      // Update file tree
      APKStudio.events.emit('apkReloaded');

      closePanel();
      APKStudio.ui.toast(`✓ ${injected.length} فایل با موفقیت تزریق شد`, 'success');

      // Log to build panel
      APKStudio.build.openBuildPanel();

    } catch (e) {
      APKStudio.ui.toast('خطا در تزریق: ' + e.message, 'error');
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg> اجرای تزریق`;
    }
  }

  async function computeHash(buffer) {
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  return { init };
})();
