# 📱 پنل آموزشی ماز — نسخه ۷ (اصلاح‌شده)

## تغییرات نسخه ۷ نسبت به ۶

### 🐛 باگ‌های رفع‌شده

| # | مشکل | وضعیت |
|---|------|--------|
| 1 | `localStorage` در WebView با `file://` ناپایدار بود | ✅ رفع: همه ذخیره‌سازی‌ها از `MazBridge.saveNote/getNote` استفاده می‌کنند |
| 2 | پوشه PDF جامعه‌شناسی اشتباه (`video/game` به جای `pdf/game`) | ✅ رفع در `mediaConfig.ts` |
| 3 | `PdfViewerActivity` همه صفحات را یکجا در RAM می‌ریخت (OOM) | ✅ رفع: Lazy RecyclerView — هر صفحه فقط موقع نمایش رندر می‌شود |
| 4 | `NoteBox` همه جا از `localStorage` مستقیم استفاده می‌کرد | ✅ رفع: `NoteBox` داخل `MediaPlayer.tsx` با bridge-aware storage |
| 5 | `SessionListPage` از `localStorage` مستقیم استفاده می‌کرد | ✅ رفع: تابع `storageGet` bridge-aware اضافه شد |
| 6 | `double semicolon` در `PdfPage.tsx` | ✅ رفع |
| 7 | فیلد `note` در `SectionMediaConfig` تعریف نشده بود | ✅ اضافه شد |

---

## ساختار پروژه

```
educational-panel-v7/
├── android/              ← پروژه Android Studio
│   ├── app/
│   │   ├── build.gradle
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── assets/
│   │       │   ├── index.html   ← ★ React build اینجا می‌آید
│   │       │   ├── video/       ← فولدرهای MP4
│   │       │   └── pdf/         ← فولدرهای PDF
│   │       ├── java/ir/maz/educational/
│   │       │   ├── MainActivity.java
│   │       │   ├── MazBridge.java          ← JS ↔ Android bridge
│   │       │   ├── PdfViewerActivity.java  ← ★ اصلاح‌شده: Lazy loading
│   │       │   ├── PdfPageAdapter.java
│   │       │   └── VideoPlayerActivity.java
│   │       └── res/
│   ├── build.gradle
│   ├── settings.gradle
│   └── gradle.properties
└── app-web/              ← سورس React
    └── src/
        ├── components/
        │   ├── MediaPlayer.tsx  ← ★ اصلاح‌شده: bridge-aware + NoteBox داخلی
        │   ├── NoteBox.tsx      ← re-export از MediaPlayer
        │   └── Layout.tsx
        ├── pages/
        │   ├── VideoPage.tsx    ← ★ اصلاح‌شده
        │   ├── PdfPage.tsx      ← ★ اصلاح‌شده
        │   ├── SessionListPage.tsx ← ★ اصلاح‌شده
        │   └── ...
        ├── mediaConfig.ts       ← ★ اصلاح‌شده: jam3e_shenasi pdf folder
        └── data.ts
```

---

## مرحله ۱ — ساخت React (index.html)

```bash
cd app-web
npm install
npm run build
```

فایل `app-web/dist/index.html` را کپی کنید به:
```
android/app/src/main/assets/index.html
```

---

## مرحله ۲ — قرار دادن فایل‌های ویدیو و PDF

### ساختار ویدیوها:
```
assets/video/{typeKey}_{slug}/mcvip{N}.mp4
```
مثال:
```
assets/video/A_farsi/mcvip1.mp4
assets/video/A_jam3e_shenasi/mcvip1.mp4   ← پوشه استاندارد
assets/video/game/mcvip1.mp4               ← جامعه‌شناسی override
```

### ساختار PDFها:
```
assets/pdf/{typeKey}_{slug}/note_{N}.pdf       ← جزوات کلاس
assets/pdf/{typeKey}_{slug}/mcvip{N}.pdf       ← جزوات mcvip
assets/pdf/exam_{examId}/sessions/exam_{N}.pdf
assets/pdf/exam_{examId}/answers/answer_{N}.pdf
assets/pdf/exam_{examId}/files/file_{N}.pdf
assets/pdf/simulator/{bookId}/exam_{N}.pdf
assets/pdf/tests/{bookId}/test_{N}.pdf
```

> **⚠️ جامعه‌شناسی (jam3e_shenasi) در typeKey A:**
> - ویدیو → `assets/video/game/mcvip{N}.mp4`
> - PDF → `assets/pdf/game/mcvip{N}.pdf`  *(اصلاح‌شده از v6)*
> - نوت → `assets/pdf/game/note_{N}.pdf`

---

## مرحله ۳ — Android Studio

1. **Open** → پوشه `android/`
2. منتظر Gradle sync
3. **Build → Build APK(s)**

### تنظیمات Gradle:
- `gradle-wrapper.properties`: `gradle-8.7-bin.zip`
- `build.gradle`: `com.android.tools.build:gradle:8.5.0`
- Java 17

---

## ویژگی‌های نسخه ۷

### ✅ ذخیره‌سازی یادداشت و جایگاه ویدیو
- در APK: از `MazBridge.saveNote/getNote` (SharedPreferences اندروید) استفاده می‌شود
- در مرورگر: fallback به `localStorage`
- **هیچ داده‌ای از دست نمی‌رود**

### ✅ PdfViewerActivity — Lazy Loading
- صفحات فقط هنگام نمایش رندر می‌شوند
- `Bitmap.Config.RGB_565` (نصف حافظه ARGB_8888)
- وقتی صفحه از دید خارج شود Bitmap آزاد می‌شود
- پشتیبانی از PDF با هر تعداد صفحه بدون خطای OOM

### ✅ VideoPlayerActivity — ExoPlayer Media3
- پخش مستقیم از `asset://` بدون کپی
- ذخیره و بازیابی جایگاه پخش
- حالت تمام صفحه (portrait + landscape)

### ✅ MazBridge — کامل
- `openPdf(assetPath, title)` → PdfViewerActivity
- `openVideo(assetPath, title)` → VideoPlayerActivity
- `saveNote(key, value)` / `getNote(key)` → SharedPreferences
- `assetExists(path)` → بررسی وجود فایل
- `showToast(message)` → Toast

---

## رفع مشکلات رایج

### ویدیو پخش نمی‌شود
- مسیر: `assets/video/{typeKey}_{slug}/mcvip{N}.mp4`
- از `aaptOptions { noCompress "mp4" }` مطمئن شوید

### PDF باز نمی‌شود
- مسیر: `assets/pdf/{typeKey}_{slug}/note_{N}.pdf`
- **جامعه‌شناسی A**: `assets/pdf/game/note_{N}.pdf`

### یادداشت‌ها ذخیره نمی‌شوند
- اگر MazBridge موجود است، از SharedPreferences استفاده می‌شود
- برای دیباگ: `bridge().showToast("test")` در console

---

## وابستگی‌ها

```gradle
implementation 'androidx.media3:media3-exoplayer:1.4.1'
implementation 'androidx.media3:media3-ui:1.4.1'
implementation 'androidx.media3:media3-common:1.4.1'
implementation 'androidx.media3:media3-datasource:1.4.1'
implementation 'androidx.recyclerview:recyclerview:1.3.2'
```

minSdk: **24** (Android 7.0+) | targetSdk: **34** (Android 14)
