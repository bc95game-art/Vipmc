import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { exams } from "../data";

const examColors = ["#c9a227", "#9b111e", "#2f6f3e", "#1a4a7a"];
const examIcons  = ["fas fa-file-alt", "fas fa-bolt", "fas fa-award", "fas fa-brain"];

export default function ExamsPage() {
  const navigate = useNavigate();

  return (
    <Layout title="آزمون‌ها" backPath="/">
      {exams.map((exam, idx) => (
        <div
          key={exam.id}
          className="class-item exam-item"
          onClick={() => navigate(`/exams/${exam.id}`)}
        >
          <div
            className="class-item-icon"
            style={{ background: `linear-gradient(145deg, ${examColors[idx % examColors.length]}, ${examColors[idx % examColors.length]}aa)` }}
          >
            <i className={examIcons[idx % examIcons.length]} style={{ color: "#fff", fontSize: 22 }} />
          </div>
          <div className="class-item-text">
            <div className="class-item-title">{exam.title}</div>
            <div className="class-info">{exam.info}</div>
          </div>
          <i className="fas fa-chevron-left class-item-arrow" />
        </div>
      ))}
    </Layout>
  );
}
