import { useNavigate } from "react-router-dom";

const menuItems = [
  { path: "/classes", icon: "fas fa-chalkboard-teacher", label: "کلاس‌ها",  color: "#2f6f3e" },
  { path: "/exams",   icon: "fas fa-file-alt",           label: "آزمون‌ها", color: "#9b111e" },
  { path: "/files",   icon: "fas fa-folder-open",        label: "فایل‌ها",  color: "#c9a227" },
];

export default function MainMenu() {
  const navigate = useNavigate();

  return (
    <div className="layout-body">
      <div className="card home-card">
        {/* هدر اصلی */}
        <div className="home-header">
          <div className="home-logo">
            <i className="fas fa-graduation-cap" />
          </div>
          <h1 className="home-title">پنل آموزشی</h1>
          <p className="home-subtitle">کلاس آنلاین ماز</p>
        </div>

        {/* منوی اصلی */}
        <div className="main-menu-grid">
          {menuItems.map(item => (
            <button
              key={item.path}
              className="main-button"
              onClick={() => navigate(item.path)}
            >
              <div className="main-button-icon" style={{ color: item.color }}>
                <i className={item.icon} />
              </div>
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        {/* footer */}
        <div className="home-footer">
          <i className="fas fa-shield-alt" />
          <span>نسخه ۷ — دسترسی آفلاین کامل</span>
        </div>
      </div>
    </div>
  );
}
