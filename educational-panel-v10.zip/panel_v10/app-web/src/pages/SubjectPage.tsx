import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { getClassType } from "../data";

export default function SubjectPage() {
  const { typeKey, slug } = useParams<{ typeKey: string; slug: string }>();
  const navigate = useNavigate();

  const typeData    = getClassType(typeKey);
  const subject     = typeData?.subjects.find(s => s.slug === slug);
  const subjectName = subject?.name ?? "درس";
  const hasNotes    = typeData?.hasNotes ?? false;

  const subtitle = [
    subject?.teacher,
    (subject as any)?.grade,
    (subject as any)?.nextClass,
  ].filter(Boolean).join(" | ");

  return (
    <Layout title={subjectName} subtitle={subtitle || undefined} backPath={`/classes/${typeKey}`}>
      <div className={hasNotes ? "two-buttons-grid" : "one-button-col"}>
        <button
          className="sub-button"
          onClick={() => navigate(`/classes/${typeKey}/${slug}/sessions`)}
        >
          <div className="sub-button-icon">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/25b6.png" width={34} height={34} alt="play" />
          </div>
          <span>جلسات برگزار شده</span>
        </button>

        {hasNotes && (
          <button
            className="sub-button"
            onClick={() => navigate(`/classes/${typeKey}/${slug}/notes`)}
          >
            <div className="sub-button-icon">
              <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c4.png" width={34} height={34} alt="pdf" />
            </div>
            <span>جزوات</span>
          </button>
        )}
      </div>
    </Layout>
  );
}
