package ir.maz.educational;

import android.content.Context;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * JavaScript ↔ Android bridge
 * Called from React via: window.MazBridge.openPdf(path) / window.MazBridge.openVideo(path)
 */
public class MazBridge {

    private final Context context;
    private final WebView webView;

    public MazBridge(Context context, WebView webView) {
        this.context = context;
        this.webView = webView;
    }

    /**
     * Open PDF from assets in native PdfViewerActivity
     * @param assetPath relative path inside assets, e.g. "pdf/A_farsi/mcvip1.pdf"
     * @param title     display title
     */
    @JavascriptInterface
    public void openPdf(String assetPath, String title) {
        try {
            // Copy asset to cache dir so PdfRenderer can access it
            File cacheFile = copyAssetToCache(assetPath);
            if (cacheFile == null) {
                showToast("فایل PDF یافت نشد: " + assetPath);
                return;
            }

            Intent intent = new Intent(context, PdfViewerActivity.class);
            intent.putExtra("pdf_path", cacheFile.getAbsolutePath());
            intent.putExtra("pdf_title", title != null ? title : "جزوه");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            showToast("خطا در باز کردن PDF");
        }
    }

    /**
     * Open video from assets in native VideoPlayerActivity (ExoPlayer)
     * @param assetPath relative path inside assets, e.g. "video/A_farsi/mcvip1.mp4"
     * @param title     display title
     */
    @JavascriptInterface
    public void openVideo(String assetPath, String title) {
        try {
            Intent intent = new Intent(context, VideoPlayerActivity.class);
            intent.putExtra("video_asset_path", assetPath);
            intent.putExtra("video_title", title != null ? title : "ویدیو");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            showToast("خطا در باز کردن ویدیو");
        }
    }

    /**
     * Check if asset file exists
     */
    @JavascriptInterface
    public boolean assetExists(String assetPath) {
        try {
            InputStream is = context.getAssets().open(assetPath);
            is.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Show native toast — FIX: null-check اضافه شد تا از crash در background thread جلوگیری شود
     */
    @JavascriptInterface
    public void showToast(final String message) {
        if (webView == null || message == null) return;
        webView.post(() -> {
            try {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            } catch (Exception ignored) {}
        });
    }

    /**
     * Save note to SharedPreferences
     */
    @JavascriptInterface
    public void saveNote(String key, String value) {
        if (key == null) return;
        context.getSharedPreferences("maz_notes", Context.MODE_PRIVATE)
               .edit().putString(key, value != null ? value : "").apply();
    }

    /**
     * Get note from SharedPreferences
     */
    @JavascriptInterface
    public String getNote(String key) {
        if (key == null) return "";
        return context.getSharedPreferences("maz_notes", Context.MODE_PRIVATE)
                      .getString(key, "");
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    private File copyAssetToCache(String assetPath) {
        try {
            // Create mirrored path in cacheDir
            File outFile = new File(context.getCacheDir(), "assets/" + assetPath);
            File parent = outFile.getParentFile();
            if (parent != null) parent.mkdirs();

            // If already cached, return it
            if (outFile.exists() && outFile.length() > 0) {
                return outFile;
            }

            InputStream in = context.getAssets().open(assetPath);
            FileOutputStream out = new FileOutputStream(outFile);
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) != -1) out.write(buf, 0, len);
            in.close();
            out.close();
            return outFile;
        } catch (IOException e) {
            return null;
        }
    }
}
