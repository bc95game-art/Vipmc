// app.js — Main application orchestration
window.APKStudio = window.APKStudio || {};

APKStudio.ui = (() => {
  function toast(message, type = 'info') {
    const icons = {
      success: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
      error: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
      warning: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
      info: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`
    };

    const container = document.getElementById('toastContainer');
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `${icons[type] || icons.info}<span>${message}</span>`;
    container.appendChild(el);

    setTimeout(() => {
      el.style.animation = 'toastOut 0.2s ease forwards';
      setTimeout(() => el.remove(), 200);
    }, 3200);
  }

  return { toast };
})();

// ========================
// Main App
// ========================
(async function() {
  // Add spin animation
  const style = document.createElement('style');
  style.textContent = `@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`;
  document.head.appendChild(style);

  // Init modules
  APKStudio.events = APKStudio.events || { on(){}, off(){}, emit(){} };

  // Init all components
  APKStudio.fileTree.init();
  APKStudio.tabs.init();
  APKStudio.editor.init();
  APKStudio.search.init();
  APKStudio.build.init();
  APKStudio.inject.init();

  // Show welcome
  APKStudio.editor.showWelcome();

  // Sidebar toggle
  const sidebar = document.getElementById('sidebar');
  document.getElementById('toggleSidebarBtn')?.addEventListener('click', () => {
    sidebar.classList.toggle('collapsed');
  });
  document.getElementById('closeSidebarBtn')?.addEventListener('click', () => {
    sidebar.classList.add('collapsed');
  });

  // Load APK button
  document.getElementById('loadApkBtn')?.addEventListener('click', () => {
    document.getElementById('apkFileInput').click();
  });

  // APK file input
  document.getElementById('apkFileInput')?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    await loadAPK(file);
    e.target.value = '';
  });

  // Drop zone on welcome screen
  const welcomeDrop = document.getElementById('dropZone');
  if (welcomeDrop) {
    welcomeDrop.addEventListener('click', () => document.getElementById('apkFileInput').click());
    welcomeDrop.addEventListener('dragover', e => { e.preventDefault(); welcomeDrop.classList.add('drag-over'); });
    welcomeDrop.addEventListener('dragleave', () => welcomeDrop.classList.remove('drag-over'));
    welcomeDrop.addEventListener('drop', async (e) => {
      e.preventDefault();
      welcomeDrop.classList.remove('drag-over');
      const file = e.dataTransfer.files[0];
      if (!file) return;
      if (file.name.endsWith('.apk')) await loadAPK(file);
      else if (file.name.endsWith('.zip')) {
        // Let inject handle it
        document.getElementById('zipInjectInput').files = e.dataTransfer.files;
        APKStudio.ui.toast('برای تزریق ZIP، ابتدا APK بارگذاری کنید', 'info');
      } else {
        APKStudio.ui.toast('فایل APK یا ZIP وارد کنید', 'error');
      }
    });
  }

  // Global drag/drop on main
  document.addEventListener('dragover', e => e.preventDefault());
  document.addEventListener('drop', async (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (!file) return;
    if (file.name.endsWith('.apk')) await loadAPK(file);
  });

  // Events
  APKStudio.events.on('fileModified', (path) => {
    APKStudio.tabs.markModified(path);
    APKStudio.fileTree.markModified(path);
  });

  APKStudio.events.on('fileSaved', (path) => {
    APKStudio.tabs.markSaved(path);
  });

  APKStudio.events.on('apkReloaded', () => {
    // Refresh tree after injection
    APKStudio.ui.toast('درخت فایل در حال به‌روزرسانی...', 'info');
  });

  // Build APK button
  document.getElementById('buildApkBtn')?.addEventListener('click', () => {
    APKStudio.build.openBuildPanel();
  });

  async function loadAPK(file) {
    if (!file.name.endsWith('.apk')) {
      APKStudio.ui.toast('فقط فایل‌های .apk مجاز هستند', 'error');
      return;
    }

    APKStudio.ui.toast(`در حال بارگذاری ${file.name}...`, 'info');

    try {
      const tree = await APKStudio.apk.loadAPK(file);
      APKStudio.fileTree.render(tree);

      // Enable buttons
      document.getElementById('buildApkBtn').disabled = false;
      document.getElementById('injectBtn').disabled = false;

      // Open sidebar if collapsed
      sidebar.classList.remove('collapsed');

      APKStudio.ui.toast(`✓ ${file.name} بارگذاری شد`, 'success');

      // Auto-open AndroidManifest.xml if exists
      await autoOpenManifest();

    } catch (e) {
      APKStudio.ui.toast(`خطا در بارگذاری APK: ${e.message}`, 'error');
      console.error(e);
    }
  }

  async function autoOpenManifest() {
    const allFiles = await APKStudio.apk.getAllFiles();
    const manifest = allFiles.find(f => f === 'AndroidManifest.xml' || f.endsWith('/AndroidManifest.xml'));
    if (manifest) {
      try {
        const content = await APKStudio.apk.getFileContent(manifest);
        const lang = APKStudio.apk.getSyntaxLanguage(manifest);
        APKStudio.editor.showFile(manifest, content, lang);
        APKStudio.tabs.openTab(manifest, 'AndroidManifest.xml');
      } catch (e) {}
    }
  }

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
      e.preventDefault();
      if (APKStudio.apk.isLoaded()) APKStudio.build.openBuildPanel();
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'i') {
      e.preventDefault();
      if (APKStudio.apk.isLoaded()) document.getElementById('injectBtn').click();
    }
  });

  console.log('%cAPK Studio Pro', 'color: #6c63ff; font-size: 18px; font-weight: bold;');
  console.log('%cآماده برای ویرایش APK', 'color: #a89fff; font-size: 12px;');
})();
