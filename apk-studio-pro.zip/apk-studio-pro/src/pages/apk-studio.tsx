import { useState, useCallback, useRef } from "react";
import JSZip from "jszip";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { FileTree } from "@/components/FileTree";
import { CodeEditor } from "@/components/CodeEditor";
import { SearchPanel } from "@/components/SearchPanel";
import { InjectPanel } from "@/components/InjectPanel";
import { BuildPanel } from "@/components/BuildPanel";
import {
  ApkFile,
  ApkInfo,
  SearchResult,
  BuildError,
  parseApk,
  searchInApk,
  getFileContent,
  updateFileInApk,
  injectZipProject,
  buildApk,
  isTextFile,
  getFileIcon,
} from "@/lib/apk-utils";
import {
  Upload,
  FolderOpen,
  Search,
  Hammer,
  FolderInput,
  Cpu,
  X,
  ChevronLeft,
  ChevronRight,
  ZapIcon,
  FileCode2,
  Info,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";

interface OpenTab {
  path: string;
  name: string;
  content: string;
  modified: boolean;
}

type SidePanel = "files" | "search" | "inject" | "build";
type RightPanel = "none" | "info";

export default function ApkStudio() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [zip, setZip] = useState<JSZip | null>(null);
  const [apkFiles, setApkFiles] = useState<ApkFile[]>([]);
  const [apkInfo, setApkInfo] = useState<ApkInfo | undefined>();
  const [tabs, setTabs] = useState<OpenTab[]>([]);
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [modifiedFiles, setModifiedFiles] = useState<Set<string>>(new Set());
  const [sidePanel, setSidePanel] = useState<SidePanel>("files");
  const [loading, setLoading] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const handleApkLoad = useCallback(async (file: File) => {
    if (!file.name.endsWith(".apk") && !file.name.endsWith(".zip")) {
      toast({ title: "فرمت نامعتبر", description: "فقط فایل‌های APK یا ZIP قابل بارگذاری هستند", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const { zip: newZip, files, info } = await parseApk(file);
      setZip(newZip);
      setApkFiles(files);
      setApkInfo(info);
      setTabs([]);
      setActiveTab(null);
      setModifiedFiles(new Set());
      toast({ title: "APK بارگذاری شد", description: `${info.fileCount} فایل یافت شد` });
    } catch (e) {
      toast({ title: "خطا در بارگذاری", description: (e as Error).message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const handleFileSelect = useCallback(async (file: ApkFile) => {
    if (file.isDirectory || !zip) return;

    const existing = tabs.find((t) => t.path === file.path);
    if (existing) {
      setActiveTab(file.path);
      return;
    }

    if (!isTextFile(file.name)) {
      toast({ title: "فایل باینری", description: "این فایل قابل ویرایش متنی نیست", variant: "default" });
      return;
    }

    try {
      const { text } = await getFileContent(zip, file.path);
      if (text !== undefined) {
        const newTab: OpenTab = { path: file.path, name: file.name, content: text, modified: false };
        setTabs((prev) => [...prev, newTab]);
        setActiveTab(file.path);
      }
    } catch (e) {
      toast({ title: "خطا در باز کردن فایل", description: (e as Error).message, variant: "destructive" });
    }
  }, [zip, tabs, toast]);

  const handleTabClose = useCallback((path: string) => {
    setTabs((prev) => {
      const idx = prev.findIndex((t) => t.path === path);
      const next = prev.filter((t) => t.path !== path);
      if (activeTab === path) {
        setActiveTab(next[Math.max(0, idx - 1)]?.path || null);
      }
      return next;
    });
  }, [activeTab]);

  const handleContentChange = useCallback((path: string, content: string) => {
    setTabs((prev) => prev.map((t) => t.path === path ? { ...t, content, modified: true } : t));
  }, []);

  const handleSave = useCallback(async (path: string) => {
    if (!zip) return;
    const tab = tabs.find((t) => t.path === path);
    if (!tab) return;
    await updateFileInApk(zip, path, tab.content);
    setTabs((prev) => prev.map((t) => t.path === path ? { ...t, modified: false } : t));
    setModifiedFiles((prev) => { const s = new Set(prev); s.delete(path); return s; });
    toast({ title: "ذخیره شد", description: path.split("/").pop() });
  }, [zip, tabs, toast]);

  const handleSearch = useCallback(async (
    query: string,
    options: { regex: boolean; caseSensitive: boolean; filePattern: string }
  ): Promise<SearchResult[]> => {
    if (!zip) return [];
    return searchInApk(zip, query, options);
  }, [zip]);

  const handleSearchResultClick = useCallback(async (result: SearchResult) => {
    if (!zip) return;
    const fileName = result.file.split("/").pop() || result.file;
    const existing = tabs.find((t) => t.path === result.file);
    if (existing) {
      setActiveTab(result.file);
      setSidePanel("files");
      return;
    }
    try {
      const { text } = await getFileContent(zip, result.file);
      if (text !== undefined) {
        const newTab: OpenTab = { path: result.file, name: fileName, content: text, modified: false };
        setTabs((prev) => [...prev, newTab]);
        setActiveTab(result.file);
        setSidePanel("files");
      }
    } catch {}
  }, [zip, tabs]);

  const handleInject = useCallback(async (zipFile: File, targetPath: string): Promise<string[]> => {
    if (!zip) throw new Error("ابتدا یک APK بارگذاری کنید");
    const injected = await injectZipProject(zip, zipFile, targetPath);
    const { zip: refreshed, files, info } = await parseApk(
      new File([await zip.generateAsync({ type: "blob" })], apkInfo?.name || "temp.apk")
    );
    setZip(refreshed);
    setApkFiles(files);
    toast({ title: "تزریق موفق", description: `${injected.length} فایل تزریق شد` });
    return injected;
  }, [zip, apkInfo, toast]);

  const handleBuild = useCallback(async (): Promise<{ blob: Blob; errors: BuildError[] }> => {
    if (!zip) throw new Error("ابتدا یک APK بارگذاری کنید");
    for (const tab of tabs.filter((t) => t.modified)) {
      await updateFileInApk(zip, tab.path, tab.content);
    }
    return buildApk(zip);
  }, [zip, tabs]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleApkLoad(file);
  }, [handleApkLoad]);

  const sidePanels: { id: SidePanel; icon: React.ReactNode; label: string }[] = [
    { id: "files", icon: <FolderOpen size={20} />, label: "فایل‌ها" },
    { id: "search", icon: <Search size={20} />, label: "جستجو" },
    { id: "inject", icon: <FolderInput size={20} />, label: "تزریق" },
    { id: "build", icon: <Hammer size={20} />, label: "ساخت" },
  ];

  return (
    <div
      className="flex flex-col h-screen bg-[#1e1e1e] text-gray-200 overflow-hidden font-sans"
      onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setDragOver(false); }}
      onDrop={handleDrop}
    >
      {dragOver && (
        <div className="absolute inset-0 z-50 bg-[#007acc]/20 border-2 border-dashed border-[#007acc] flex items-center justify-center pointer-events-none">
          <div className="text-center space-y-2">
            <Upload size={48} className="mx-auto text-[#007acc]" />
            <p className="text-xl font-semibold text-[#007acc]">فایل APK را رها کنید</p>
          </div>
        </div>
      )}

      <header className="flex items-center h-10 bg-[#323233] border-b border-[#1e1e1e] px-3 gap-3 flex-shrink-0 select-none">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 bg-gradient-to-br from-[#007acc] to-[#569cd6] rounded flex items-center justify-center">
            <Cpu size={12} className="text-white" />
          </div>
          <span className="text-sm font-semibold text-white">APK Studio Pro</span>
        </div>

        <div className="flex items-center gap-1 ml-2">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1 text-xs bg-[#007acc] hover:bg-[#005a9e] text-white rounded transition-colors"
          >
            <Upload size={11} />
            بارگذاری APK
          </button>
          <input ref={fileInputRef} type="file" accept=".apk,.zip" className="hidden" onChange={(e) => e.target.files?.[0] && handleApkLoad(e.target.files[0])} />
        </div>

        {apkInfo && (
          <div className="flex items-center gap-2 ml-2 text-xs text-gray-400">
            <FileCode2 size={12} className="text-[#4ec9b0]" />
            <span className="text-[#4ec9b0]">{apkInfo.name}</span>
            {apkInfo.packageName && (
              <>
                <span className="text-gray-600">·</span>
                <span>{apkInfo.packageName}</span>
              </>
            )}
            {apkInfo.versionName && (
              <>
                <span className="text-gray-600">·</span>
                <span>v{apkInfo.versionName}</span>
              </>
            )}
          </div>
        )}

        {loading && (
          <div className="flex items-center gap-1.5 text-xs text-[#569cd6] animate-pulse">
            <ZapIcon size={12} />
            در حال پردازش...
          </div>
        )}

        <div className="ml-auto flex items-center gap-1 text-xs text-gray-500">
          {tabs.filter((t) => t.modified).length > 0 && (
            <span className="text-yellow-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-yellow-400 rounded-full" />
              {tabs.filter((t) => t.modified).length} تغییر ذخیره‌نشده
            </span>
          )}
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        <div className="flex flex-col bg-[#333333] border-r border-[#1e1e1e] w-12 flex-shrink-0">
          {sidePanels.map(({ id, icon, label }) => (
            <button
              key={id}
              onClick={() => setSidePanel(id)}
              title={label}
              className={`w-12 h-12 flex items-center justify-center transition-colors relative ${
                sidePanel === id
                  ? "text-white bg-[#1e1e1e] border-l-2 border-l-[#007acc]"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              {icon}
            </button>
          ))}
        </div>

        <ResizablePanelGroup direction="horizontal" className="flex-1">
          <ResizablePanel defaultSize={22} minSize={15} maxSize={40}>
            <div className="h-full flex flex-col border-r border-[#1e1e1e]">
              <div className="px-3 py-1.5 bg-[#252526] border-b border-[#1e1e1e] flex items-center gap-2">
                <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
                  {sidePanel === "files" && "درخت فایل"}
                  {sidePanel === "search" && "جستجوی پیشرفته"}
                  {sidePanel === "inject" && "تزریق پروژه"}
                  {sidePanel === "build" && "بازسازی APK"}
                </span>
                {apkInfo && sidePanel === "files" && (
                  <span className="ml-auto text-[10px] text-gray-600">{apkInfo.fileCount} فایل</span>
                )}
              </div>

              <div className="flex-1 overflow-hidden">
                {sidePanel === "files" && (
                  <FileTree
                    files={apkFiles}
                    selectedFile={activeTab || undefined}
                    onFileSelect={handleFileSelect}
                    modifiedFiles={modifiedFiles}
                  />
                )}
                {sidePanel === "search" && (
                  <SearchPanel
                    onSearch={handleSearch}
                    onResultClick={handleSearchResultClick}
                  />
                )}
                {sidePanel === "inject" && (
                  <InjectPanel
                    onInject={handleInject}
                    hasApk={!!zip}
                  />
                )}
                {sidePanel === "build" && (
                  <BuildPanel
                    onBuild={handleBuild}
                    apkInfo={apkInfo}
                    hasApk={!!zip}
                    modifiedCount={tabs.filter((t) => t.modified).length}
                  />
                )}
              </div>
            </div>
          </ResizablePanel>

          <ResizableHandle className="w-px bg-[#1e1e1e] hover:bg-[#007acc] transition-colors cursor-col-resize" />

          <ResizablePanel defaultSize={78} minSize={40}>
            {!zip ? (
              <div className="flex flex-col items-center justify-center h-full bg-[#1e1e1e] select-none">
                <div className="text-center space-y-6 max-w-sm">
                  <div className="relative">
                    <div className="w-24 h-24 mx-auto bg-gradient-to-br from-[#007acc]/20 to-[#569cd6]/10 rounded-2xl flex items-center justify-center border border-[#007acc]/20">
                      <Cpu size={48} className="text-[#007acc]/60" />
                    </div>
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-[#569cd6]/20 rounded-full flex items-center justify-center border border-[#569cd6]/30">
                      <Upload size={14} className="text-[#569cd6]" />
                    </div>
                  </div>

                  <div>
                    <h2 className="text-2xl font-bold text-white mb-2">APK Studio Pro</h2>
                    <p className="text-gray-400 text-sm leading-relaxed">
                      فایل APK خود را بارگذاری کنید تا بتوانید آن را ویرایش کنید
                    </p>
                  </div>

                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 mx-auto px-6 py-3 bg-[#007acc] hover:bg-[#005a9e] text-white font-medium rounded-lg transition-colors shadow-lg shadow-[#007acc]/20"
                  >
                    <Upload size={16} />
                    بارگذاری فایل APK
                  </button>

                  <p className="text-xs text-gray-600">یا فایل را اینجا رها کنید</p>

                  <div className="grid grid-cols-2 gap-2 text-xs text-gray-500 mt-4">
                    {[
                      ["📄", "ویرایش XML, Java, Smali"],
                      ["🔍", "جستجوی پیشرفته Regex"],
                      ["📦", "تزریق پروژه ZIP"],
                      ["⚡", "بازسازی با کنترل خطا"],
                    ].map(([icon, label]) => (
                      <div key={label} className="flex items-center gap-2 bg-[#252526] p-2 rounded">
                        <span>{icon}</span>
                        <span>{label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <CodeEditor
                tabs={tabs}
                activeTab={activeTab}
                onTabChange={setActiveTab}
                onTabClose={handleTabClose}
                onContentChange={handleContentChange}
                onSave={handleSave}
              />
            )}
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      <div className="h-6 bg-[#007acc] flex items-center px-3 gap-4 text-xs text-white flex-shrink-0 select-none">
        <span className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 bg-green-400 rounded-full" />
          آماده
        </span>
        {activeTab && (
          <>
            <span className="text-blue-200">{activeTab.split("/").pop()}</span>
            <span className="text-blue-300">·</span>
            <span className="text-blue-200">{activeTab}</span>
          </>
        )}
        <span className="ml-auto text-blue-200">APK Studio Pro v2.0</span>
      </div>

      <Toaster />
    </div>
  );
}
