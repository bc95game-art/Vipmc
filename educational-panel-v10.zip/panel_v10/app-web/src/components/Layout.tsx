import type { ReactNode } from "react";
import { useNavigate } from "react-router-dom";

interface LayoutProps {
  children: ReactNode;
  title?: string;
  backPath?: string;
  showBack?: boolean;
  subtitle?: string;
}

export default function Layout({ children, title, backPath, showBack = true, subtitle }: LayoutProps) {
  const navigate = useNavigate();

  const handleBack = () => {
    if (backPath) navigate(backPath);
    else navigate(-1);
  };

  return (
    <div className="layout-body">
      <div className="card">
        <div className="card-header">
          {showBack && (
            <button className="back-btn" onClick={handleBack}>
              <img
                src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/27a1.png"
                width={16} height={16}
                alt="بازگشت"
                style={{ transform: "scaleX(-1)" }}
              />
              بازگشت
            </button>
          )}
          {title && (
            <div className="title-block">
              <h1 className="main-title">{title}</h1>
              {subtitle && <p className="main-subtitle">{subtitle}</p>}
            </div>
          )}
        </div>
        <div className="card-content">
          {children}
        </div>
      </div>
    </div>
  );
}
