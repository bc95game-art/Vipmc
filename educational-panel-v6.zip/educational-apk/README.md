# 📱 پنل آموزشی ماز — راهنمای کامل ساخت APK

## ساختار پروژه

```
educational-apk/
├── android/              ← پروژه Android Studio (فایل APK از اینجا ساخته می‌شود)
│   ├── app/
│   │   ├── build.gradle
│   │   ├── proguard-rules.pro
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── assets/          ← ★ ویدیو و PDF اینجا می‌روند
│   │       │   ├── index.html   ← ★ باید React build را اینجا کپی کنید
│   │       │   ├── video/       ← فولدرهای MP4
│   │       │   └── pdf/         ← فولدرهای PDF
│   │       ├── java/ir/maz/educational/
│   │       │   ├── MainActivity.java       ← WebView اصلی
│   │       │   ├── MazBridge.java          ← Bridge ← JS → Android
│   │       │   ├── PdfViewerActivity.java  ← نمایش‌دهنده PDF native
│   │       │   ├── PdfPageAdapter.java     ← آداپتور صفحات PDF
│   │       │   └── VideoPlayerActivity.java ← پخش‌کننده ویدیو (ExoPlayer)
│   │       └── res/
│   ├── build.gradle
│   ├── settings.gradle
│   └── gradle.properties
└── app-web/              ← سورس React (برای ساخت index.html)
    ├── src/
    │   ├── components/MediaPlayer.tsx  ← ★ تغییر داده شده — از MazBridge استفاده می‌کند
    │   ├── pages/
    │   └── ...
    ├── package.json
    └── vite.config.ts
```

---

## مرحله ۱ — ساخت فایل index.html از React

```bash
cd app-web
npm install
npm run build
```

فایل خروجی: `app-web/dist/index.html`

این فایل را کپی کنید به:
```
android/app/src/main/assets/index.html
```

---

## مرحله ۲ — قرار دادن فایل‌های ویدیو و PDF

### ساختار ویدیوها:
```
android/app/src/main/assets/video/{typeKey}_{slug}/mcvip{N}.mp4
```

مثال‌ها:
```
assets/video/A_farsi/mcvip1.mp4
assets/video/A_farsi/mcvip2.mp4
assets/video/A_jam3e_shenasi/mcvip1.mp4
assets/video/B_din_zendegi/mcvip1.mp4
```

### ساختار PDFها:
```
assets/pdf/{typeKey}_{slug}/note_{N}.pdf      ← جزوات کلاس‌ها
assets/pdf/exam_{examId}/sessions/exam_{N}.pdf
assets/pdf/exam_{examId}/answers/answer_{N}.pdf
assets/pdf/exam_{examId}/files/file_{N}.pdf
assets/pdf/simulator/{bookId}/exam_{N}.pdf
assets/pdf/tests/{bookId}/test_{N}.pdf
```

مثال‌ها:
```
assets/pdf/A_farsi/note_1.pdf
assets/pdf/B_jam3e_shenasi/note_1.pdf
assets/pdf/exam_maz/sessions/exam_1.pdf
assets/pdf/exam_maz/answers/answer_1.pdf
```

> **مهم:** typeKey ها: A=سالیانه، B=نهایی، C=خط‌به‌خط، D=بانک ویدیویی، E=جمع‌بندی

---

## مرحله ۳ — باز کردن در Android Studio

1. Android Studio را باز کنید
2. **Open** → پوشه `android/` را انتخاب کنید
3. منتظر بمانید Gradle sync بشود
4. **Build → Generate Signed APK** یا **Build → Build Bundle(s)/APK(s) → Build APK(s)**

---

## مرحله ۴ — تنظیمات مهم Android Studio

اگر Gradle version درخواست کرد:
- `gradle-wrapper.properties`: از `gradle-8.7-bin.zip` استفاده کنید
- `build.gradle`: `com.android.tools.build:gradle:8.5.0`

اگر Java version error داشت:
- **File → Project Structure → SDK Location** → Java 17

---

## ویژگی‌های نسخه ۶

### ✅ نمایش‌دهنده ویدیو (VideoPlayerActivity)
- **ExoPlayer Media3** — پیشرفته‌ترین پلیر Android
- پشتیبانی کامل از **تمام صفحه** (Portrait + Landscape)
- **ذخیره جایگاه** — ادامه از همان جا پس از بستن
- دکمه‌های **۱۰ ثانیه جلو/عقب**
- **نوار پیشرفت** قابل لمس
- نمایش زمان جاری و کل
- پخش از `asset://` مستقیم بدون کپی فایل

### ✅ نمایش‌دهنده PDF (PdfViewerActivity)  
- **Android PdfRenderer** — موتور native Android
- نمایش **همه صفحات** به صورت اسکرول عمودی
- **Zoom** با انگشت روی هر صفحه
- رندر با **وضوح بالا** (کل عرض صفحه)
- نوار وضعیت با شماره صفحات

### ✅ React WebView
- **MazBridge** — ارتباط JavaScript ↔ Android
- دکمه‌های Native برای باز کردن PDF/Video
- نمایش مسیر فایل برای دیباگ
- ذخیره یادداشت‌ها

---

## رفع مشکلات رایج

### ویدیو پخش نمی‌شود
- بررسی کنید فایل در `assets/video/{typeKey}_{slug}/mcvip{N}.mp4` وجود دارد
- از `aaptOptions { noCompress "mp4" }` در build.gradle مطمئن شوید (موجود است)

### PDF باز نمی‌شود  
- بررسی کنید فایل در `assets/pdf/...` وجود دارد
- اگر خطای `RuntimeException` دارد، فایل PDF معتبر نیست

### Build error: `asset://` not supported
- Media3 1.4.1+ به طور native از `asset://` پشتیبانی می‌کند
- اگر version قدیمی‌تر دارید، آن را به ۱.۴.۱ ارتقا دهید

---

## وابستگی‌های مهم (build.gradle)

```gradle
implementation 'androidx.media3:media3-exoplayer:1.4.1'
implementation 'androidx.media3:media3-ui:1.4.1'
implementation 'androidx.media3:media3-common:1.4.1'
implementation 'androidx.media3:media3-datasource:1.4.1'
implementation 'androidx.recyclerview:recyclerview:1.3.2'
```

minSdk: **24** (Android 7.0+)
targetSdk: **34** (Android 14)
