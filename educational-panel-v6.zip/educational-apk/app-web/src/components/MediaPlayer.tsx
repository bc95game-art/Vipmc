import { useState, useRef, useCallback, useEffect } from "react";

// ─── Android Bridge type ──────────────────────────────────────────────────────
declare global {
  interface Window {
    MazBridge?: {
      openPdf(assetPath: string, title: string): void;
      openVideo(assetPath: string, title: string): void;
      assetExists(assetPath: string): boolean;
      showToast(message: string): void;
      saveNote(key: string, value: string): void;
      getNote(key: string): string;
    };
  }
}

const bridge = () => window.MazBridge;

function urlToAssetPath(url: string): string {
  return url.replace("file:///android_asset/", "");
}

// ─── CopyLinkButton ──────────────────────────────────────────────────────────
interface CopyLinkButtonProps { url: string; label?: string; }

function CopyLinkButton({ url, label = "کپی آدرس فایل" }: CopyLinkButtonProps) {
  const [copied, setCopied] = useState(false);
  const handleCopy = useCallback(async () => {
    try { await navigator.clipboard.writeText(url); } catch {
      const ta = document.createElement("textarea");
      ta.value = url;
      Object.assign(ta.style, { position: "fixed", opacity: "0" });
      document.body.appendChild(ta); ta.select(); document.execCommand("copy"); document.body.removeChild(ta);
    }
    setCopied(true); setTimeout(() => setCopied(false), 2000);
  }, [url]);
  return (
    <button type="button" className="copy-link-btn" onClick={handleCopy}>
      {copied ? <><i className="fas fa-check" /> کپی شد</> : <><i className="fas fa-copy" /> {label}</>}
    </button>
  );
}

// ─── VideoPlayer ──────────────────────────────────────────────────────────────
interface VideoPlayerProps { src: string; mediaKey: string; title?: string; }

export function VideoPlayer({ src, mediaKey, title = "ویدیو" }: VideoPlayerProps) {
  const assetPath = urlToAssetPath(src);
  const hasBridge = !!bridge();
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const savedKey = `video_pos_${mediaKey}`;

  useEffect(() => { setError(false); setLoading(true); setProgress(0); }, [mediaKey]);

  const handleOpenNative = useCallback(() => {
    bridge()?.openVideo(assetPath, title);
  }, [assetPath, title]);

  const handleCanPlay = useCallback(() => {
    setLoading(false);
    const saved = localStorage.getItem(savedKey);
    if (saved && videoRef.current) { const t = parseFloat(saved); if (t > 5) videoRef.current.currentTime = t; }
  }, [savedKey]);

  const handleTimeUpdate = useCallback(() => {
    if (videoRef.current) {
      const t = videoRef.current.currentTime, d = videoRef.current.duration || 0;
      if (d > 0) setProgress(Math.round((t / d) * 100));
      if (Math.floor(t) % 5 === 0) localStorage.setItem(savedKey, String(t));
    }
  }, [savedKey]);

  const handleFullscreen = useCallback(() => {
    const el = wrapperRef.current; if (!el) return;
    const vid = el.querySelector("video") as HTMLVideoElement | null;
    if (vid && (vid as any).webkitEnterFullscreen) { (vid as any).webkitEnterFullscreen(); return; }
    if (vid?.requestFullscreen) { vid.requestFullscreen().catch(() => {}); return; }
    if (el.requestFullscreen) el.requestFullscreen().catch(() => {});
  }, []);

  if (hasBridge) {
    return (
      <div className="native-launcher">
        <div className="native-icon"><i className="fas fa-play-circle" /></div>
        <p className="native-hint">برای پخش ویدیو روی دکمه بزنید</p>
        <button type="button" className="open-native-btn open-native-btn--video" onClick={handleOpenNative}>
          <i className="fas fa-film" /> پخش ویدیو در پلیر
        </button>
        <p className="native-path">{assetPath}</p>
        <CopyLinkButton url={src} />
      </div>
    );
  }

  return (
    <div className="video-wrapper" ref={wrapperRef}>
      {loading && !error && (<div className="media-loading"><i className="fas fa-spinner fa-spin" /><span>در حال بارگذاری ویدیو...</span></div>)}
      {error ? (
        <div className="media-error">
          <i className="fas fa-triangle-exclamation" /><span>خطا در بارگذاری ویدیو</span>
          <span className="media-error-hint">{assetPath}</span><CopyLinkButton url={src} label="کپی آدرس" />
        </div>
      ) : (
        <video ref={videoRef} key={mediaKey} className="video-player" controls preload="metadata" playsInline
          onCanPlay={handleCanPlay} onTimeUpdate={handleTimeUpdate}
          onError={() => { setError(true); setLoading(false); }}
          style={{ display: loading ? "none" : "block" }}>
          <source src={src} type="video/mp4" />
        </video>
      )}
      {!error && !loading && (
        <>
          <div className="video-progress-bar"><div className="video-progress-fill" style={{ width: `${progress}%` }} /></div>
          <button type="button" className="fullscreen-btn" onClick={handleFullscreen}><i className="fas fa-expand" /> تمام صفحه</button>
        </>
      )}
      {!error && <CopyLinkButton url={src} />}
    </div>
  );
}

// ─── PdfViewer ───────────────────────────────────────────────────────────────
interface PdfViewerProps { src: string; mediaKey: string; openLabel?: string; title?: string; }

export function PdfViewer({ src, mediaKey, openLabel = "باز کردن جزوه", title = "جزوه" }: PdfViewerProps) {
  const assetPath = urlToAssetPath(src);
  const hasBridge = !!bridge();
  const [viewMode, setViewMode] = useState<"iframe" | "fallback">("iframe");
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const iframeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleOpenNative = useCallback(() => {
    bridge()?.openPdf(assetPath, title);
  }, [assetPath, title]);

  useEffect(() => {
    setIframeLoaded(false);
    if (hasBridge) { setViewMode("fallback"); return; }
    iframeTimerRef.current = setTimeout(() => setViewMode("fallback"), 5000);
    return () => { if (iframeTimerRef.current) clearTimeout(iframeTimerRef.current); };
  }, [mediaKey, hasBridge]);

  const handleLoad = useCallback(() => {
    if (iframeTimerRef.current) clearTimeout(iframeTimerRef.current);
    setIframeLoaded(true);
  }, []);

  if (hasBridge) {
    return (
      <div className="native-launcher native-launcher--pdf">
        <div className="native-icon native-icon--pdf"><i className="fas fa-file-pdf" /></div>
        <p className="native-hint">برای مشاهده جزوه روی دکمه بزنید</p>
        <button type="button" className="open-native-btn open-native-btn--pdf" onClick={handleOpenNative}>
          <i className="fas fa-eye" /> {openLabel}
        </button>
        <p className="native-path">{assetPath}</p>
        <CopyLinkButton url={src} />
      </div>
    );
  }

  return (
    <div className="pdf-wrapper">
      <a className="open-pdf-btn open-pdf-btn--primary" href={src} target="_blank" rel="noreferrer">
        <i className="fas fa-file-pdf" /> {openLabel}
      </a>
      {viewMode === "iframe" && (
        <div className="pdf-iframe-wrapper">
          {!iframeLoaded && (<div className="pdf-loading"><i className="fas fa-spinner fa-spin" /> در حال بارگذاری PDF...</div>)}
          <iframe key={mediaKey} className="pdf-viewer" src={src} title="نمایش PDF"
            onLoad={handleLoad} onError={() => setViewMode("fallback")}
            style={{ display: iframeLoaded ? "block" : "none" }} />
        </div>
      )}
      {viewMode === "fallback" && (
        <div className="pdf-fallback-box"><i className="fas fa-info-circle" /><p>از دکمه بالا برای باز کردن PDF استفاده کنید.</p></div>
      )}
      <CopyLinkButton url={src} />
    </div>
  );
}

// ─── MediaNotAvailable ───────────────────────────────────────────────────────
interface MediaNotAvailableProps { icon?: string; message: string; }

export function MediaNotAvailable({ icon = "fas fa-file-circle-xmark", message }: MediaNotAvailableProps) {
  return (
    <div className="not-available">
      <i className={icon} style={{ fontSize: 28, marginBottom: 10, display: "block" }} />{message}
    </div>
  );
}
