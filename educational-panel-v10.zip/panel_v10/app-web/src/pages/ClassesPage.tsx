import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { classTypes } from "../data";

// نگاشت آیکون به ایموجی آنلاین
const iconEmojiMap: Record<string, string> = {
  "fas fa-calendar-alt":    "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c5.png",
  "fas fa-clipboard-check": "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4cb.png",
  "fas fa-book":            "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4da.png",
  "fas fa-video":           "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f3ac.png",
  "fas fa-layer-group":     "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c6.png",
  "fas fa-robot":           "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f916.png",
  "fas fa-ellipsis-h":      "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4cc.png",
};

export default function ClassesPage() {
  const navigate = useNavigate();
  const total = classTypes.length;

  return (
    <Layout title="کلاس‌ها" backPath="/">
      <div className="class-types-grid">
        {classTypes.map((type, idx) => {
          const isAlone = total % 2 !== 0 && idx === total - 1;
          const emojiUrl = iconEmojiMap[type.icon] || "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4d6.png";
          return (
            <button
              key={type.key}
              className={`sub-button${isAlone ? " full-width" : ""}`}
              onClick={() => navigate(`/classes/${type.key}`)}
            >
              <div className="sub-button-icon">
                <img src={emojiUrl} width={36} height={36} alt={type.title} />
              </div>
              <span>{type.title}</span>
            </button>
          );
        })}
      </div>
    </Layout>
  );
}
