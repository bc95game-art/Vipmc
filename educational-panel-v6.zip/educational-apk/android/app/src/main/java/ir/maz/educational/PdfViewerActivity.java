package ir.maz.educational;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PdfViewerActivity extends AppCompatActivity {

    private PdfRenderer pdfRenderer;
    private ParcelFileDescriptor pfd;
    private RecyclerView recyclerView;
    private TextView tvTitle, tvPageInfo;
    private ProgressBar progressBar;
    private int totalPages = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full-screen immersive
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_FULLSCREEN
        );

        setContentView(R.layout.activity_pdf_viewer);

        tvTitle    = findViewById(R.id.tvPdfTitle);
        tvPageInfo = findViewById(R.id.tvPageInfo);
        progressBar = findViewById(R.id.pdfProgressBar);
        recyclerView = findViewById(R.id.pdfRecyclerView);

        String pdfPath  = getIntent().getStringExtra("pdf_path");
        String pdfTitle = getIntent().getStringExtra("pdf_title");

        tvTitle.setText(pdfTitle != null ? pdfTitle : "PDF");

        // Back button
        findViewById(R.id.btnPdfBack).setOnClickListener(v -> finish());

        if (pdfPath == null) {
            showError("مسیر فایل نامعتبر است");
            return;
        }

        loadPdf(pdfPath);
    }

    private void loadPdf(String path) {
        progressBar.setVisibility(View.VISIBLE);

        new Thread(() -> {
            try {
                File file = new File(path);
                pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                pdfRenderer = new PdfRenderer(pfd);
                totalPages = pdfRenderer.getPageCount();

                // Render all pages as bitmaps
                List<Bitmap> pages = new ArrayList<>();
                int screenWidth = getResources().getDisplayMetrics().widthPixels;

                for (int i = 0; i < totalPages; i++) {
                    PdfRenderer.Page page = pdfRenderer.openPage(i);
                    float scale = (float) screenWidth / page.getWidth();
                    int bitmapWidth  = screenWidth;
                    int bitmapHeight = (int)(page.getHeight() * scale);

                    Bitmap bmp = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bmp);
                    canvas.drawColor(Color.WHITE);
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    page.close();
                    pages.add(bmp);
                }

                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    tvPageInfo.setText("تعداد صفحات: " + totalPages);
                    recyclerView.setLayoutManager(new LinearLayoutManager(this));
                    recyclerView.setAdapter(new PdfPageAdapter(pages));
                });

            } catch (IOException e) {
                runOnUiThread(() -> showError("خطا در بارگذاری PDF: " + e.getMessage()));
            }
        }).start();
    }

    private void showError(String msg) {
        progressBar.setVisibility(View.GONE);
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (pdfRenderer != null) pdfRenderer.close();
            if (pfd != null) pfd.close();
        } catch (IOException ignored) {}
    }
}
