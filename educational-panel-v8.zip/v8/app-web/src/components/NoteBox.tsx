// NoteBox از MediaPlayer re-export می‌شود تا import‌های قدیمی کار کنند
export { NoteBox as default } from "./MediaPlayer";
