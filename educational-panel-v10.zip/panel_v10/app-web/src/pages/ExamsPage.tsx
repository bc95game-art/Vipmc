import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { exams } from "../data";

const examEmojis = [
  "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4dd.png",
  "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/26a1.png",
  "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f3c6.png",
  "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f9e0.png",
];
const examColors = ["#c9a227", "#9b111e", "#2f6f3e", "#1a4a7a"];

export default function ExamsPage() {
  const navigate = useNavigate();

  return (
    <Layout title="آزمون‌ها" backPath="/">
      {exams.map((exam, idx) => (
        <div
          key={exam.id}
          className="class-item exam-item"
          onClick={() => navigate(`/exams/${exam.id}`)}
        >
          <div
            className="class-item-icon"
            style={{ background: `linear-gradient(145deg, ${examColors[idx % examColors.length]}, ${examColors[idx % examColors.length]}aa)` }}
          >
            <img src={examEmojis[idx % examEmojis.length]} width={28} height={28} alt="exam" />
          </div>
          <div className="class-item-text">
            <div className="class-item-title">{exam.title}</div>
            <div className="class-info">{exam.info}</div>
          </div>
          <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/2b05.png" width={14} height={14} alt="arrow" className="class-item-arrow" />
        </div>
      ))}
    </Layout>
  );
}
