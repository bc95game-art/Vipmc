import { useParams } from "react-router-dom";
import Layout from "../components/Layout";
import NoteBox from "../components/NoteBox";
import { VideoPlayer, MediaNotAvailable } from "../components/MediaPlayer";
import { getClassType } from "../data";
import { getClassVideoUrl } from "../mediaConfig";

export default function VideoPage() {
  const { typeKey, slug, index } = useParams<{ typeKey: string; slug: string; index: string }>();

  const typeData    = getClassType(typeKey);
  const subject     = typeData?.subjects.find(s => s.slug === slug);
  const subjectName = subject?.name ?? "درس";

  const videoUrl = typeKey && slug && index
    ? getClassVideoUrl(typeKey, slug, index)
    : null;

  return (
    <Layout
      title={`جلسه ${index}`}
      subtitle={subjectName}
      backPath={`/classes/${typeKey}/${slug}/sessions`}
    >
      <div className="media-container">
        {videoUrl
          ? <VideoPlayer
              src={videoUrl}
              mediaKey={`${typeKey}-${slug}-${index}`}
              title={`جلسه ${index} — ${subjectName}`}
            />
          : <MediaNotAvailable icon="fas fa-video-slash" message="ویدیوی این جلسه هنوز اضافه نشده است" />
        }
      </div>
      <NoteBox noteKey={`video_${typeKey}_${slug}_${index}`} label={`یادداشت جلسه ${index} — ${subjectName}`} />
    </Layout>
  );
}
