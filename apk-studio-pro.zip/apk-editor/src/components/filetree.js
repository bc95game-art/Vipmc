// filetree.js — Recursive file tree renderer
window.APKStudio = window.APKStudio || {};

APKStudio.fileTree = (() => {
  let _treeData = null;

  function init() {
    document.getElementById('expandAllBtn')?.addEventListener('click', expandAll);
    document.getElementById('collapseAllBtn')?.addEventListener('click', collapseAll);
  }

  function render(tree) {
    _treeData = tree;
    const container = document.getElementById('fileTree');
    container.innerHTML = '';
    const el = renderNode(tree, 0);
    container.appendChild(el);
  }

  function renderNode(node, depth) {
    const fragment = document.createDocumentFragment();

    // Sort: dirs first, then files
    const entries = Object.entries(node).sort(([aName, aVal], [bName, bVal]) => {
      const aIsDir = aVal._dir || (!aVal._file && typeof aVal === 'object');
      const bIsDir = bVal._dir || (!bVal._file && typeof bVal === 'object');
      if (aIsDir && !bIsDir) return -1;
      if (!aIsDir && bIsDir) return 1;
      return aName.localeCompare(bName);
    });

    for (const [name, value] of entries) {
      if (name.startsWith('_')) continue;

      const isFile = value._file;
      const isDir = value._dir || (!isFile && typeof value === 'object' && Object.keys(value).length > 0);

      const itemEl = document.createElement('div');
      itemEl.className = 'tree-item';
      if (isDir) itemEl.classList.add('dir');
      itemEl.style.paddingRight = `${8 + depth * 12}px`;

      const icon = document.createElement('span');
      icon.className = 'tree-icon';

      if (isDir) {
        // Chevron
        const chevron = document.createElement('svg');
        chevron.className = 'tree-chevron';
        chevron.setAttribute('viewBox', '0 0 24 24');
        chevron.setAttribute('fill', 'none');
        chevron.setAttribute('stroke', 'currentColor');
        chevron.setAttribute('stroke-width', '2');
        chevron.innerHTML = '<polyline points="9 18 15 12 9 6"/>';
        itemEl.appendChild(chevron);

        icon.textContent = APKStudio.apk.getFileIcon(value.path || name, true);
        itemEl.appendChild(icon);

        const nameEl = document.createElement('span');
        nameEl.className = 'tree-name';
        nameEl.textContent = name;
        itemEl.appendChild(nameEl);

        const childrenEl = document.createElement('div');
        childrenEl.className = 'tree-children';

        const children = value.children || value;
        const childContent = renderNode(children, depth + 1);
        childrenEl.appendChild(childContent);

        itemEl.addEventListener('click', (e) => {
          e.stopPropagation();
          itemEl.classList.toggle('open');
          childrenEl.classList.toggle('open');
        });

        fragment.appendChild(itemEl);
        fragment.appendChild(childrenEl);

      } else if (isFile) {
        const path = value.path;
        const ext = path.split('.').pop()?.toLowerCase();

        icon.textContent = APKStudio.apk.getFileIcon(path, false);
        itemEl.appendChild(icon);

        const nameEl = document.createElement('span');
        nameEl.className = 'tree-name';
        nameEl.textContent = name;
        itemEl.appendChild(nameEl);

        if (APKStudio.apk.isModified(path)) {
          const dot = document.createElement('span');
          dot.className = 'tab-modified';
          itemEl.appendChild(dot);
        }

        itemEl.dataset.path = path;
        itemEl.addEventListener('click', (e) => {
          e.stopPropagation();
          openFile(path, itemEl);
        });

        fragment.appendChild(itemEl);
      }
    }

    return fragment;
  }

  async function openFile(path, itemEl) {
    // Mark active
    document.querySelectorAll('.tree-item.active').forEach(el => el.classList.remove('active'));
    itemEl.classList.add('active');

    try {
      const content = await APKStudio.apk.getFileContent(path);
      const lang = APKStudio.apk.getSyntaxLanguage(path);
      APKStudio.editor.showFile(path, content, lang);
      APKStudio.tabs.openTab(path, path.split('/').pop());
    } catch (e) {
      APKStudio.ui.toast(`خطا در باز کردن فایل: ${e.message}`, 'error');
    }
  }

  function expandAll() {
    document.querySelectorAll('.tree-item.dir').forEach(el => el.classList.add('open'));
    document.querySelectorAll('.tree-children').forEach(el => el.classList.add('open'));
  }

  function collapseAll() {
    document.querySelectorAll('.tree-item.dir').forEach(el => el.classList.remove('open'));
    document.querySelectorAll('.tree-children').forEach(el => el.classList.remove('open'));
  }

  function markModified(path) {
    const itemEl = document.querySelector(`.tree-item[data-path="${path}"]`);
    if (!itemEl) return;
    if (!itemEl.querySelector('.tab-modified')) {
      const dot = document.createElement('span');
      dot.className = 'tab-modified';
      itemEl.appendChild(dot);
    }
  }

  return { init, render, markModified };
})();
