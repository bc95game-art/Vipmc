/**
 * ====================================================================
 *  پیکربندی مسیر ویدیوها و جزوه‌ها (PDF)
 * ====================================================================
 *
 * الگوی پیش‌فرض:
 *   ویدیوی کلاس‌ها:          file:///android_asset/video/{typeKey}_{slug}/mcvip{N}.mp4
 *   جزوه‌ی کلاس‌ها:          file:///android_asset/pdf/{typeKey}_{slug}/note_{N}.pdf
 *   آزمون‌های برگزار شده:    file:///android_asset/pdf/exam_{examId}/sessions/exam_{N}.pdf
 *   پاسخنامه آزمون‌ها:       file:///android_asset/pdf/exam_{examId}/answers/answer_{N}.pdf
 *   فایل‌های آزمون:          file:///android_asset/pdf/exam_{examId}/files/file_{N}.pdf
 *   شبیه‌ساز نهایی:          file:///android_asset/pdf/simulator/{bookId}/exam_{N}.pdf
 *   تست‌ها:                  file:///android_asset/pdf/tests/{bookId}/test_{N}.pdf
 * ====================================================================
 */

// ─── Types ────────────────────────────────────────────────────────────────────

export interface MediaPathConfig {
  /** پوشه نسبت به android_asset — بدون اسلش ابتدا/انتها */
  folder?: string;
  /** پیشوند نام فایل پیش از شماره. مثال: "mcvip" → mcvip1.mp4 */
  prefix?: string;
  /** پسوند بدون نقطه */
  ext?: string;
}

export interface SectionMediaConfig {
  video?: MediaPathConfig;
  /** مسیر جزوات کلاس (PDF) */
  pdf?: MediaPathConfig;
  /** مسیر نوت‌ها — اگر تعریف نشود از پوشه pdf/{typeKey}_{slug} با پیشوند note_ استفاده می‌شود */
  note?: MediaPathConfig;
}

// ─── Internal builder ─────────────────────────────────────────────────────────

function buildUrl(
  folder: string,
  prefix: string,
  ext: string,
  index: string | number
): string {
  const clean = folder.replace(/^\/+|\/+$/g, "");
  return `file:///android_asset/${clean}/${prefix}${index}.${ext}`;
}

function resolve(
  cfg: MediaPathConfig | undefined,
  defaults: { folder: string; prefix: string; ext: string },
  index: string | number
): string {
  return buildUrl(
    cfg?.folder ?? defaults.folder,
    cfg?.prefix ?? defaults.prefix,
    cfg?.ext    ?? defaults.ext,
    index
  );
}

// ─── Override tables ──────────────────────────────────────────────────────────
// فقط برای بخش/درس‌هایی که آدرس واقعی‌شان با الگوی پیش‌فرض فرق دارد.
//
// ⚠️  اصلاح باگ v6:
//     جامعه‌شناسی (jam3e_shenasi) در نسخه قبلی pdf.folder اشتباه روی
//     "video/game" تنظیم شده بود. اکنون به درستی "pdf/game" است.

export const classMediaConfig: Record<string, Record<string, SectionMediaConfig>> = {
  A: {
    jam3e_shenasi: {
      video: { folder: "video/game", prefix: "mcvip", ext: "mp4" },
      pdf:   { folder: "pdf/game",   prefix: "mcvip", ext: "pdf" }, // ✅ اصلاح‌شده
      note:  { folder: "pdf/game",   prefix: "note_", ext: "pdf" }, // ✅ اضافه‌شده
    },
  },
  B: {}, C: {}, D: {}, E: {},
};

export const examMediaConfig: Record<
  string,
  { sessions?: MediaPathConfig; answers?: MediaPathConfig; files?: MediaPathConfig }
> = {
  // مثال:
  // maz: {
  //   sessions: { folder: "pdf/exam_maz/sessions", prefix: "exam_",   ext: "pdf" },
  //   answers:  { folder: "pdf/exam_maz/answers",  prefix: "answer_", ext: "pdf" },
  //   files:    { folder: "pdf/exam_maz/files",    prefix: "file_",   ext: "pdf" },
  // },
};

export const simulatorMediaConfig: Record<string, MediaPathConfig> = {};
export const testMediaConfig:      Record<string, MediaPathConfig> = {};

// ─── Public URL builders ──────────────────────────────────────────────────────

export function getClassVideoUrl(typeKey: string, slug: string, index: string | number): string {
  return resolve(
    classMediaConfig[typeKey]?.[slug]?.video,
    { folder: `video/${typeKey}_${slug}`, prefix: "mcvip", ext: "mp4" },
    index
  );
}

/** جزوه‌های PDF کلاس — پیشوند پیش‌فرض: mcvip */
export function getClassPdfUrl(typeKey: string, slug: string, index: string | number): string {
  return resolve(
    classMediaConfig[typeKey]?.[slug]?.pdf,
    { folder: `pdf/${typeKey}_${slug}`, prefix: "mcvip", ext: "pdf" },
    index
  );
}

/** نوت‌های کلاس — پیشوند پیش‌فرض: note_ */
export function getClassNoteUrl(typeKey: string, slug: string, index: string | number): string {
  return resolve(
    classMediaConfig[typeKey]?.[slug]?.note,
    { folder: `pdf/${typeKey}_${slug}`, prefix: "note_", ext: "pdf" },
    index
  );
}

export function getExamSessionPdfUrl(examId: string, index: string | number): string {
  return resolve(
    examMediaConfig[examId]?.sessions,
    { folder: `pdf/exam_${examId}/sessions`, prefix: "exam_", ext: "pdf" },
    index
  );
}

export function getExamAnswerPdfUrl(examId: string, index: string | number): string {
  return resolve(
    examMediaConfig[examId]?.answers,
    { folder: `pdf/exam_${examId}/answers`, prefix: "answer_", ext: "pdf" },
    index
  );
}

export function getExamFilePdfUrl(examId: string, index: string | number): string {
  return resolve(
    examMediaConfig[examId]?.files,
    { folder: `pdf/exam_${examId}/files`, prefix: "file_", ext: "pdf" },
    index
  );
}

export function getSimulatorPdfUrl(bookId: string, index: string | number): string {
  return resolve(
    simulatorMediaConfig[bookId],
    { folder: `pdf/simulator/${bookId}`, prefix: "exam_", ext: "pdf" },
    index
  );
}

export function getTestPdfUrl(bookId: string, index: string | number): string {
  return resolve(
    testMediaConfig[bookId],
    { folder: `pdf/tests/${bookId}`, prefix: "test_", ext: "pdf" },
    index
  );
}
