پوشه ویدیوها
ساختار:
  video/{typeKey}_{slug}/mcvip1.mp4
  video/{typeKey}_{slug}/mcvip2.mp4
  ...

مثال:
  video/A_farsi/mcvip1.mp4
  video/A_jam3e_shenasi/mcvip1.mp4
  video/B_din_zendegi/mcvip3.mp4
