import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { getClassType } from "../data";

export default function ClassTypePage() {
  const { typeKey } = useParams<{ typeKey: string }>();
  const navigate   = useNavigate();

  const typeData = getClassType(typeKey);

  if (!typeData) {
    return (
      <Layout title="خطا" backPath="/classes">
        <div className="not-available">صفحه پیدا نشد</div>
      </Layout>
    );
  }

  if (typeKey === "F" || typeKey === "G") {
    return (
      <Layout title={typeData.title} backPath="/classes">
        <div className="not-available">
          <i className="fas fa-lock" style={{ fontSize: 32, marginBottom: 12, display: "block" }} />
          این گزینه به زودی در دسترس خواهد بود
        </div>
      </Layout>
    );
  }

  const isAnnual = typeKey === "A";

  return (
    <Layout title={typeData.title} backPath="/classes">
      {typeData.subjects.map(subj => {
        const lines: string[] = [subj.teacher];
        if (isAnnual && subj.grade)      lines.push(subj.grade);
        if (!isAnnual && subj.nextClass) lines.push(subj.nextClass);

        const iconColors: Record<string, string> = {
          A: "#2f6f3e", B: "#9b111e", C: "#c9a227", D: "#1a4a7a", E: "#5a1a7a",
        };
        const color = iconColors[typeKey ?? "A"] ?? "#2f6f3e";

        return (
          <div
            key={subj.slug}
            className="class-item"
            onClick={() => navigate(`/classes/${typeKey}/${subj.slug}`)}
          >
            <div
              className="class-item-icon"
              style={{ background: `linear-gradient(145deg, ${color}, ${color}bb)` }}
            >
              <i className="fas fa-book-open" style={{ color: "#fff", fontSize: 20 }} />
            </div>
            <div className="class-item-text">
              <div className="class-item-title">{subj.name}</div>
              <div className="class-info">{lines.join("\n")}</div>
            </div>
            <i className="fas fa-chevron-left class-item-arrow" />
          </div>
        );
      })}
    </Layout>
  );
}
