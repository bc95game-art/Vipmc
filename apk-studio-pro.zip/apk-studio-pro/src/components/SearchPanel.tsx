import { useState } from "react";
import { Search, ChevronRight, Loader2, FileText, Code2 } from "lucide-react";
import { SearchResult } from "@/lib/apk-utils";

interface SearchPanelProps {
  onSearch: (query: string, options: { regex: boolean; caseSensitive: boolean; filePattern: string }) => Promise<SearchResult[]>;
  onResultClick: (result: SearchResult) => void;
  isLoading?: boolean;
}

function highlightMatch(text: string, query: string, isRegex: boolean, caseSensitive: boolean): React.ReactNode {
  if (!query) return text;
  try {
    const flags = caseSensitive ? "g" : "gi";
    const pattern = isRegex ? new RegExp(query, flags) : new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), flags);
    const parts = text.split(pattern);
    const matches = text.match(pattern) || [];

    return parts.map((part, i) => (
      <span key={i}>
        {part}
        {i < matches.length && <mark className="bg-yellow-500/40 text-yellow-200 rounded-sm">{matches[i]}</mark>}
      </span>
    ));
  } catch {
    return text;
  }
}

export function SearchPanel({ onSearch, onResultClick, isLoading }: SearchPanelProps) {
  const [query, setQuery] = useState("");
  const [filePattern, setFilePattern] = useState("");
  const [useRegex, setUseRegex] = useState(false);
  const [caseSensitive, setCaseSensitive] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [searched, setSearched] = useState(false);
  const [searching, setSearching] = useState(false);

  const grouped = results.reduce<Record<string, SearchResult[]>>((acc, r) => {
    if (!acc[r.file]) acc[r.file] = [];
    acc[r.file].push(r);
    return acc;
  }, {});

  const handleSearch = async () => {
    if (!query.trim()) return;
    setSearching(true);
    setSearched(false);
    try {
      const res = await onSearch(query, { regex: useRegex, caseSensitive, filePattern });
      setResults(res);
      setSearched(true);
    } finally {
      setSearching(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSearch();
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] text-gray-300">
      <div className="p-3 space-y-2 border-b border-[#2d2d2d]">
        <div className="relative">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            placeholder="جستجو در تمام فایل‌ها..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            className="w-full bg-[#2d2d2d] text-xs text-gray-200 placeholder-gray-500 pl-8 pr-3 py-2 rounded border border-[#3d3d3d] focus:outline-none focus:border-[#007acc]"
          />
        </div>

        <div className="relative">
          <FileText size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            placeholder="فیلتر فایل (مثلاً *.xml)"
            value={filePattern}
            onChange={(e) => setFilePattern(e.target.value)}
            className="w-full bg-[#2d2d2d] text-xs text-gray-200 placeholder-gray-500 pl-8 pr-3 py-1.5 rounded border border-[#3d3d3d] focus:outline-none focus:border-[#007acc]"
          />
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setUseRegex(!useRegex)}
            className={`flex items-center gap-1 px-2 py-1 rounded text-xs border transition-colors ${
              useRegex ? "bg-[#007acc]/20 border-[#007acc] text-[#569cd6]" : "bg-[#2d2d2d] border-[#3d3d3d] text-gray-500 hover:text-gray-300"
            }`}
          >
            <Code2 size={10} />
            Regex
          </button>
          <button
            onClick={() => setCaseSensitive(!caseSensitive)}
            className={`flex items-center gap-1 px-2 py-1 rounded text-xs border transition-colors ${
              caseSensitive ? "bg-[#007acc]/20 border-[#007acc] text-[#569cd6]" : "bg-[#2d2d2d] border-[#3d3d3d] text-gray-500 hover:text-gray-300"
            }`}
          >
            Aa حساس
          </button>
          <button
            onClick={handleSearch}
            disabled={searching || !query.trim()}
            className="ml-auto flex items-center gap-1 px-3 py-1 bg-[#007acc] hover:bg-[#005a9e] disabled:opacity-40 text-white text-xs rounded transition-colors"
          >
            {searching ? <Loader2 size={10} className="animate-spin" /> : <Search size={10} />}
            جستجو
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {searching && (
          <div className="flex items-center justify-center h-20 gap-2 text-gray-500 text-xs">
            <Loader2 size={14} className="animate-spin" />
            در حال جستجو...
          </div>
        )}

        {searched && !searching && (
          <div className="px-3 py-1.5 text-xs text-gray-500 border-b border-[#2d2d2d] flex items-center justify-between">
            <span>{results.length} نتیجه در {Object.keys(grouped).length} فایل</span>
            {results.length >= 500 && <span className="text-yellow-500">نتایج محدود شد</span>}
          </div>
        )}

        {Object.entries(grouped).map(([file, fileResults]) => (
          <FileResultGroup
            key={file}
            file={file}
            results={fileResults}
            query={query}
            useRegex={useRegex}
            caseSensitive={caseSensitive}
            onResultClick={onResultClick}
          />
        ))}

        {searched && !searching && results.length === 0 && (
          <div className="flex flex-col items-center justify-center h-32 text-gray-500 text-xs gap-2">
            <Search size={24} className="text-gray-600" />
            <span>نتیجه‌ای یافت نشد</span>
          </div>
        )}
      </div>
    </div>
  );
}

function FileResultGroup({
  file,
  results,
  query,
  useRegex,
  caseSensitive,
  onResultClick,
}: {
  file: string;
  results: SearchResult[];
  query: string;
  useRegex: boolean;
  caseSensitive: boolean;
  onResultClick: (r: SearchResult) => void;
}) {
  const [expanded, setExpanded] = useState(true);
  const fileName = file.split("/").pop() || file;

  return (
    <div className="border-b border-[#2d2d2d]">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-1.5 px-3 py-1.5 hover:bg-white/5 transition-colors text-left"
      >
        <ChevronRight size={10} className={`text-gray-400 transition-transform ${expanded ? "rotate-90" : ""}`} />
        <span className="text-xs text-[#4ec9b0] font-medium truncate">{fileName}</span>
        <span className="ml-auto text-[10px] text-gray-500 bg-[#2d2d2d] px-1.5 py-0.5 rounded-full">{results.length}</span>
      </button>

      {expanded && (
        <div className="ml-4">
          {results.map((result, i) => (
            <button
              key={i}
              onClick={() => onResultClick(result)}
              className="w-full flex items-start gap-2 px-3 py-1 hover:bg-[#094771] transition-colors text-left group"
            >
              <span className="text-[10px] text-gray-600 font-mono w-8 text-right flex-shrink-0 mt-0.5">{result.line}</span>
              <span className="text-xs text-gray-400 font-mono truncate flex-1">
                {highlightMatch(result.content.slice(0, 120), query, useRegex, caseSensitive)}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
