import { useParams } from "react-router-dom";
import Layout from "../components/Layout";
import NoteBox from "../components/NoteBox";
import { PdfViewer, MediaNotAvailable } from "../components/MediaPlayer";
import { getClassType } from "../data";
import { getClassNoteUrl } from "../mediaConfig";

export default function PdfPage() {
  const { typeKey, slug, index } = useParams<{ typeKey: string; slug: string; index: string }>();

  const typeData    = getClassType(typeKey);
  const subject     = typeData?.subjects.find(s => s.slug === slug);
  const subjectName = subject?.name ?? "درس";

  const pdfUrl = typeKey && slug && index
    ? getClassNoteUrl(typeKey, slug, index)
    : null;

  return (
    <Layout
      title={`جزوه ${index}`}
      subtitle={subjectName}
      backPath={`/classes/${typeKey}/${slug}/notes`}
    >
      <div className="media-container">
        {pdfUrl
          ? <PdfViewer src={pdfUrl} mediaKey={`${typeKey}-${slug}-note-${index}`} openLabel="باز کردن جزوه" />
          : <MediaNotAvailable message="جزوه‌ی این بخش هنوز اضافه نشده است" />
        }
      </div>
      <NoteBox noteKey={`pdf_${typeKey}_${slug}_${index}`} label={`یادداشت جزوه ${index} — ${subjectName}`} />
    </Layout>
  );
}
