// syntax.js — Lightweight syntax highlighter (not used for textarea, just for display)
window.APKStudio = window.APKStudio || {};

APKStudio.syntax = (() => {
  // We use the textarea approach for editing (no contenteditable issues)
  // Syntax highlighting is applied via CSS classes to line numbers and status

  const LANGUAGE_LABELS = {
    xml: 'XML', json: 'JSON', java: 'Java', kotlin: 'Kotlin',
    smali: 'Smali', groovy: 'Groovy', properties: 'Properties',
    javascript: 'JavaScript', typescript: 'TypeScript',
    html: 'HTML', css: 'CSS', text: 'Text', markdown: 'Markdown',
    yaml: 'YAML', bash: 'Shell', python: 'Python'
  };

  function getLabel(lang) {
    return LANGUAGE_LABELS[lang] || lang.toUpperCase();
  }

  // Token colors for status bar context info
  const LANG_COLORS = {
    xml: '#e5534b', json: '#f0883e', java: '#cc7b5c', kotlin: '#7c5cbf',
    smali: '#8b949e', groovy: '#4db84b', javascript: '#f0c32a', typescript: '#339af0',
    html: '#e5534b', css: '#79c0ff', text: '#8b949e', markdown: '#8b949e',
    python: '#3572a5', bash: '#89e051', yaml: '#cb171e'
  };

  function getLangColor(lang) {
    return LANG_COLORS[lang] || '#8b949e';
  }

  return { getLabel, getLangColor };
})();
