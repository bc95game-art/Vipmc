import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { getExam } from "../data";

export default function ExamDetailPage() {
  const { examId } = useParams<{ examId: string }>();
  const navigate   = useNavigate();

  const exam = getExam(examId);

  if (!exam) {
    return (
      <Layout title="خطا" backPath="/exams">
        <div className="not-available">آزمون پیدا نشد</div>
      </Layout>
    );
  }

  const sections = [
    { icon: "fas fa-file-pdf",    label: "سوالات آزمون",  path: `/exams/${examId}/sessions`,   color: "#2f6f3e" },
    { icon: "fas fa-folder-open", label: "فایل‌های مرتبط", path: `/exams/${examId}/files`,      color: "#c9a227" },
  ];

  return (
    <Layout title={exam.title} subtitle={exam.info} backPath="/exams">
      <div className="exam-detail-grid">
        {sections.map(sec => (
          <button
            key={sec.path}
            className="exam-section-btn"
            style={{ "--btn-color": sec.color } as React.CSSProperties}
            onClick={() => navigate(sec.path)}
          >
            <i className={sec.icon} />
            <span>{sec.label}</span>
          </button>
        ))}
      </div>
    </Layout>
  );
}
