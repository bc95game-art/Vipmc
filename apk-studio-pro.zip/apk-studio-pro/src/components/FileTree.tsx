import { useState, useMemo } from "react";
import { ChevronRight, ChevronDown, Search, X, FolderOpen, Folder } from "lucide-react";
import { ApkFile, getFileIcon, formatFileSize } from "@/lib/apk-utils";
import { cn } from "@/lib/utils";

interface FileTreeProps {
  files: ApkFile[];
  selectedFile?: string;
  onFileSelect: (file: ApkFile) => void;
  modifiedFiles?: Set<string>;
}

interface TreeNodeProps {
  file: ApkFile;
  depth: number;
  selectedFile?: string;
  onFileSelect: (file: ApkFile) => void;
  modifiedFiles?: Set<string>;
  searchQuery: string;
}

function matchesSearch(file: ApkFile, query: string): boolean {
  if (!query) return true;
  const q = query.toLowerCase();
  if (file.name.toLowerCase().includes(q)) return true;
  if (file.children) {
    return file.children.some((child) => matchesSearch(child, query));
  }
  return false;
}

function TreeNode({ file, depth, selectedFile, onFileSelect, modifiedFiles, searchQuery }: TreeNodeProps) {
  const [expanded, setExpanded] = useState(depth < 2);
  const isSelected = selectedFile === file.path;
  const isModified = modifiedFiles?.has(file.path);
  const icon = getFileIcon(file);

  const visibleChildren = useMemo(() => {
    if (!file.children) return [];
    if (!searchQuery) return file.children;
    return file.children.filter((child) => matchesSearch(child, searchQuery));
  }, [file.children, searchQuery]);

  if (searchQuery && !matchesSearch(file, searchQuery)) return null;

  const handleClick = () => {
    if (file.isDirectory) {
      setExpanded(!expanded);
    } else {
      onFileSelect(file);
    }
  };

  return (
    <div>
      <div
        className={cn(
          "flex items-center gap-1 px-2 py-[3px] cursor-pointer rounded-sm group transition-colors",
          "hover:bg-white/5",
          isSelected && "bg-[#094771] hover:bg-[#094771]",
        )}
        style={{ paddingLeft: `${8 + depth * 16}px` }}
        onClick={handleClick}
      >
        {file.isDirectory ? (
          <span className="text-gray-400 w-4 h-4 flex items-center justify-center flex-shrink-0">
            {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          </span>
        ) : (
          <span className="w-4 flex-shrink-0" />
        )}

        <span className="text-sm leading-none mr-1 flex-shrink-0">
          {file.isDirectory ? (expanded ? <FolderOpen size={14} className="text-[#dcb67a]" /> : <Folder size={14} className="text-[#dcb67a]" />) : icon}
        </span>

        <span
          className={cn(
            "text-xs truncate flex-1 min-w-0",
            file.isDirectory ? "text-gray-200 font-medium" : "text-gray-300",
            isSelected && "text-white",
            isModified && "text-yellow-400 italic",
          )}
        >
          {file.name}
          {isModified && <span className="ml-1 text-yellow-500">●</span>}
        </span>

        {!file.isDirectory && file.size > 0 && (
          <span className="text-[10px] text-gray-500 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
            {formatFileSize(file.size)}
          </span>
        )}
      </div>

      {file.isDirectory && expanded && visibleChildren.length > 0 && (
        <div>
          {visibleChildren.map((child) => (
            <TreeNode
              key={child.path}
              file={child}
              depth={depth + 1}
              selectedFile={selectedFile}
              onFileSelect={onFileSelect}
              modifiedFiles={modifiedFiles}
              searchQuery={searchQuery}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function FileTree({ files, selectedFile, onFileSelect, modifiedFiles }: FileTreeProps) {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e]">
      <div className="px-2 py-2 border-b border-[#2d2d2d]">
        <div className="relative">
          <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            placeholder="Filter files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#2d2d2d] text-xs text-gray-300 placeholder-gray-500 pl-6 pr-6 py-1.5 rounded border border-[#3d3d3d] focus:outline-none focus:border-[#007acc]"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
            >
              <X size={10} />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto overflow-x-hidden py-1 scrollbar-thin">
        {files.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 text-xs gap-2 px-4 text-center">
            <Folder size={32} className="text-gray-600" />
            <span>فایل APK را بارگذاری کنید</span>
          </div>
        ) : (
          files.map((file) => (
            <TreeNode
              key={file.path}
              file={file}
              depth={0}
              selectedFile={selectedFile}
              onFileSelect={onFileSelect}
              modifiedFiles={modifiedFiles}
              searchQuery={searchQuery}
            />
          ))
        )}
      </div>
    </div>
  );
}
