import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { fileBooks } from "../data";

export default function FileBooksPage() {
  const navigate = useNavigate();

  return (
    <Layout title="شبیه‌ساز نهایی" backPath="/files">
      {fileBooks.map((book, idx) => (
        <div
          key={book.id}
          className="class-item"
          onClick={() => navigate(`/files/simulator/${book.id}`)}
        >
          <div
            className="class-item-icon"
            style={{ background: `linear-gradient(145deg, #2f6f3e, #1e4a29)` }}
          >
            <span className="class-item-num">{idx + 1}</span>
          </div>
          <div className="class-item-text">
            <div className="class-item-title">{book.title}</div>
            <div className="class-info">آزمون‌های شبیه‌ساز</div>
          </div>
          <i className="fas fa-chevron-left class-item-arrow" />
        </div>
      ))}
    </Layout>
  );
}
