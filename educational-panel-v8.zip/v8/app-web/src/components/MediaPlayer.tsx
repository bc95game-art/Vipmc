import { useState, useRef, useCallback, useEffect } from "react";

// ─── Android Bridge type ──────────────────────────────────────────────────────
declare global {
  interface Window {
    MazBridge?: {
      openPdf(assetPath: string, title: string): void;
      openVideo(assetPath: string, title: string): void;
      assetExists(assetPath: string): boolean;
      showToast(message: string): void;
      saveNote(key: string, value: string): void;
      getNote(key: string): string;
    };
  }
}

/** برمی‌گرداند null اگر bridge موجود نباشد */
const bridge = (): Window["MazBridge"] | null =>
  typeof window !== "undefined" && window.MazBridge ? window.MazBridge : null;

/** تبدیل file:///android_asset/ به مسیر نسبی برای bridge */
function urlToAssetPath(url: string): string {
  return url.replace("file:///android_asset/", "");
}

// ─── Storage helper: bridge اول، بعد localStorage ────────────────────────────
// این رویکرد مشکل عدم پایداری localStorage در WebView با file:// را حل می‌کند

function storageSet(key: string, value: string): void {
  try {
    const b = bridge();
    if (b) {
      b.saveNote(key, value);
    } else {
      localStorage.setItem(key, value);
    }
  } catch { /* silent */ }
}

function storageGet(key: string): string | null {
  try {
    const b = bridge();
    if (b) {
      const val = b.getNote(key);
      return val !== "" ? val : null;
    } else {
      return localStorage.getItem(key);
    }
  } catch {
    return null;
  }
}

// ─── CopyLinkButton ──────────────────────────────────────────────────────────

interface CopyLinkButtonProps {
  url: string;
  label?: string;
}

function CopyLinkButton({ url, label = "کپی آدرس فایل" }: CopyLinkButtonProps) {
  const [copied, setCopied] = useState(false);

  const legacyCopy = (text: string): boolean => {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      Object.assign(ta.style, { position: "fixed", top: "0", left: "0", opacity: "0" });
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch {
      return false;
    }
  };

  const handleCopy = useCallback(async () => {
    let ok = false;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(url);
        ok = true;
      }
    } catch { /* fall through */ }

    if (!ok) ok = legacyCopy(url);

    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } else {
      window.prompt("کپی خودکار ممکن نشد — آدرس را با دست کپی کنید:", url);
    }
  }, [url]);

  return (
    <button type="button" className="copy-link-btn" onClick={handleCopy}>
      {copied
        ? <><i className="fas fa-check" /> آدرس کپی شد</>
        : <><i className="fas fa-copy" /> {label}</>
      }
    </button>
  );
}

// ─── requestFullscreen helper ────────────────────────────────────────────────

function enterFullscreen(wrapperEl: HTMLElement) {
  const video = wrapperEl.querySelector("video") as HTMLVideoElement | null;
  if (video) {
    if ((video as any).webkitEnterFullscreen) {
      (video as any).webkitEnterFullscreen();
      return;
    }
    if (video.requestFullscreen) {
      video.requestFullscreen().catch(() => {});
      return;
    }
  }
  if (wrapperEl.requestFullscreen) {
    wrapperEl.requestFullscreen().catch(() => {});
  } else if ((wrapperEl as any).webkitRequestFullscreen) {
    (wrapperEl as any).webkitRequestFullscreen();
  }
}

// ─── VideoPlayer ──────────────────────────────────────────────────────────────

interface VideoPlayerProps {
  src: string;
  mediaKey: string;
  title?: string;
}

export function VideoPlayer({ src, mediaKey, title = "ویدیو" }: VideoPlayerProps) {
  const assetPath = urlToAssetPath(src);
  const hasBridge = !!bridge();

  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const savedKey = `video_pos_${mediaKey}`;

  useEffect(() => {
    setError(false);
    setLoading(true);
    setProgress(0);
  }, [mediaKey]);

  // ─── حالت native: bridge موجود است ───────────────────────────────────────
  const handleOpenNative = useCallback(() => {
    bridge()?.openVideo(assetPath, title);
  }, [assetPath, title]);

  if (hasBridge) {
    return (
      <div className="native-launcher">
        <div className="native-icon"><i className="fas fa-play-circle" /></div>
        <p className="native-hint">برای پخش ویدیو روی دکمه بزنید</p>
        <button
          type="button"
          className="open-native-btn open-native-btn--video"
          onClick={handleOpenNative}
        >
          <i className="fas fa-film" /> پخش ویدیو در پلیر
        </button>
        <p className="native-path">{assetPath}</p>
        <CopyLinkButton url={src} />
      </div>
    );
  }

  // ─── حالت web: بدون bridge ────────────────────────────────────────────────
  const handleCanPlay = () => {
    setLoading(false);
    const saved = storageGet(savedKey);
    if (saved && videoRef.current) {
      const t = parseFloat(saved);
      if (t > 5) videoRef.current.currentTime = t;
    }
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const t = videoRef.current.currentTime;
    const d = videoRef.current.duration || 0;
    if (d > 0) setProgress(Math.round((t / d) * 100));
    if (Math.floor(t) % 5 === 0) storageSet(savedKey, String(t));
  };

  const handleFullscreen = () => {
    if (wrapperRef.current) enterFullscreen(wrapperRef.current);
  };

  return (
    <div className="video-wrapper" ref={wrapperRef}>
      {loading && !error && (
        <div className="media-loading">
          <i className="fas fa-spinner fa-spin" />
          <span>در حال بارگذاری ویدیو...</span>
        </div>
      )}

      {error ? (
        <div className="media-error">
          <i className="fas fa-triangle-exclamation" />
          <span>خطا در بارگذاری ویدیو</span>
          <span className="media-error-hint">{assetPath}</span>
          <CopyLinkButton url={src} label="کپی آدرس برای بررسی" />
        </div>
      ) : (
        <video
          ref={videoRef}
          key={mediaKey}
          className="video-player"
          controls
          preload="metadata"
          playsInline
          webkit-playsinline="true"
          x5-playsinline="true"
          x5-video-player-type="h5"
          x5-video-player-fullscreen="true"
          onCanPlay={handleCanPlay}
          onTimeUpdate={handleTimeUpdate}
          onError={() => { setError(true); setLoading(false); }}
          style={{ display: loading ? "none" : "block" }}
        >
          <source src={src} type="video/mp4" />
          مرورگر شما از پخش ویدیو پشتیبانی نمی‌کند.
        </video>
      )}

      {!error && !loading && (
        <>
          <div className="video-progress-bar">
            <div className="video-progress-fill" style={{ width: `${progress}%` }} />
          </div>
          <button type="button" className="fullscreen-btn" onClick={handleFullscreen}>
            <i className="fas fa-expand" /> تمام صفحه
          </button>
        </>
      )}

      {!error && <CopyLinkButton url={src} />}
    </div>
  );
}

// ─── PdfViewer ───────────────────────────────────────────────────────────────

interface PdfViewerProps {
  src: string;
  mediaKey: string;
  openLabel?: string;
  title?: string;
}

export function PdfViewer({
  src,
  mediaKey,
  openLabel = "باز کردن جزوه",
  title = "جزوه",
}: PdfViewerProps) {
  const assetPath = urlToAssetPath(src);
  const hasBridge = !!bridge();
  const [viewMode, setViewMode] = useState<"iframe" | "fallback">("iframe");
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const iframeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleOpenNative = useCallback(() => {
    bridge()?.openPdf(assetPath, title);
  }, [assetPath, title]);

  useEffect(() => {
    setIframeLoaded(false);
    if (hasBridge) {
      // bridge موجود است: نمایش native
      setViewMode("fallback");
    } else {
      // web: سعی iframe، timeout 5 ثانیه
      setViewMode("iframe");
      iframeTimerRef.current = setTimeout(() => setViewMode("fallback"), 5000);
    }
    return () => {
      if (iframeTimerRef.current) clearTimeout(iframeTimerRef.current);
    };
  }, [mediaKey, hasBridge]);

  const handleLoad = useCallback(() => {
    if (iframeTimerRef.current) clearTimeout(iframeTimerRef.current);
    setIframeLoaded(true);
  }, []);

  // ─── حالت native ─────────────────────────────────────────────────────────
  if (hasBridge) {
    return (
      <div className="native-launcher native-launcher--pdf">
        <div className="native-icon native-icon--pdf">
          <i className="fas fa-file-pdf" />
        </div>
        <p className="native-hint">برای مشاهده جزوه روی دکمه بزنید</p>
        <button
          type="button"
          className="open-native-btn open-native-btn--pdf"
          onClick={handleOpenNative}
        >
          <i className="fas fa-eye" /> {openLabel}
        </button>
        <p className="native-path">{assetPath}</p>
        <CopyLinkButton url={src} />
      </div>
    );
  }

  // ─── حالت web ────────────────────────────────────────────────────────────
  return (
    <div className="pdf-wrapper">
      <a
        className="open-pdf-btn open-pdf-btn--primary"
        href={src}
        target="_blank"
        rel="noreferrer"
      >
        <i className="fas fa-file-pdf" /> {openLabel}
      </a>

      {viewMode === "iframe" && (
        <div className="pdf-iframe-wrapper">
          {!iframeLoaded && (
            <div className="pdf-loading">
              <i className="fas fa-spinner fa-spin" /> در حال بارگذاری PDF...
            </div>
          )}
          <iframe
            key={mediaKey}
            className="pdf-viewer"
            src={src}
            title="نمایش PDF"
            onLoad={handleLoad}
            onError={() => setViewMode("fallback")}
            style={{ display: iframeLoaded ? "block" : "none" }}
          />
        </div>
      )}

      {viewMode === "fallback" && (
        <div className="pdf-fallback-box">
          <i className="fas fa-info-circle" />
          <p>از دکمه بالا برای باز کردن PDF استفاده کنید.</p>
        </div>
      )}

      <CopyLinkButton url={src} />
    </div>
  );
}

// ─── NoteBox با bridge-aware storage ─────────────────────────────────────────

interface NoteBoxProps {
  noteKey: string;
  label?: string;
}

export function NoteBox({ noteKey, label = "یادداشت شما" }: NoteBoxProps) {
  const storageKey = `note_${noteKey}`;
  const [note, setNote] = useState("");
  const [saved, setSaved] = useState(false);
  const [charCount, setCharCount] = useState(0);

  useEffect(() => {
    const stored = storageGet(storageKey) ?? "";
    setNote(stored);
    setCharCount(stored.length);
  }, [storageKey]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNote(e.target.value);
    setCharCount(e.target.value.length);
  }, []);

  const handleSave = useCallback(() => {
    storageSet(storageKey, note);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }, [storageKey, note]);

  const handleClear = useCallback(() => {
    if (window.confirm("یادداشت پاک شود؟")) {
      setNote("");
      setCharCount(0);
      // پاک کردن از هر دو مکان
      try { localStorage.removeItem(storageKey); } catch { /* silent */ }
      storageSet(storageKey, "");
    }
  }, [storageKey]);

  return (
    <div className="note-box">
      <div className="note-box-header">
        <div className="note-box-label">
          <i className="fas fa-sticky-note" /> {label}
        </div>
        {charCount > 0 && (
          <button className="note-clear-btn" onClick={handleClear} title="پاک کردن">
            <i className="fas fa-trash-alt" />
          </button>
        )}
      </div>
      <textarea
        className="note-textarea"
        value={note}
        onChange={handleChange}
        placeholder="یادداشت خود را اینجا بنویسید..."
        rows={4}
      />
      <div className="note-footer">
        <span className="note-char-count">{charCount} کاراکتر</span>
        <button className="note-save-btn" onClick={handleSave}>
          {saved
            ? <><i className="fas fa-check" /> ذخیره شد!</>
            : <><i className="fas fa-save" /> ذخیره</>
          }
        </button>
      </div>
    </div>
  );
}

// ─── MediaNotAvailable ───────────────────────────────────────────────────────

interface MediaNotAvailableProps {
  icon?: string;
  message: string;
}

export function MediaNotAvailable({
  icon = "fas fa-file-circle-xmark",
  message,
}: MediaNotAvailableProps) {
  return (
    <div className="not-available">
      <i className={icon} style={{ fontSize: 28, marginBottom: 10, display: "block" }} />
      {message}
    </div>
  );
}
