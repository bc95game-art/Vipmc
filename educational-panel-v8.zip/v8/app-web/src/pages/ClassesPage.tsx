import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { classTypes } from "../data";

export default function ClassesPage() {
  const navigate = useNavigate();
  const total = classTypes.length;

  return (
    <Layout title="کلاس‌ها" backPath="/">
      <div className="class-types-grid">
        {classTypes.map((type, idx) => {
          const isAlone = total % 2 !== 0 && idx === total - 1;
          return (
            <button
              key={type.key}
              className={`sub-button${isAlone ? " full-width" : ""}`}
              onClick={() => navigate(`/classes/${type.key}`)}
            >
              <i className={type.icon} />
              <span>{type.title}</span>
            </button>
          );
        })}
      </div>
    </Layout>
  );
}
