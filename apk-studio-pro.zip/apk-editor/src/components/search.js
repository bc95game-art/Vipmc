// search.js — File search component
window.APKStudio = window.APKStudio || {};

APKStudio.search = (() => {
  let _debounceTimer = null;

  function init() {
    const input = document.getElementById('searchInput');
    const clearBtn = document.getElementById('clearSearchBtn');

    input?.addEventListener('input', () => {
      clearBtn.style.display = input.value ? 'flex' : 'none';
      clearTimeout(_debounceTimer);
      _debounceTimer = setTimeout(() => doSearch(input.value), 400);
    });

    clearBtn?.addEventListener('click', () => {
      input.value = '';
      clearBtn.style.display = 'none';
      document.getElementById('searchResults').innerHTML = '';
    });
  }

  async function doSearch(query) {
    const container = document.getElementById('searchResults');
    if (!query || query.length < 2) { container.innerHTML = ''; return; }
    if (!APKStudio.apk.isLoaded()) return;

    container.innerHTML = '<div style="color: var(--text-muted); font-size: 11px; padding: 6px 8px;">در حال جستجو...</div>';

    const options = {
      regex: document.getElementById('regexSearch').checked,
      caseSensitive: document.getElementById('caseSensitive').checked
    };

    try {
      const results = await APKStudio.apk.searchInFiles(query, options);
      renderResults(results, query);
    } catch (e) {
      container.innerHTML = `<div style="color: var(--error); font-size: 11px; padding: 6px 8px;">خطا: ${e.message}</div>`;
    }
  }

  function renderResults(results, query) {
    const container = document.getElementById('searchResults');
    if (!results.length) {
      container.innerHTML = '<div style="color: var(--text-muted); font-size: 11px; padding: 6px 8px;">نتیجه‌ای پیدا نشد</div>';
      return;
    }

    // Group by file
    const byFile = {};
    results.forEach(r => {
      if (!byFile[r.path]) byFile[r.path] = [];
      byFile[r.path].push(r);
    });

    const fragment = document.createDocumentFragment();

    const header = document.createElement('div');
    header.style.cssText = 'font-size:10px;color:var(--text-muted);padding:4px 8px;';
    header.textContent = `${results.length} نتیجه در ${Object.keys(byFile).length} فایل`;
    fragment.appendChild(header);

    for (const [file, matches] of Object.entries(byFile)) {
      const fileName = file.split('/').pop();

      matches.forEach(match => {
        const item = document.createElement('div');
        item.className = 'search-result-item';

        const fileDiv = document.createElement('div');
        fileDiv.className = 'search-result-file';
        fileDiv.textContent = `${fileName}:${match.line}`;

        const lineDiv = document.createElement('div');
        lineDiv.className = 'search-result-line';
        lineDiv.innerHTML = highlightMatch(match.content, match.match);

        item.appendChild(fileDiv);
        item.appendChild(lineDiv);

        item.addEventListener('click', () => {
          openSearchResult(file);
        });

        fragment.appendChild(item);
      });
    }

    container.innerHTML = '';
    container.appendChild(fragment);
  }

  function highlightMatch(line, query) {
    const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escaped})`, 'gi');
    return line.replace(regex, '<mark>$1</mark>');
  }

  async function openSearchResult(path) {
    try {
      const content = await APKStudio.apk.getFileContent(path);
      const lang = APKStudio.apk.getSyntaxLanguage(path);
      APKStudio.editor.showFile(path, content, lang);
      APKStudio.tabs.openTab(path, path.split('/').pop());

      // Scroll tree to file
      const treeItem = document.querySelector(`.tree-item[data-path="${path}"]`);
      if (treeItem) {
        treeItem.scrollIntoView({ behavior: 'smooth', block: 'center' });
        document.querySelectorAll('.tree-item.active').forEach(el => el.classList.remove('active'));
        treeItem.classList.add('active');
      }
    } catch (e) {
      APKStudio.ui.toast('خطا در باز کردن فایل', 'error');
    }
  }

  return { init };
})();
