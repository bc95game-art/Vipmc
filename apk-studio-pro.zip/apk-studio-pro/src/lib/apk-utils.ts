import JSZip from "jszip";

export interface ApkFile {
  name: string;
  path: string;
  size: number;
  isDirectory: boolean;
  content?: Uint8Array | string;
  mimeType?: string;
  children?: ApkFile[];
}

export interface BuildError {
  file: string;
  line?: number;
  message: string;
  type: "error" | "warning";
}

export interface ApkInfo {
  name: string;
  size: number;
  fileCount: number;
  packageName?: string;
  versionName?: string;
  versionCode?: string;
  minSdkVersion?: string;
  targetSdkVersion?: string;
}

export interface SearchResult {
  file: string;
  line: number;
  content: string;
  matchStart: number;
  matchEnd: number;
}

const TEXT_EXTENSIONS = new Set([
  "xml", "java", "kt", "smali", "json", "txt", "html", "htm",
  "css", "js", "ts", "gradle", "properties", "mf", "sf", "rsa",
  "md", "yaml", "yml", "ini", "cfg", "conf", "sh", "bat",
  "pro", "policy", "pgcfg", "flags", "map", "pem",
]);

const LANGUAGE_MAP: Record<string, string> = {
  xml: "xml",
  java: "java",
  kt: "kotlin",
  smali: "ini",
  json: "json",
  js: "javascript",
  ts: "typescript",
  html: "html",
  htm: "html",
  css: "css",
  gradle: "groovy",
  properties: "ini",
  yaml: "yaml",
  yml: "yaml",
  md: "markdown",
  sh: "shell",
  bat: "bat",
};

export function getFileExtension(filename: string): string {
  const parts = filename.split(".");
  return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : "";
}

export function isTextFile(filename: string): boolean {
  const ext = getFileExtension(filename);
  return TEXT_EXTENSIONS.has(ext);
}

export function getLanguage(filename: string): string {
  const ext = getFileExtension(filename);
  return LANGUAGE_MAP[ext] || "plaintext";
}

export function getFileIcon(file: ApkFile): string {
  if (file.isDirectory) return "📁";
  const ext = getFileExtension(file.name);
  const icons: Record<string, string> = {
    xml: "📄",
    java: "☕",
    kt: "🟣",
    smali: "🔧",
    json: "📋",
    png: "🖼️",
    jpg: "🖼️",
    jpeg: "🖼️",
    gif: "🖼️",
    webp: "🖼️",
    dex: "⚙️",
    so: "🔗",
    arsc: "📦",
    gradle: "🐘",
    properties: "⚙️",
    txt: "📝",
    md: "📝",
    html: "🌐",
    css: "🎨",
    js: "🟡",
    ts: "🔵",
    mp3: "🎵",
    mp4: "🎬",
    ttf: "🔤",
    otf: "🔤",
    zip: "🗜️",
  };
  return icons[ext] || "📄";
}

export async function parseApk(file: File): Promise<{ zip: JSZip; files: ApkFile[]; info: ApkInfo }> {
  const arrayBuffer = await file.arrayBuffer();
  const zip = await JSZip.loadAsync(arrayBuffer);

  const fileMap = new Map<string, ApkFile>();
  const rootFiles: ApkFile[] = [];

  const sortedPaths = Object.keys(zip.files).sort();

  for (const path of sortedPaths) {
    const zipFile = zip.files[path];
    const parts = path.split("/").filter(Boolean);
    if (parts.length === 0) continue;

    let content: Uint8Array | string | undefined;
    let mimeType: string | undefined;

    if (!zipFile.dir) {
      const fileName = parts[parts.length - 1];
      if (isTextFile(fileName)) {
        try {
          content = await zipFile.async("string");
        } catch {
          content = await zipFile.async("uint8array");
        }
      }
    }

    const apkFile: ApkFile = {
      name: parts[parts.length - 1] || path,
      path: path.endsWith("/") ? path.slice(0, -1) : path,
      size: zipFile.dir ? 0 : ((zipFile as any)._data?.uncompressedSize || 0),
      isDirectory: zipFile.dir || path.endsWith("/"),
      content,
      mimeType,
      children: zipFile.dir ? [] : undefined,
    };

    fileMap.set(apkFile.path, apkFile);

    if (parts.length === 1) {
      rootFiles.push(apkFile);
    } else {
      const parentPath = parts.slice(0, -1).join("/");
      const parent = fileMap.get(parentPath);
      if (parent && parent.children) {
        parent.children.push(apkFile);
      }
    }
  }

  const allFiles = Array.from(fileMap.values());
  const info = await extractApkInfo(zip, file, allFiles);

  return { zip, files: rootFiles, info };
}

async function extractApkInfo(zip: JSZip, file: File, allFiles: ApkFile[]): Promise<ApkInfo> {
  let packageName: string | undefined;
  let versionName: string | undefined;
  let versionCode: string | undefined;
  let minSdkVersion: string | undefined;
  let targetSdkVersion: string | undefined;

  const manifestFile = zip.files["AndroidManifest.xml"];
  if (manifestFile) {
    try {
      const text = await manifestFile.async("string");
      const pkgMatch = text.match(/package="([^"]+)"/);
      if (pkgMatch) packageName = pkgMatch[1];
      const vNameMatch = text.match(/versionName="([^"]+)"/);
      if (vNameMatch) versionName = vNameMatch[1];
      const vCodeMatch = text.match(/versionCode="([^"]+)"/);
      if (vCodeMatch) versionCode = vCodeMatch[1];
      const minSdkMatch = text.match(/minSdkVersion="([^"]+)"/);
      if (minSdkMatch) minSdkVersion = minSdkMatch[1];
      const targetSdkMatch = text.match(/targetSdkVersion="([^"]+)"/);
      if (targetSdkMatch) targetSdkVersion = targetSdkMatch[1];
    } catch {}
  }

  return {
    name: file.name,
    size: file.size,
    fileCount: allFiles.filter(f => !f.isDirectory).length,
    packageName,
    versionName,
    versionCode,
    minSdkVersion,
    targetSdkVersion,
  };
}

export async function searchInApk(
  zip: JSZip,
  query: string,
  options: { regex?: boolean; caseSensitive?: boolean; filePattern?: string }
): Promise<SearchResult[]> {
  const results: SearchResult[] = [];
  if (!query) return results;

  let pattern: RegExp;
  try {
    if (options.regex) {
      pattern = new RegExp(query, options.caseSensitive ? "g" : "gi");
    } else {
      const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      pattern = new RegExp(escaped, options.caseSensitive ? "g" : "gi");
    }
  } catch {
    return results;
  }

  const filePattern = options.filePattern
    ? new RegExp(options.filePattern.replace(/\*/g, ".*").replace(/\?/g, "."), "i")
    : null;

  for (const [path, zipFile] of Object.entries(zip.files)) {
    if (zipFile.dir) continue;
    if (filePattern && !filePattern.test(path)) continue;

    const fileName = path.split("/").pop() || path;
    if (!isTextFile(fileName)) continue;

    try {
      const content = await zipFile.async("string");
      const lines = content.split("\n");

      for (let lineNum = 0; lineNum < lines.length; lineNum++) {
        const line = lines[lineNum];
        pattern.lastIndex = 0;
        let match: RegExpExecArray | null;

        while ((match = pattern.exec(line)) !== null) {
          results.push({
            file: path,
            line: lineNum + 1,
            content: line.trim(),
            matchStart: match.index,
            matchEnd: match.index + match[0].length,
          });

          if (results.length >= 500) return results;
        }
      }
    } catch {}
  }

  return results;
}

export async function getFileContent(zip: JSZip, path: string): Promise<{ text?: string; binary?: Uint8Array }> {
  const zipFile = zip.files[path] || zip.files[path + "/"];
  if (!zipFile) throw new Error(`File not found: ${path}`);

  const fileName = path.split("/").pop() || path;
  if (isTextFile(fileName)) {
    try {
      const text = await zipFile.async("string");
      return { text };
    } catch {}
  }

  const binary = await zipFile.async("uint8array");
  return { binary };
}

export async function updateFileInApk(zip: JSZip, path: string, content: string): Promise<void> {
  zip.file(path, content);
}

export async function injectZipProject(mainZip: JSZip, projectZipFile: File, targetPath: string): Promise<string[]> {
  const arrayBuffer = await projectZipFile.arrayBuffer();
  const projectZip = await JSZip.loadAsync(arrayBuffer);
  const injected: string[] = [];

  for (const [path, zipFile] of Object.entries(projectZip.files)) {
    if (zipFile.dir) continue;
    const content = await zipFile.async("uint8array");
    const destPath = targetPath ? `${targetPath}/${path}` : path;
    mainZip.file(destPath, content);
    injected.push(destPath);
  }

  return injected;
}

export async function buildApk(zip: JSZip): Promise<{ blob: Blob; errors: BuildError[] }> {
  const errors: BuildError[] = [];

  const manifest = zip.files["AndroidManifest.xml"];
  if (!manifest) {
    errors.push({ file: "AndroidManifest.xml", message: "AndroidManifest.xml not found — required for valid APK", type: "error" });
  } else {
    try {
      const content = await manifest.async("string");
      if (!content.includes("package=")) {
        errors.push({ file: "AndroidManifest.xml", line: 1, message: "Missing 'package' attribute in manifest", type: "error" });
      }
      if (!content.includes("<activity")) {
        errors.push({ file: "AndroidManifest.xml", message: "No Activity declared — app may not launch", type: "warning" });
      }
    } catch (e) {
      errors.push({ file: "AndroidManifest.xml", message: "Failed to parse manifest: " + (e as Error).message, type: "error" });
    }
  }

  for (const [path, zipFile] of Object.entries(zip.files)) {
    if (zipFile.dir) continue;
    const ext = getFileExtension(path.split("/").pop() || "");

    if (ext === "xml" && !path.startsWith("META-INF")) {
      try {
        const content = await zipFile.async("string");
        const openTags = (content.match(/<[^/][^>]*>/g) || []).length;
        const closeTags = (content.match(/<\/[^>]+>/g) || []).length;
        const selfClose = (content.match(/<[^>]+\/>/g) || []).length;
        if (Math.abs(openTags - closeTags - selfClose) > 2) {
          errors.push({ file: path, message: "Possible unclosed XML tags detected", type: "warning" });
        }
      } catch {}
    }

    if (ext === "java") {
      try {
        const content = await zipFile.async("string");
        if (content.includes("System.out.println") || content.includes("e.printStackTrace()")) {
          errors.push({ file: path, message: "Debug logging found — consider removing for production", type: "warning" });
        }
      } catch {}
    }
  }

  const blob = await zip.generateAsync({ type: "blob", compression: "DEFLATE", compressionOptions: { level: 6 } });
  return { blob, errors };
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

export function flattenFiles(files: ApkFile[]): ApkFile[] {
  const result: ApkFile[] = [];
  const traverse = (items: ApkFile[]) => {
    for (const item of items) {
      result.push(item);
      if (item.children) traverse(item.children);
    }
  };
  traverse(files);
  return result;
}
