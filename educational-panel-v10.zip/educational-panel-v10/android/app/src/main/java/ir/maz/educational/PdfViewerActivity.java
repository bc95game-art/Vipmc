package ir.maz.educational;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class PdfViewerActivity extends AppCompatActivity {

    private PdfRenderer pdfRenderer;
    private ParcelFileDescriptor pfd;
    private RecyclerView recyclerView;
    private TextView tvTitle, tvPageInfo;
    private ProgressBar progressBar;
    private View emptyState;
    private int totalPages = 0;

    // FIX: thread pool محدود به ۲ — جلوگیری از race condition و OOM هنگام scroll سریع
    private final ExecutorService renderExecutor = Executors.newFixedThreadPool(2);

    // FIX: قفل مشترک بین رندر صفحات و بستن PdfRenderer در onDestroy
    // تا هیچ‌گاه renderPage() همزمان با close() اجرا نشود (علت اصلی کرش هنگام بازگشت)
    private final Object pdfLock = new Object();

    // FIX: پرچم برای جلوگیری از دسترسی به View/PdfRenderer بعد از پایان Activity
    private volatile boolean isClosed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            // Full-screen immersive
            getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            );
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN
            );

            setContentView(R.layout.activity_pdf_viewer);

            tvTitle     = findViewById(R.id.tvPdfTitle);
            tvPageInfo  = findViewById(R.id.tvPageInfo);
            progressBar = findViewById(R.id.pdfProgressBar);
            recyclerView = findViewById(R.id.pdfRecyclerView);
            emptyState  = findViewById(R.id.pdfEmptyState);

            String pdfPath  = getIntent().getStringExtra("pdf_path");
            String pdfTitle = getIntent().getStringExtra("pdf_title");

            tvTitle.setText(pdfTitle != null ? pdfTitle : "PDF");

            // Back button
            findViewById(R.id.btnPdfBack).setOnClickListener(v -> finish());

            if (pdfPath == null || pdfPath.trim().isEmpty()) {
                showError("مسیر فایل نامعتبر است");
                return;
            }

            File file = new File(pdfPath);
            if (!file.exists() || file.length() == 0) {
                showError("فایل PDF یافت نشد یا خراب است");
                return;
            }

            loadPdf(pdfPath);
        } catch (Exception e) {
            // FIX: جلوگیری از باز ماندن صفحه سفید در صورت بروز خطای ناشناخته در onCreate
            showError("خطا در نمایش PDF: " + e.getMessage());
        }
    }

    private void loadPdf(String path) {
        progressBar.setVisibility(View.VISIBLE);

        renderExecutor.execute(() -> {
            try {
                File file = new File(path);
                synchronized (pdfLock) {
                    if (isClosed) return;
                    pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                    pdfRenderer = new PdfRenderer(pfd);
                    totalPages  = pdfRenderer.getPageCount();
                }

                runOnUiThread(() -> {
                    if (isClosed) return;
                    progressBar.setVisibility(View.GONE);

                    if (totalPages <= 0) {
                        // FIX: PDF بدون صفحه — به‌جای صفحه سفید، پیام مناسب نشان داده می‌شود
                        showError("این فایل PDF صفحه‌ای ندارد");
                        return;
                    }

                    tvPageInfo.setText("تعداد صفحات: " + totalPages);

                    // Lazy adapter: هر صفحه هنگام نیاز رندر می‌شود (رفع OOM)
                    recyclerView.setLayoutManager(new LinearLayoutManager(this));
                    recyclerView.setRecycledViewPool(new RecyclerView.RecycledViewPool());
                    recyclerView.setAdapter(new LazyPdfAdapter());
                    recyclerView.setVisibility(View.VISIBLE);
                });

            } catch (Exception e) {
                runOnUiThread(() -> showError("خطا در بارگذاری PDF: " + e.getMessage()));
            }
        });
    }

    // ─── Lazy RecyclerView Adapter ────────────────────────────────────────────
    // هر صفحه فقط وقتی وارد دید می‌شود رندر می‌شود؛
    // وقتی از دید خارج شود Bitmap آزاد می‌شود.

    private class LazyPdfAdapter extends RecyclerView.Adapter<LazyPdfAdapter.PageHolder> {

        @Override
        public PageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            ImageView iv = new ImageView(PdfViewerActivity.this);
            int screenW = getResources().getDisplayMetrics().widthPixels;
            // ارتفاع اولیه — نسبت A4 تقریبی
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (int) (screenW * 1.414f)
            );
            iv.setLayoutParams(lp);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setBackgroundColor(Color.WHITE);
            return new PageHolder(iv);
        }

        @Override
        public void onBindViewHolder(PageHolder holder, int position) {
            holder.render(position);
        }

        @Override
        public void onViewRecycled(PageHolder holder) {
            // آزاد کردن Bitmap وقتی آیتم از دید خارج می‌شود
            holder.recycleBitmap();
        }

        @Override
        public int getItemCount() { return totalPages; }

        class PageHolder extends RecyclerView.ViewHolder {
            ImageView imageView;
            // FIX: volatile برای دیده شدن صحیح بین thread‌ها
            volatile Bitmap currentBitmap = null;

            PageHolder(ImageView iv) {
                super(iv);
                imageView = iv;
            }

            void recycleBitmap() {
                Bitmap old = currentBitmap;
                currentBitmap = null;
                if (old != null && !old.isRecycled()) old.recycle();
                imageView.setImageBitmap(null);
            }

            void render(int pageIndex) {
                // FIX: از renderExecutor (thread pool) به جای new Thread استفاده می‌شود
                renderExecutor.execute(() -> {
                    if (isClosed) return;
                    Bitmap bmp = renderPage(pageIndex);
                    if (isClosed) {
                        if (bmp != null && !bmp.isRecycled()) bmp.recycle();
                        return;
                    }
                    runOnUiThread(() -> {
                        if (isClosed) {
                            if (bmp != null && !bmp.isRecycled()) bmp.recycle();
                            return;
                        }
                        // FIX: بررسی می‌شود که holder هنوز همین صفحه را نمایش می‌دهد
                        if (getBindingAdapterPosition() == pageIndex) {
                            Bitmap old = currentBitmap;
                            currentBitmap = bmp;
                            if (bmp != null) {
                                imageView.setImageBitmap(bmp);
                            } else {
                                // FIX: اگر رندر ناموفق بود، صفحه سفید خالی نمی‌ماند —
                                // حداقل پس‌زمینهٔ خاکستری روشن نمایش داده می‌شود
                                imageView.setImageBitmap(null);
                                imageView.setBackgroundColor(Color.parseColor("#e9e6df"));
                            }
                            if (old != null && !old.isRecycled()) old.recycle();
                        } else if (bmp != null && !bmp.isRecycled()) {
                            bmp.recycle();
                        }
                    });
                });
            }
        }
    }

    /** رندر یک صفحه — قفل مشترک با onDestroy جلوی استفاده از رندرر بسته‌شده را می‌گیرد */
    private Bitmap renderPage(int pageIndex) {
        synchronized (pdfLock) {
            if (isClosed || pdfRenderer == null) return null;
            PdfRenderer.Page page = null;
            try {
                page = pdfRenderer.openPage(pageIndex);
                int screenW = getResources().getDisplayMetrics().widthPixels;
                float scale = (float) screenW / page.getWidth();
                int w = screenW;
                int h = (int) (page.getHeight() * scale);

                // FIX: محدود کردن حداکثر ابعاد برای جلوگیری از OOM با PDFهای خیلی بزرگ
                int maxDim = 2200;
                if (h > maxDim) {
                    float ratio = (float) maxDim / h;
                    h = maxDim;
                    w = (int) (w * ratio);
                }
                if (w <= 0) w = 1;
                if (h <= 0) h = 1;

                // FIX: ARGB_8888 به‌جای RGB_565 — در نسخه‌های جدید اندروید
                // PdfRenderer.Page.render با RGB_565 خطا می‌دهد و نتیجه‌اش صفحهٔ سفید/خالی بود
                Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bmp);
                canvas.drawColor(Color.WHITE);
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                return bmp;
            } catch (Exception e) {
                return null;
            } finally {
                if (page != null) {
                    try { page.close(); } catch (Exception ignored) {}
                }
            }
        }
    }

    /** هندلر دکمه بازگشت در حالت خطا/خالی (از layout صدا زده می‌شود) */
    public void onEmptyBackClick(View view) {
        finish();
    }

    private void showError(String msg) {
        if (progressBar != null) progressBar.setVisibility(View.GONE);
        if (recyclerView != null) recyclerView.setVisibility(View.GONE);
        if (emptyState != null) {
            TextView tvEmpty = emptyState.findViewById(R.id.tvEmptyMessage);
            if (tvEmpty != null) tvEmpty.setText(msg);
            emptyState.setVisibility(View.VISIBLE);
        } else {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        // FIX: ابتدا پرچم بسته‌شدن فعال می‌شود تا کارهای در حال اجرا روی UI تأثیر نگذارند
        isClosed = true;
        renderExecutor.shutdownNow();
        try {
            // FIX: منتظر می‌مانیم تا کارهای در حال اجرای رندر کاملاً متوقف شوند
            renderExecutor.awaitTermination(500, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {}

        synchronized (pdfLock) {
            try {
                if (pdfRenderer != null) { pdfRenderer.close(); pdfRenderer = null; }
                if (pfd != null) { pfd.close(); pfd = null; }
            } catch (IOException ignored) {}
        }
        super.onDestroy();
    }
}
