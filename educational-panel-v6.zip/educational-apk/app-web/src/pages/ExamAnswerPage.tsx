import { useParams } from "react-router-dom";
import Layout from "../components/Layout";
import NoteBox from "../components/NoteBox";
import { PdfViewer, MediaNotAvailable } from "../components/MediaPlayer";
import { getExam } from "../data";
import { getExamAnswerPdfUrl } from "../mediaConfig";

export default function ExamAnswerPage() {
  const { examId, index } = useParams<{ examId: string; index: string }>();

  const exam      = getExam(examId);
  const answerUrl = examId && index ? getExamAnswerPdfUrl(examId, index) : null;

  return (
    <Layout
      title={`پاسخنامه ${index}`}
      subtitle={exam?.title}
      backPath={`/exams/${examId}/sessions/${index}`}
    >
      <div className="media-container">
        {answerUrl
          ? <PdfViewer src={answerUrl} mediaKey={`exam-answer-${examId}-${index}`} openLabel="باز کردن پاسخنامه" />
          : <MediaNotAvailable icon="fas fa-file-circle-xmark" message="پاسخنامه این آزمون هنوز اضافه نشده است" />
        }
      </div>
      <NoteBox noteKey={`exam_answer_${examId}_${index}`} label={`یادداشت پاسخنامه ${index}`} />
    </Layout>
  );
}
