import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";

export default function FilesPage() {
  const navigate = useNavigate();

  return (
    <Layout title="فایل‌ها" backPath="/">
      <div className="files-types-grid">
        <button className="sub-button" onClick={() => navigate("/files/simulator")}>
          <div className="sub-button-icon">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c2.png" width={36} height={36} alt="folder" />
          </div>
          <span>شبیه‌ساز نهایی</span>
        </button>
        <button className="sub-button" onClick={() => navigate("/files/tests")}>
          <div className="sub-button-icon">
            <img src="https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4dd.png" width={36} height={36} alt="tests" />
          </div>
          <span>تست‌ها</span>
        </button>
      </div>
    </Layout>
  );
}
