// tabs.js — Tab management
window.APKStudio = window.APKStudio || {};

APKStudio.tabs = (() => {
  const _tabs = new Map(); // path -> { name, modified }
  let _activeTab = null;

  function init() {}

  function openTab(path, name) {
    if (!_tabs.has(path)) {
      _tabs.set(path, { name, modified: false });
    }
    setActiveTab(path);
    renderTabs();
  }

  function setActiveTab(path) {
    _activeTab = path;
  }

  function closeTab(path) {
    const wasActive = _activeTab === path;
    _tabs.delete(path);

    if (wasActive) {
      const keys = Array.from(_tabs.keys());
      if (keys.length > 0) {
        _activeTab = keys[keys.length - 1];
        openFileForTab(_activeTab);
      } else {
        _activeTab = null;
        APKStudio.editor.showWelcome();
      }
    }
    renderTabs();
  }

  async function openFileForTab(path) {
    try {
      const content = await APKStudio.apk.getFileContent(path);
      const lang = APKStudio.apk.getSyntaxLanguage(path);
      APKStudio.editor.showFile(path, content, lang);
      // Mark active in tree
      document.querySelectorAll('.tree-item.active').forEach(el => el.classList.remove('active'));
      const treeItem = document.querySelector(`.tree-item[data-path="${path}"]`);
      if (treeItem) treeItem.classList.add('active');
    } catch (e) {}
  }

  function markModified(path) {
    if (_tabs.has(path)) {
      _tabs.get(path).modified = true;
      renderTabs();
    }
  }

  function markSaved(path) {
    if (_tabs.has(path)) {
      _tabs.get(path).modified = false;
      renderTabs();
    }
  }

  function renderTabs() {
    const container = document.getElementById('tabsContainer');
    if (!container) return;
    container.innerHTML = '';

    _tabs.forEach((info, path) => {
      const tab = document.createElement('div');
      tab.className = `tab ${path === _activeTab ? 'active' : ''}`;
      tab.title = path;

      const iconSpan = document.createElement('span');
      iconSpan.className = 'tab-icon';
      iconSpan.textContent = APKStudio.apk.getFileIcon(path, false);

      const nameSpan = document.createElement('span');
      nameSpan.className = 'tab-name';
      nameSpan.textContent = info.name;

      const closeBtn = document.createElement('span');
      closeBtn.className = 'tab-close';
      closeBtn.title = 'بستن';
      closeBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>`;

      if (info.modified) {
        const dot = document.createElement('span');
        dot.className = 'tab-modified';
        tab.appendChild(dot);
      }

      tab.appendChild(iconSpan);
      tab.appendChild(nameSpan);
      tab.appendChild(closeBtn);

      tab.addEventListener('click', (e) => {
        if (!e.target.closest('.tab-close')) {
          setActiveTab(path);
          openFileForTab(path);
          renderTabs();
        }
      });

      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        closeTab(path);
      });

      container.appendChild(tab);
    });
  }

  return { init, openTab, closeTab, markModified, markSaved };
})();
