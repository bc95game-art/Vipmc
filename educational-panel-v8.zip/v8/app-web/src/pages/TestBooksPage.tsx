import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { fileBooks } from "../data";

export default function TestBooksPage() {
  const navigate = useNavigate();

  return (
    <Layout title="تست‌ها" backPath="/files">
      {fileBooks.map((book, idx) => (
        <div
          key={book.id}
          className="class-item"
          onClick={() => navigate(`/files/tests/${book.id}`)}
        >
          <div
            className="class-item-icon"
            style={{ background: `linear-gradient(145deg, #c9a227, #9b7a1a)` }}
          >
            <span className="class-item-num">{idx + 1}</span>
          </div>
          <div className="class-item-text">
            <div className="class-item-title">{book.title}</div>
            <div className="class-info">تست‌های طبقه‌بندی‌شده</div>
          </div>
          <i className="fas fa-chevron-left class-item-arrow" />
        </div>
      ))}
    </Layout>
  );
}
