import { useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { NoteBox } from "../components/MediaPlayer";
import { PdfViewer, MediaNotAvailable } from "../components/MediaPlayer";
import { getFileBook } from "../data";
import { getSimulatorPdfUrl } from "../mediaConfig";

export default function FilePdfPage() {
  const { bookId, index } = useParams<{ bookId: string; index: string }>();

  const book   = getFileBook(bookId);
  const pdfUrl = bookId && index ? getSimulatorPdfUrl(bookId, index) : null;

  return (
    <Layout
      title={`آزمون ${index}`}
      subtitle={book?.title}
      backPath={`/files/simulator/${bookId}`}
    >
      <div className="media-container">
        {pdfUrl
          ? <PdfViewer src={pdfUrl} mediaKey={`sim-${bookId}-${index}`} openLabel="باز کردن آزمون" />
          : <MediaNotAvailable message="فایل آزمون هنوز اضافه نشده است" />
        }
      </div>
      <NoteBox noteKey={`sim_${bookId}_${index}`} label={`یادداشت آزمون ${index} — ${book?.title}`} />
    </Layout>
  );
}
