import { useState, useEffect, useCallback } from "react";

interface NoteBoxProps {
  noteKey: string;
  label?: string;
}

export default function NoteBox({ noteKey, label = "یادداشت شما" }: NoteBoxProps) {
  const storageKey = `note_${noteKey}`;
  const [note, setNote]   = useState("");
  const [saved, setSaved] = useState(false);
  const [charCount, setCharCount] = useState(0);

  useEffect(() => {
    const stored = localStorage.getItem(storageKey);
    const val = stored ?? "";
    setNote(val);
    setCharCount(val.length);
  }, [storageKey]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNote(e.target.value);
    setCharCount(e.target.value.length);
  }, []);

  const handleSave = useCallback(() => {
    localStorage.setItem(storageKey, note);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }, [storageKey, note]);

  const handleClear = useCallback(() => {
    if (window.confirm("یادداشت پاک شود؟")) {
      setNote("");
      setCharCount(0);
      localStorage.removeItem(storageKey);
    }
  }, [storageKey]);

  return (
    <div className="note-box">
      <div className="note-box-header">
        <div className="note-box-label">
          <i className="fas fa-sticky-note" /> {label}
        </div>
        {charCount > 0 && (
          <button className="note-clear-btn" onClick={handleClear} title="پاک کردن">
            <i className="fas fa-trash-alt" />
          </button>
        )}
      </div>
      <textarea
        className="note-textarea"
        value={note}
        onChange={handleChange}
        placeholder="یادداشت خود را اینجا بنویسید..."
        rows={4}
      />
      <div className="note-footer">
        <span className="note-char-count">{charCount} کاراکتر</span>
        <button className="note-save-btn" onClick={handleSave}>
          {saved
            ? <><i className="fas fa-check" /> ذخیره شد!</>
            : <><i className="fas fa-save" /> ذخیره</>
          }
        </button>
      </div>
    </div>
  );
}
