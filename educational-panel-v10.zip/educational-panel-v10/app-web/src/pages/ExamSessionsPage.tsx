import { useState, useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { getExam } from "../data";

export default function ExamSessionsPage() {
  const { examId } = useParams<{ examId: string }>();
  const navigate   = useNavigate();
  const [search, setSearch] = useState("");

  const exam = getExam(examId);
  const total = 100;

  const items = useMemo(() =>
    Array.from({ length: total }, (_, i) => i + 1).filter(i =>
      search ? String(i).includes(search) : true
    ), [search]);

  return (
    <Layout title="سوالات آزمون" subtitle={exam?.title} backPath={`/exams/${examId}`}>
      <div className="search-box">
        <i className="fas fa-search" />
        <input
          type="number" min={1} max={total}
          placeholder="شماره آزمون..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="search-input"
        />
        {search && (
          <button className="search-clear" onClick={() => setSearch("")}>
            <i className="fas fa-times" />
          </button>
        )}
      </div>
      <div className="lesson-list">
        {items.map(i => (
          <div
            key={i}
            className="lesson-item exam-session-item"
            onClick={() => navigate(`/exams/${examId}/sessions/${i}`)}
          >
            <span className="item-number">{i}</span>
            <span className="item-label">آزمون</span>
          </div>
        ))}
        {items.length === 0 && <div className="empty-search">موردی یافت نشد</div>}
      </div>
    </Layout>
  );
}
