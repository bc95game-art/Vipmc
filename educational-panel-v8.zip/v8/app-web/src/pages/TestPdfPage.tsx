import { useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { NoteBox } from "../components/MediaPlayer";
import { PdfViewer, MediaNotAvailable } from "../components/MediaPlayer";
import { getFileBook } from "../data";
import { getTestPdfUrl } from "../mediaConfig";

export default function TestPdfPage() {
  const { bookId, index } = useParams<{ bookId: string; index: string }>();

  const book   = getFileBook(bookId);
  const pdfUrl = bookId && index ? getTestPdfUrl(bookId, index) : null;

  return (
    <Layout
      title={`تست ${index}`}
      subtitle={book?.title}
      backPath={`/files/tests/${bookId}`}
    >
      <div className="media-container">
        {pdfUrl
          ? <PdfViewer src={pdfUrl} mediaKey={`test-${bookId}-${index}`} openLabel="باز کردن تست" />
          : <MediaNotAvailable message="فایل تست هنوز اضافه نشده است" />
        }
      </div>
      <NoteBox noteKey={`test_${bookId}_${index}`} label={`یادداشت تست ${index} — ${book?.title}`} />
    </Layout>
  );
}
