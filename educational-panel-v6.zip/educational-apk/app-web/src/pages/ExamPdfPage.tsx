import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import NoteBox from "../components/NoteBox";
import { PdfViewer, MediaNotAvailable } from "../components/MediaPlayer";
import { getExam } from "../data";
import { getExamSessionPdfUrl } from "../mediaConfig";

export default function ExamPdfPage() {
  const { examId, index } = useParams<{ examId: string; index: string }>();
  const navigate = useNavigate();

  const exam   = getExam(examId);
  const pdfUrl = examId && index ? getExamSessionPdfUrl(examId, index) : null;

  return (
    <Layout
      title={`آزمون ${index}`}
      subtitle={exam?.title}
      backPath={`/exams/${examId}/sessions`}
    >
      <div className="media-container">
        {pdfUrl
          ? <PdfViewer src={pdfUrl} mediaKey={`exam-session-${examId}-${index}`} openLabel="باز کردن آزمون" />
          : <MediaNotAvailable message="فایل آزمون هنوز اضافه نشده است" />
        }
      </div>

      <button
        type="button"
        className="answer-sheet-btn"
        onClick={() => navigate(`/exams/${examId}/sessions/${index}/answer`)}
      >
        <i className="fas fa-key" /> مشاهده پاسخنامه
      </button>

      <NoteBox noteKey={`exam_session_${examId}_${index}`} label={`یادداشت آزمون ${index}`} />
    </Layout>
  );
}
