// build.js — APK build simulation with validation and error reporting
window.APKStudio = window.APKStudio || {};

APKStudio.build = (() => {
  let _buildLog = [];
  let _buildBlob = null;

  const buildPanel = () => document.getElementById('buildPanel');
  const buildOutput = () => document.getElementById('buildOutput');
  const downloadApkBtn = () => document.getElementById('downloadApkBtn');
  const closeBuildPanelBtn = () => document.getElementById('closeBuildPanel');
  const clearBuildBtn = () => document.getElementById('clearBuildBtn');

  function init() {
    closeBuildPanelBtn()?.addEventListener('click', closeBuildPanel);
    clearBuildBtn()?.addEventListener('click', clearLog);
    downloadApkBtn()?.addEventListener('click', downloadBuiltApk);
    document.getElementById('buildApkBtn')?.addEventListener('click', startBuild);
  }

  function openBuildPanel() {
    buildPanel().style.display = 'flex';
  }

  function closeBuildPanel() {
    buildPanel().style.display = 'none';
  }

  function clearLog() {
    _buildLog = [];
    buildOutput().innerHTML = '';
    downloadApkBtn().style.display = 'none';
  }

  function log(msg, type = 'info') {
    const time = new Date().toLocaleTimeString('fa-IR', { hour12: false });
    _buildLog.push({ msg, type, time });
    const div = document.createElement('div');
    div.className = `build-log ${type}`;
    div.innerHTML = `<span class="log-time">[${time}]</span><span class="log-msg">${escapeHtml(msg)}</span>`;
    buildOutput().appendChild(div);
    buildOutput().scrollTop = buildOutput().scrollHeight;
  }

  function escapeHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  async function startBuild() {
    if (!APKStudio.apk.isLoaded()) {
      APKStudio.ui.toast('ابتدا یک APK بارگذاری کنید', 'error');
      return;
    }

    openBuildPanel();
    clearLog();
    _buildBlob = null;
    downloadApkBtn().style.display = 'none';

    log('══════════════════════════════', 'info');
    log('شروع فرآیند ساخت APK', 'step');
    log('══════════════════════════════', 'info');

    const errors = [];
    const warnings = [];

    try {
      // Step 1: Validation
      log('مرحله ۱: اعتبارسنجی فایل‌ها', 'step');
      await sleep(300);
      const validationResult = await validateFiles();
      errors.push(...validationResult.errors);
      warnings.push(...validationResult.warnings);

      if (validationResult.errors.length) {
        log(`${validationResult.errors.length} خطا پیدا شد`, 'error');
        validationResult.errors.forEach(e => log(`  ✗ ${e.file}: ${e.message}`, 'error'));
        log('ساخت به دلیل خطا متوقف شد', 'error');
        return;
      }

      if (validationResult.warnings.length) {
        log(`${validationResult.warnings.length} هشدار:`, 'warning');
        validationResult.warnings.forEach(w => log(`  ⚠ ${w.file}: ${w.message}`, 'warning'));
      } else {
        log('✓ اعتبارسنجی موفق', 'success');
      }

      // Step 2: Resource check
      log('مرحله ۲: بررسی منابع', 'step');
      await sleep(400);
      const resourceResult = await checkResources();
      if (resourceResult.warnings.length) {
        resourceResult.warnings.forEach(w => log(`  ⚠ ${w}`, 'warning'));
      }
      log('✓ منابع بررسی شدند', 'success');

      // Step 3: Manifest validation
      log('مرحله ۳: بررسی AndroidManifest.xml', 'step');
      await sleep(300);
      const manifestResult = await validateManifest();
      if (manifestResult.errors.length) {
        manifestResult.errors.forEach(e => log(`  ✗ Manifest: ${e}`, 'error'));
        log('خطا در Manifest - ساخت متوقف شد', 'error');
        return;
      }
      if (manifestResult.warnings.length) {
        manifestResult.warnings.forEach(w => log(`  ⚠ Manifest: ${w}`, 'warning'));
      }
      log('✓ AndroidManifest.xml معتبر است', 'success');

      // Step 4: Packaging
      log('مرحله ۴: بسته‌بندی فایل‌ها', 'step');
      await sleep(200);

      const modifiedFiles = APKStudio.apk.getModifiedFiles();
      if (modifiedFiles.length > 0) {
        log(`${modifiedFiles.length} فایل تغییر کرده:`, 'info');
        modifiedFiles.forEach(f => log(`  • ${f}`, 'info'));
      }

      // Simulate packaging with progress
      const allFiles = await APKStudio.apk.getAllFiles();
      log(`در حال بسته‌بندی ${allFiles.length} فایل...`, 'info');

      for (let i = 0; i <= 100; i += 20) {
        await sleep(150);
        log(`  پیشرفت بسته‌بندی: ${i}%`, 'info');
      }

      // Step 5: Build APK
      log('مرحله ۵: ساخت فایل APK', 'step');
      await sleep(300);

      _buildBlob = await APKStudio.apk.buildAPK();
      log('✓ APK ساخته شد', 'success');

      // Step 6: Signing info
      log('مرحله ۶: اطلاعات امضا', 'step');
      await sleep(200);
      log('⚠ APK بدون امضا - برای نصب باید امضا شود', 'warning');
      log('  توصیه: از apksigner یا keytool استفاده کنید', 'info');

      log('══════════════════════════════', 'info');
      log(`✓ ساخت APK با موفقیت کامل شد`, 'success');
      log(`  حجم نهایی: ${APKStudio.apk.formatSize(_buildBlob.size)}`, 'info');
      log('══════════════════════════════', 'info');

      downloadApkBtn().style.display = 'inline-flex';
      APKStudio.ui.toast('APK با موفقیت ساخته شد!', 'success');

    } catch (err) {
      log(`خطای غیرمنتظره: ${err.message}`, 'error');
      log('ساخت ناموفق بود', 'error');
      APKStudio.ui.toast('خطا در ساخت APK', 'error');
    }
  }

  async function validateFiles() {
    const errors = [];
    const warnings = [];
    const allFiles = await APKStudio.apk.getAllFiles();

    // Check for modified files with potential issues
    const modifiedFiles = APKStudio.apk.getModifiedFiles();
    for (const filePath of modifiedFiles) {
      const content = await APKStudio.apk.getFileContent(filePath);
      if (content === null) continue;

      const ext = filePath.split('.').pop()?.toLowerCase();

      // JSON validation
      if (ext === 'json') {
        try { JSON.parse(content); }
        catch (e) { errors.push({ file: filePath, message: `JSON نامعتبر: ${e.message}` }); }
      }

      // XML basic validation
      if (ext === 'xml') {
        const issues = validateXMLBasic(content);
        issues.errors.forEach(e => errors.push({ file: filePath, message: e }));
        issues.warnings.forEach(w => warnings.push({ file: filePath, message: w }));
      }

      // Check for empty file
      if (content.trim().length === 0) {
        warnings.push({ file: filePath, message: 'فایل خالی است' });
      }
    }

    // Check required files
    const requiredFiles = ['AndroidManifest.xml'];
    for (const req of requiredFiles) {
      const exists = allFiles.some(f => f === req || f.endsWith('/' + req));
      if (!exists) {
        errors.push({ file: req, message: 'فایل ضروری وجود ندارد' });
      }
    }

    return { errors, warnings };
  }

  function validateXMLBasic(content) {
    const errors = [];
    const warnings = [];

    // Check for unclosed tags (basic)
    const openTags = (content.match(/<[a-zA-Z][^/>]*(?<!\/)>/g) || []).length;
    const closeTags = (content.match(/<\/[a-zA-Z][^>]*>/g) || []).length;
    const selfClose = (content.match(/<[a-zA-Z][^>]*\/>/g) || []).length;

    // Very rough check
    if (Math.abs(openTags - closeTags - selfClose) > 5) {
      warnings.push('ساختار XML ممکن است نامعتبر باشد');
    }

    // Check for common XML errors
    if (content.includes('&') && !content.includes('&amp;') && !content.includes('&#')) {
      warnings.push('کاراکتر & بدون escape پیدا شد');
    }

    return { errors, warnings };
  }

  async function checkResources() {
    const warnings = [];
    const allFiles = await APKStudio.apk.getAllFiles();

    const drawables = allFiles.filter(f => f.includes('/drawable') && (f.endsWith('.png') || f.endsWith('.xml')));
    const layouts = allFiles.filter(f => f.includes('/layout') && f.endsWith('.xml'));

    if (drawables.length === 0) warnings.push('هیچ drawable پیدا نشد');
    if (layouts.length === 0) warnings.push('هیچ layout پیدا نشد');

    return { warnings };
  }

  async function validateManifest() {
    const errors = [];
    const warnings = [];

    const allFiles = await APKStudio.apk.getAllFiles();
    const manifestPath = allFiles.find(f => f === 'AndroidManifest.xml' || f.endsWith('/AndroidManifest.xml'));

    if (!manifestPath) {
      errors.push('AndroidManifest.xml پیدا نشد');
      return { errors, warnings };
    }

    const content = await APKStudio.apk.getFileContent(manifestPath);
    if (!content) return { errors, warnings };

    // Basic manifest checks
    if (!content.includes('package=') && !content.includes('<manifest')) {
      warnings.push('تگ manifest یا package پیدا نشد');
    }

    return { errors, warnings };
  }

  function downloadBuiltApk() {
    if (!_buildBlob) return;
    const fileName = APKStudio.apk.getFileName().replace('.apk', '') + '_modified.apk';
    const url = URL.createObjectURL(_buildBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    APKStudio.ui.toast(`دانلود ${fileName} شروع شد`, 'success');
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  return { init, openBuildPanel };
})();
