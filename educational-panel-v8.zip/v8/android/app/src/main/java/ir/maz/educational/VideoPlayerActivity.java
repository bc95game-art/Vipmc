package ir.maz.educational;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

@UnstableApi
public class VideoPlayerActivity extends AppCompatActivity {

    private ExoPlayer player;
    private PlayerView playerView;
    private TextView tvTitle;
    private String assetPath;
    private long savedPosition = 0;
    private static final String PREFS_NAME = "maz_video_pos";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen on & full-screen
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        setContentView(R.layout.activity_video_player);

        tvTitle     = findViewById(R.id.tvVideoTitle);
        playerView  = findViewById(R.id.playerView);

        assetPath = getIntent().getStringExtra("video_asset_path");
        String videoTitle = getIntent().getStringExtra("video_title");

        tvTitle.setText(videoTitle != null ? videoTitle : "ویدیو");

        // Back button
        ImageButton btnBack = findViewById(R.id.btnVideoBack);
        btnBack.setOnClickListener(v -> finish());

        // Restore position
        savedPosition = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .getLong(assetPath, 0);

        initPlayer();
    }

    private void initPlayer() {
        if (assetPath == null) {
            Toast.makeText(this, "مسیر ویدیو نامعتبر است", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        playerView.setKeepContentOnPlayerReset(true);

        // Build asset:// URI which ExoPlayer supports via AssetDataSource
        Uri videoUri = Uri.parse("asset:///" + assetPath);
        MediaItem mediaItem = MediaItem.fromUri(videoUri);
        player.setMediaItem(mediaItem);
        player.prepare();

        if (savedPosition > 5000) {
            player.seekTo(savedPosition);
        }

        player.setPlayWhenReady(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(androidx.media3.common.PlaybackException error) {
                Toast.makeText(VideoPlayerActivity.this,
                    "خطا: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) {
            savedPosition = player.getCurrentPosition();
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putLong(assetPath, savedPosition).apply();
            player.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (player != null) {
            player.play();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            savedPosition = player.getCurrentPosition();
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putLong(assetPath, savedPosition).apply();
            player.release();
            player = null;
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN
            );
        }
    }
}
