import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";

export default function FilesPage() {
  const navigate = useNavigate();

  return (
    <Layout title="فایل‌ها" backPath="/">
      <div className="files-types-grid">
        <button className="sub-button" onClick={() => navigate("/files/simulator")}>
          <i className="fas fa-folder-open" />
          <span>شبیه‌ساز نهایی</span>
        </button>
        <button className="sub-button" onClick={() => navigate("/files/tests")}>
          <i className="fas fa-tasks" />
          <span>تست‌ها</span>
        </button>
      </div>
    </Layout>
  );
}
