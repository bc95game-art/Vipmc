پوشه PDFها
ساختار:
  pdf/{typeKey}_{slug}/mcvip1.pdf       -- جزوات کلاس‌ها
  pdf/{typeKey}_{slug}/note_1.pdf       -- نوت‌ها
  pdf/exam_{examId}/sessions/exam_1.pdf -- آزمون‌ها
  pdf/exam_{examId}/answers/answer_1.pdf
  pdf/exam_{examId}/files/file_1.pdf
  pdf/simulator/{bookId}/exam_1.pdf
  pdf/tests/{bookId}/test_1.pdf

مثال:
  pdf/A_farsi/note_1.pdf
  pdf/exam_maz/sessions/exam_1.pdf
