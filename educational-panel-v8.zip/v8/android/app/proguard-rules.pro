# Proguard rules for educational panel
# Keep JavaScript interface methods used by MazBridge
-keepclassmembers class ir.maz.educational.MazBridge {
    @android.webkit.JavascriptInterface <methods>;
}
