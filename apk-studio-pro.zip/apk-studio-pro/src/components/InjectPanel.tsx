import { useState, useRef } from "react";
import { Upload, FolderInput, CheckCircle2, AlertCircle, Loader2, Package } from "lucide-react";

interface InjectPanelProps {
  onInject: (zipFile: File, targetPath: string) => Promise<string[]>;
  hasApk: boolean;
}

export function InjectPanel({ onInject, hasApk }: InjectPanelProps) {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [targetPath, setTargetPath] = useState("assets/injected");
  const [injecting, setInjecting] = useState(false);
  const [injectedFiles, setInjectedFiles] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file && file.name.endsWith(".zip")) {
      setSelectedFile(file);
      setError(null);
      setInjectedFiles([]);
    } else {
      setError("فقط فایل‌های .zip قابل قبول هستند");
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.name.endsWith(".zip")) {
      setSelectedFile(file);
      setError(null);
      setInjectedFiles([]);
    } else if (file) {
      setError("فقط فایل‌های .zip قابل قبول هستند");
    }
  };

  const handleInject = async () => {
    if (!selectedFile || !hasApk) return;
    setInjecting(true);
    setError(null);
    try {
      const files = await onInject(selectedFile, targetPath);
      setInjectedFiles(files);
    } catch (e) {
      setError((e as Error).message || "خطا در تزریق پروژه");
    } finally {
      setInjecting(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] text-gray-300 p-4 space-y-4 overflow-y-auto">
      <div className="space-y-1">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <FolderInput size={14} className="text-[#569cd6]" />
          تزریق پروژه
        </h3>
        <p className="text-xs text-gray-500">
          فایل‌های پروژه خود را از طریق zip به داخل APK تزریق کنید
        </p>
      </div>

      {!hasApk && (
        <div className="flex items-center gap-2 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded text-xs text-yellow-400">
          <AlertCircle size={12} />
          ابتدا یک فایل APK بارگذاری کنید
        </div>
      )}

      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-all ${
          dragOver
            ? "border-[#007acc] bg-[#007acc]/10"
            : selectedFile
            ? "border-green-500/50 bg-green-500/5"
            : "border-[#3d3d3d] hover:border-[#007acc]/50 hover:bg-[#007acc]/5"
        }`}
      >
        <input ref={fileInputRef} type="file" accept=".zip" className="hidden" onChange={handleFileSelect} />

        {selectedFile ? (
          <div className="space-y-1">
            <Package size={24} className="mx-auto text-green-400" />
            <p className="text-sm text-green-400 font-medium">{selectedFile.name}</p>
            <p className="text-xs text-gray-500">
              {(selectedFile.size / 1024).toFixed(1)} KB
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            <Upload size={24} className="mx-auto text-gray-500" />
            <p className="text-sm text-gray-400">فایل zip را اینجا رها کنید</p>
            <p className="text-xs text-gray-600">یا کلیک کنید</p>
          </div>
        )}
      </div>

      <div className="space-y-1.5">
        <label className="text-xs text-gray-400 font-medium">مسیر تزریق در APK</label>
        <input
          type="text"
          value={targetPath}
          onChange={(e) => setTargetPath(e.target.value)}
          placeholder="assets/injected"
          className="w-full bg-[#2d2d2d] text-xs text-gray-200 placeholder-gray-500 px-3 py-2 rounded border border-[#3d3d3d] focus:outline-none focus:border-[#007acc]"
        />
        <p className="text-[10px] text-gray-600">
          فایل‌های zip در این مسیر قرار می‌گیرند. خالی بذارید برای root
        </p>
      </div>

      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded text-xs text-red-400">
          <AlertCircle size={12} className="flex-shrink-0" />
          {error}
        </div>
      )}

      {injectedFiles.length > 0 && (
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs text-green-400">
            <CheckCircle2 size={12} />
            {injectedFiles.length} فایل با موفقیت تزریق شد
          </div>
          <div className="bg-[#2d2d2d] rounded p-2 max-h-40 overflow-y-auto space-y-0.5">
            {injectedFiles.map((f, i) => (
              <div key={i} className="text-[10px] text-gray-400 font-mono truncate">{f}</div>
            ))}
          </div>
        </div>
      )}

      <button
        onClick={handleInject}
        disabled={!selectedFile || !hasApk || injecting}
        className="flex items-center justify-center gap-2 w-full py-2.5 bg-[#569cd6] hover:bg-[#4e8cbf] disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-medium rounded transition-colors"
      >
        {injecting ? (
          <>
            <Loader2 size={14} className="animate-spin" />
            در حال تزریق...
          </>
        ) : (
          <>
            <FolderInput size={14} />
            تزریق به APK
          </>
        )}
      </button>
    </div>
  );
}
