// editor.js — Code editor with line numbers, find/replace, cursor tracking
window.APKStudio = window.APKStudio || {};

APKStudio.editor = (() => {
  let _currentPath = null;
  let _currentLang = 'text';
  let _findMatches = [];
  let _currentMatchIdx = 0;
  let _findReplaceOpen = false;

  const el = {
    wrapper: () => document.getElementById('codeEditorWrapper'),
    editor: () => document.getElementById('codeEditor'),
    lineNumbers: () => document.getElementById('lineNumbers'),
    cursorPos: () => document.getElementById('cursorPos'),
    selectionInfo: () => document.getElementById('selectionInfo'),
    fileSize: () => document.getElementById('fileSize'),
    fileEncoding: () => document.getElementById('fileEncoding'),
    currentFilePath: () => document.getElementById('currentFilePath'),
    fileType: () => document.getElementById('fileType'),
    findReplacePanel: () => document.getElementById('findReplacePanel'),
    findInput: () => document.getElementById('findInput'),
    replaceInput: () => document.getElementById('replaceInput'),
    findCount: () => document.getElementById('findCount'),
    imageViewer: () => document.getElementById('imageViewer'),
    previewImage: () => document.getElementById('previewImage'),
    imageInfo: () => document.getElementById('imageInfo'),
    binaryViewer: () => document.getElementById('binaryViewer'),
    binaryFileName: () => document.getElementById('binaryFileName'),
    binaryFileSize: () => document.getElementById('binaryFileSize'),
    downloadBinaryBtn: () => document.getElementById('downloadBinaryBtn'),
    welcomeScreen: () => document.getElementById('welcomeScreen'),
  };

  function init() {
    const editor = el.editor();
    if (!editor) return;

    editor.addEventListener('input', onInput);
    editor.addEventListener('keydown', onKeyDown);
    editor.addEventListener('scroll', syncScroll);
    editor.addEventListener('selectionchange', updateCursorPos);
    editor.addEventListener('click', updateCursorPos);
    editor.addEventListener('keyup', updateCursorPos);

    // Find/Replace
    document.getElementById('findReplaceBtn')?.addEventListener('click', toggleFindReplace);
    document.getElementById('closeFRBtn')?.addEventListener('click', closeFindReplace);
    document.getElementById('findInput')?.addEventListener('input', doFind);
    document.getElementById('nextMatchBtn')?.addEventListener('click', nextMatch);
    document.getElementById('prevMatchBtn')?.addEventListener('click', prevMatch);
    document.getElementById('replaceBtn')?.addEventListener('click', doReplace);
    document.getElementById('replaceAllBtn')?.addEventListener('click', doReplaceAll);

    // Save
    document.getElementById('saveFileBtn')?.addEventListener('click', saveCurrentFile);
    document.getElementById('formatBtn')?.addEventListener('click', formatCurrentFile);

    // Download binary
    document.getElementById('downloadBinaryBtn')?.addEventListener('click', downloadBinary);
  }

  function showFile(path, content, lang) {
    _currentPath = path;
    _currentLang = lang;

    // Hide all viewers first
    el.wrapper() && (el.wrapper().style.display = 'none');
    el.imageViewer() && (el.imageViewer().style.display = 'none');
    el.binaryViewer() && (el.binaryViewer().style.display = 'none');
    el.welcomeScreen() && (el.welcomeScreen().style.display = 'none');

    if (content === null) {
      // Binary file
      showBinaryViewer(path);
      return;
    }

    if (APKStudio.apk.isImage(path) && content.startsWith('blob:')) {
      // Image
      el.imageViewer().style.display = 'flex';
      el.previewImage().src = content;
      el.imageInfo().textContent = path.split('/').pop();
      return;
    }

    // Text editor
    el.wrapper().style.display = 'flex';
    const editor = el.editor();
    editor.value = content;
    el.currentFilePath().textContent = path;
    el.fileType().textContent = APKStudio.syntax.getLabel(lang);
    el.fileType().style.color = APKStudio.syntax.getLangColor(lang);

    updateLineNumbers();
    updateCursorPos();
    updateFileSize(content);
  }

  function showBinaryViewer(path) {
    el.binaryViewer().style.display = 'flex';
    const name = path.split('/').pop();
    el.binaryFileName().textContent = name;
    APKStudio.apk.getFileSizeAndInfo(path).then(info => {
      if (info) el.binaryFileSize().textContent = info.sizeFormatted;
    });
  }

  let _binaryPath = null;
  async function downloadBinary() {
    if (!_currentPath) return;
    try {
      const entry = APKStudio.apk._zip?.file(_currentPath);
      if (!entry) return;
      const blob = await entry.async('blob');
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = _currentPath.split('/').pop();
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      APKStudio.ui.toast('خطا در دانلود فایل', 'error');
    }
  }

  function showWelcome() {
    el.wrapper() && (el.wrapper().style.display = 'none');
    el.imageViewer() && (el.imageViewer().style.display = 'none');
    el.binaryViewer() && (el.binaryViewer().style.display = 'none');
    el.welcomeScreen() && (el.welcomeScreen().style.display = 'flex');
    _currentPath = null;
  }

  function onInput() {
    if (!_currentPath) return;
    const content = el.editor().value;
    APKStudio.apk.saveFileContent(_currentPath, content);
    APKStudio.events.emit('fileModified', _currentPath);
    updateLineNumbers();
    updateFileSize(content);
  }

  function onKeyDown(e) {
    // Tab key — insert spaces
    if (e.key === 'Tab') {
      e.preventDefault();
      const editor = el.editor();
      const start = editor.selectionStart;
      const end = editor.selectionEnd;
      const spaces = '  '; // 2 spaces
      editor.value = editor.value.substring(0, start) + spaces + editor.value.substring(end);
      editor.selectionStart = editor.selectionEnd = start + spaces.length;
      onInput();
    }
    // Ctrl+S save
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      saveCurrentFile();
    }
    // Ctrl+F find
    if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
      e.preventDefault();
      toggleFindReplace();
    }
    // ESC close find
    if (e.key === 'Escape' && _findReplaceOpen) {
      closeFindReplace();
    }
    // Ctrl+Z, Ctrl+Y — browser handles natively
  }

  function updateLineNumbers() {
    const editor = el.editor();
    const lineNums = el.lineNumbers();
    if (!lineNums) return;
    const lines = editor.value.split('\n').length;
    let nums = '';
    for (let i = 1; i <= lines; i++) {
      nums += i + '\n';
    }
    lineNums.textContent = nums;
  }

  function syncScroll() {
    const editor = el.editor();
    const lineNums = el.lineNumbers();
    if (lineNums) lineNums.scrollTop = editor.scrollTop;
  }

  function updateCursorPos() {
    const editor = el.editor();
    if (!editor) return;
    const text = editor.value;
    const pos = editor.selectionStart;
    const lines = text.substring(0, pos).split('\n');
    const line = lines.length;
    const col = lines[lines.length - 1].length + 1;
    el.cursorPos().textContent = `خط ${line}، ستون ${col}`;

    const selLen = editor.selectionEnd - editor.selectionStart;
    el.selectionInfo().textContent = selLen > 0 ? `(${selLen} کاراکتر انتخاب شده)` : '';
  }

  function updateFileSize(content) {
    const bytes = new TextEncoder().encode(content).length;
    el.fileSize().textContent = APKStudio.apk.formatSize(bytes);
  }

  function saveCurrentFile() {
    if (!_currentPath) return;
    const content = el.editor().value;
    APKStudio.apk.saveFileContent(_currentPath, content);
    APKStudio.events.emit('fileSaved', _currentPath);
    APKStudio.ui.toast('فایل ذخیره شد', 'success');
  }

  function formatCurrentFile() {
    if (!_currentPath) return;
    const editor = el.editor();
    const lang = _currentLang;
    let content = editor.value;

    try {
      if (lang === 'json') {
        content = JSON.stringify(JSON.parse(content), null, 2);
        editor.value = content;
        onInput();
        APKStudio.ui.toast('JSON فرمت‌بندی شد', 'success');
      } else if (lang === 'xml') {
        content = formatXML(content);
        editor.value = content;
        onInput();
        APKStudio.ui.toast('XML فرمت‌بندی شد', 'success');
      } else {
        APKStudio.ui.toast('فرمت‌بندی برای این نوع فایل پشتیبانی نمی‌شود', 'info');
      }
    } catch (e) {
      APKStudio.ui.toast(`خطا در فرمت‌بندی: ${e.message}`, 'error');
    }
  }

  function formatXML(xml) {
    let formatted = '';
    let indent = 0;
    const tab = '  ';
    xml = xml.replace(/></g, '>\n<');
    xml.split('\n').forEach(line => {
      line = line.trim();
      if (!line) return;
      if (line.match(/^<\/\w/)) indent = Math.max(0, indent - 1);
      formatted += tab.repeat(indent) + line + '\n';
      if (line.match(/^<\w[^/]*[^/]>$/) && !line.match(/^<\?/) && !line.match(/^<!/) && !line.match(/<.*\/>/)) {
        indent++;
      }
    });
    return formatted.trim();
  }

  // Find/Replace
  function toggleFindReplace() {
    if (_findReplaceOpen) { closeFindReplace(); return; }
    el.findReplacePanel().style.display = 'flex';
    _findReplaceOpen = true;
    el.findInput().focus();
  }

  function closeFindReplace() {
    el.findReplacePanel().style.display = 'none';
    _findReplaceOpen = false;
    _findMatches = [];
    el.findCount().textContent = '';
  }

  function doFind() {
    const query = el.findInput().value;
    if (!query) { _findMatches = []; el.findCount().textContent = ''; return; }
    const text = el.editor().value;
    const regex = new RegExp(escapeRegex(query), 'gi');
    _findMatches = [];
    _currentMatchIdx = 0;
    let m;
    while ((m = regex.exec(text)) !== null) {
      _findMatches.push({ start: m.index, end: m.index + m[0].length });
    }
    el.findCount().textContent = `${_findMatches.length} مورد`;
    if (_findMatches.length) highlightMatch(0);
  }

  function nextMatch() {
    if (!_findMatches.length) return;
    _currentMatchIdx = (_currentMatchIdx + 1) % _findMatches.length;
    highlightMatch(_currentMatchIdx);
  }

  function prevMatch() {
    if (!_findMatches.length) return;
    _currentMatchIdx = (_currentMatchIdx - 1 + _findMatches.length) % _findMatches.length;
    highlightMatch(_currentMatchIdx);
  }

  function highlightMatch(idx) {
    const match = _findMatches[idx];
    if (!match) return;
    const editor = el.editor();
    editor.focus();
    editor.setSelectionRange(match.start, match.end);
    updateCursorPos();
  }

  function doReplace() {
    if (!_findMatches.length) return;
    const query = el.findInput().value;
    const replacement = el.replaceInput().value;
    const editor = el.editor();
    const match = _findMatches[_currentMatchIdx];
    if (!match) return;
    const text = editor.value;
    editor.value = text.substring(0, match.start) + replacement + text.substring(match.end);
    editor.setSelectionRange(match.start, match.start + replacement.length);
    onInput();
    doFind();
  }

  function doReplaceAll() {
    const query = el.findInput().value;
    if (!query) return;
    const replacement = el.replaceInput().value;
    const editor = el.editor();
    const regex = new RegExp(escapeRegex(query), 'gi');
    const count = (editor.value.match(regex) || []).length;
    editor.value = editor.value.replace(regex, replacement);
    onInput();
    doFind();
    APKStudio.ui.toast(`${count} مورد جایگزین شد`, 'success');
  }

  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function getCurrentPath() { return _currentPath; }
  function getContent() { return el.editor()?.value || ''; }

  return { init, showFile, showWelcome, getCurrentPath, getContent };
})();
