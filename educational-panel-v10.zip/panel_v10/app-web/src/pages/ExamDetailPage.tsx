import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import { getExam } from "../data";

export default function ExamDetailPage() {
  const { examId } = useParams<{ examId: string }>();
  const navigate   = useNavigate();

  const exam = getExam(examId);

  if (!exam) {
    return (
      <Layout title="خطا" backPath="/exams">
        <div className="not-available">آزمون پیدا نشد</div>
      </Layout>
    );
  }

  const sections = [
    {
      emoji: "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c4.png",
      label: "سوالات آزمون",
      path: `/exams/${examId}/sessions`,
      color: "#2f6f3e"
    },
    {
      emoji: "https://cdn.jsdelivr.net/npm/twemoji@14/assets/72x72/1f4c2.png",
      label: "فایل‌های مرتبط",
      path: `/exams/${examId}/files`,
      color: "#c9a227"
    },
  ];

  return (
    <Layout title={exam.title} subtitle={exam.info} backPath="/exams">
      <div className="exam-detail-grid">
        {sections.map(sec => (
          <button
            key={sec.path}
            className="exam-section-btn"
            style={{ "--btn-color": sec.color } as React.CSSProperties}
            onClick={() => navigate(sec.path)}
          >
            <div className="exam-section-icon">
              <img src={sec.emoji} width={32} height={32} alt={sec.label} />
            </div>
            <span>{sec.label}</span>
          </button>
        ))}
      </div>
    </Layout>
  );
}
